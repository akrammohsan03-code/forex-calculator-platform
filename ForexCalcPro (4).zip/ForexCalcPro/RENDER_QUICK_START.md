# Render Quick Start - Forex Calculator Deployment

## 🚀 **30-Minute Deployment to Render**

### **Step 1: Download Project (2 minutes)**
1. **In Replit**: Click **⋮** → **"Download as ZIP"**
2. **Extract ZIP** file on your computer

### **Step 2: Upload to GitHub (5 minutes)**
1. **Go to**: `https://github.com`
2. **Create account** (if needed) and **sign in**
3. **Click "+" → "New repository"**
4. **Name**: `forex-calculator-platform`
5. **Set Public** and **click "Create"**
6. **Upload files**: Drag all project files into GitHub
7. **Commit**: "Initial forex calculator platform"

### **Step 3: Deploy to Render (10 minutes)**
1. **Go to**: `https://render.com`
2. **Sign up with GitHub** account
3. **Click "New +" → "Web Service"**
4. **Select repository**: `forex-calculator-platform`
5. **Configure settings**:
   ```
   Name: forex-calculator-pro
   Build Command: chmod +x render-build.sh && ./render-build.sh
   Start Command: npm start
   ```
6. **Add environment variables**:
   ```
   NODE_ENV=production
   PORT=10000
   VITE_GOOGLE_ADSENSE_CLIENT=ca-pub-XXXXXXXXXX
   ```
7. **Choose plan**: Free (testing) or $7/month (production)
8. **Click "Create Web Service"**

### **Step 4: Get Your URL (5 minutes)**
1. **Wait for deployment** (5-10 minutes)
2. **Copy your URL**: `https://forex-calculator-pro.onrender.com`
3. **Test calculators**: Visit your URL and test all calculators

### **Step 5: Update WordPress (5 minutes)**
**Replace all iframe URLs in WordPress:**
- **FROM**: `https://replit-url.app`
- **TO**: `https://forex-calculator-pro.onrender.com`

### **Step 6: Monitor (3 minutes)**
1. **Check Render dashboard** for performance
2. **Enable auto-deploy** for future updates
3. **Monitor ad revenue** starting immediately

## ✅ **Done!**

**Your forex calculators are now live on Render:**
- **Professional hosting** with HTTPS
- **Cost**: $7/month (vs $20/month Replit)
- **Revenue potential**: $200-1000+/month
- **ROI**: 1400%+ return on hosting investment

**Test your live calculators:**
- `https://forex-calculator-pro.onrender.com/position-size-calculator`
- `https://forex-calculator-pro.onrender.com/pip-calculator`
- `https://forex-calculator-pro.onrender.com/profit-calculator`

Your professional forex calculator platform is earning money! 🎯