import { type CurrencyPair, type InsertCurrencyPair, type CalculatorResult, type InsertCalculatorResult, type User, type InsertUser } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Currency pair methods
  getCurrencyPair(symbol: string): Promise<CurrencyPair | undefined>;
  getAllCurrencyPairs(): Promise<CurrencyPair[]>;
  updateCurrencyPair(symbol: string, data: Partial<InsertCurrencyPair>): Promise<CurrencyPair | undefined>;
  createCurrencyPair(pair: InsertCurrencyPair & { id: string }): Promise<CurrencyPair>;
  
  // Calculator results methods
  saveCalculatorResult(result: InsertCalculatorResult): Promise<CalculatorResult>;
  getCalculatorResults(calculatorType: string, limit?: number): Promise<CalculatorResult[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private currencyPairs: Map<string, CurrencyPair>;
  private calculatorResults: Map<string, CalculatorResult>;

  constructor() {
    this.users = new Map();
    this.currencyPairs = new Map();
    this.calculatorResults = new Map();
    
    // Initialize with major currency pairs
    this.initializeCurrencyPairs();
  }

  private initializeCurrencyPairs() {
    // Comprehensive trading instruments with sample rates
    const allInstruments = [
      // Major Forex Pairs
      { symbol: "EUR/USD", baseCurrency: "EUR", quoteCurrency: "USD", rate: "1.10250" },
      { symbol: "GBP/USD", baseCurrency: "GBP", quoteCurrency: "USD", rate: "1.26500" },
      { symbol: "USD/JPY", baseCurrency: "USD", quoteCurrency: "JPY", rate: "149.82000" },
      { symbol: "USD/CHF", baseCurrency: "USD", quoteCurrency: "CHF", rate: "0.88750" },
      { symbol: "AUD/USD", baseCurrency: "AUD", quoteCurrency: "USD", rate: "0.67800" },
      { symbol: "USD/CAD", baseCurrency: "USD", quoteCurrency: "CAD", rate: "1.35200" },
      { symbol: "NZD/USD", baseCurrency: "NZD", quoteCurrency: "USD", rate: "0.62100" },
      
      // Minor Forex Pairs  
      { symbol: "EUR/GBP", baseCurrency: "EUR", quoteCurrency: "GBP", rate: "0.87150" },
      { symbol: "EUR/CHF", baseCurrency: "EUR", quoteCurrency: "CHF", rate: "0.97850" },
      { symbol: "EUR/JPY", baseCurrency: "EUR", quoteCurrency: "JPY", rate: "165.20000" },
      { symbol: "EUR/AUD", baseCurrency: "EUR", quoteCurrency: "AUD", rate: "1.62600" },
      { symbol: "EUR/CAD", baseCurrency: "EUR", quoteCurrency: "CAD", rate: "1.49100" },
      { symbol: "EUR/NZD", baseCurrency: "EUR", quoteCurrency: "NZD", rate: "1.77600" },
      { symbol: "GBP/CHF", baseCurrency: "GBP", quoteCurrency: "CHF", rate: "1.12250" },
      { symbol: "GBP/JPY", baseCurrency: "GBP", quoteCurrency: "JPY", rate: "189.56000" },
      { symbol: "GBP/AUD", baseCurrency: "GBP", quoteCurrency: "AUD", rate: "1.86500" },
      { symbol: "GBP/CAD", baseCurrency: "GBP", quoteCurrency: "CAD", rate: "1.71000" },
      { symbol: "GBP/NZD", baseCurrency: "GBP", quoteCurrency: "NZD", rate: "2.03700" },
      { symbol: "AUD/CHF", baseCurrency: "AUD", quoteCurrency: "CHF", rate: "0.60200" },
      { symbol: "AUD/JPY", baseCurrency: "AUD", quoteCurrency: "JPY", rate: "101.58000" },
      { symbol: "AUD/CAD", baseCurrency: "AUD", quoteCurrency: "CAD", rate: "0.91700" },
      { symbol: "AUD/NZD", baseCurrency: "AUD", quoteCurrency: "NZD", rate: "1.09200" },
      { symbol: "CAD/CHF", baseCurrency: "CAD", quoteCurrency: "CHF", rate: "0.65650" },
      { symbol: "CAD/JPY", baseCurrency: "CAD", quoteCurrency: "JPY", rate: "110.82000" },
      { symbol: "CHF/JPY", baseCurrency: "CHF", quoteCurrency: "JPY", rate: "168.92000" },
      { symbol: "NZD/CHF", baseCurrency: "NZD", quoteCurrency: "CHF", rate: "0.55100" },
      { symbol: "NZD/CAD", baseCurrency: "NZD", quoteCurrency: "CAD", rate: "0.84000" },
      { symbol: "NZD/JPY", baseCurrency: "NZD", quoteCurrency: "JPY", rate: "93.02000" },
      
      // Exotic Pairs
      { symbol: "USD/ZAR", baseCurrency: "USD", quoteCurrency: "ZAR", rate: "18.45000" },
      { symbol: "USD/MXN", baseCurrency: "USD", quoteCurrency: "MXN", rate: "17.25000" },
      { symbol: "USD/SGD", baseCurrency: "USD", quoteCurrency: "SGD", rate: "1.34500" },
      { symbol: "USD/HKD", baseCurrency: "USD", quoteCurrency: "HKD", rate: "7.82500" },
      { symbol: "USD/NOK", baseCurrency: "USD", quoteCurrency: "NOK", rate: "10.85000" },
      { symbol: "USD/SEK", baseCurrency: "USD", quoteCurrency: "SEK", rate: "10.45000" },
      { symbol: "USD/DKK", baseCurrency: "USD", quoteCurrency: "DKK", rate: "6.98000" },
      { symbol: "USD/TRY", baseCurrency: "USD", quoteCurrency: "TRY", rate: "32.45000" },
      { symbol: "USD/PLN", baseCurrency: "USD", quoteCurrency: "PLN", rate: "4.02500" },
      { symbol: "USD/CZK", baseCurrency: "USD", quoteCurrency: "CZK", rate: "22.85000" },
      { symbol: "USD/HUF", baseCurrency: "USD", quoteCurrency: "HUF", rate: "365.50000" },
      { symbol: "USD/RUB", baseCurrency: "USD", quoteCurrency: "RUB", rate: "92.75000" },
      { symbol: "USD/BRL", baseCurrency: "USD", quoteCurrency: "BRL", rate: "5.15000" },
      { symbol: "USD/INR", baseCurrency: "USD", quoteCurrency: "INR", rate: "83.25000" },
      { symbol: "USD/CNY", baseCurrency: "USD", quoteCurrency: "CNY", rate: "7.32000" },
      { symbol: "USD/KRW", baseCurrency: "USD", quoteCurrency: "KRW", rate: "1325.50000" },
      { symbol: "USD/THB", baseCurrency: "USD", quoteCurrency: "THB", rate: "36.45000" },
      
      // Precious Metals
      { symbol: "XAUUSD", baseCurrency: "XAU", quoteCurrency: "USD", rate: "2045.50000" },
      { symbol: "XAGUSD", baseCurrency: "XAG", quoteCurrency: "USD", rate: "24.85000" },
      { symbol: "XPTUSD", baseCurrency: "XPT", quoteCurrency: "USD", rate: "995.50000" },
      { symbol: "XPDUSD", baseCurrency: "XPD", quoteCurrency: "USD", rate: "1125.00000" },
      { symbol: "XAUEUR", baseCurrency: "XAU", quoteCurrency: "EUR", rate: "1855.20000" },
      { symbol: "XAUGBP", baseCurrency: "XAU", quoteCurrency: "GBP", rate: "1618.75000" },
      { symbol: "XAUJPY", baseCurrency: "XAU", quoteCurrency: "JPY", rate: "306425.00000" },
      
      // Energy Commodities
      { symbol: "USOIL", baseCurrency: "USO", quoteCurrency: "USD", rate: "78.45000" },
      { symbol: "UKOIL", baseCurrency: "UKO", quoteCurrency: "USD", rate: "82.15000" },
      { symbol: "NGAS", baseCurrency: "NGA", quoteCurrency: "USD", rate: "2.68500" },
      { symbol: "XNGUSD", baseCurrency: "XNG", quoteCurrency: "USD", rate: "2.72000" },
      
      // Major Stock Indices
      { symbol: "US100", baseCurrency: "US1", quoteCurrency: "USD", rate: "15845.50000" },
      { symbol: "US30", baseCurrency: "US3", quoteCurrency: "USD", rate: "37250.00000" },
      { symbol: "SPX500", baseCurrency: "SPX", quoteCurrency: "USD", rate: "4785.25000" },
      { symbol: "UK100", baseCurrency: "UK1", quoteCurrency: "GBP", rate: "7525.50000" },
      { symbol: "GER40", baseCurrency: "GER", quoteCurrency: "EUR", rate: "16485.75000" },
      { symbol: "FRA40", baseCurrency: "FRA", quoteCurrency: "EUR", rate: "7285.50000" },
      { symbol: "JPN225", baseCurrency: "JPN", quoteCurrency: "JPY", rate: "33245.75000" },
      { symbol: "AUS200", baseCurrency: "AUS", quoteCurrency: "AUD", rate: "7285.25000" },
      { symbol: "HK50", baseCurrency: "HK5", quoteCurrency: "HKD", rate: "17525.50000" },
      
      // Major Cryptocurrencies
      { symbol: "BTCUSD", baseCurrency: "BTC", quoteCurrency: "USD", rate: "67845.50000" },
      { symbol: "ETHUSD", baseCurrency: "ETH", quoteCurrency: "USD", rate: "3285.75000" },
      { symbol: "BNBUSD", baseCurrency: "BNB", quoteCurrency: "USD", rate: "325.50000" },
      { symbol: "ADAUSD", baseCurrency: "ADA", quoteCurrency: "USD", rate: "0.48500" },
      { symbol: "DOTUSD", baseCurrency: "DOT", quoteCurrency: "USD", rate: "7.25000" },
      { symbol: "XRPUSD", baseCurrency: "XRP", quoteCurrency: "USD", rate: "0.58500" },
      { symbol: "LTCUSD", baseCurrency: "LTC", quoteCurrency: "USD", rate: "82.45000" },
      { symbol: "SOLUSD", baseCurrency: "SOL", quoteCurrency: "USD", rate: "155.75000" },
    ];

    allInstruments.forEach(instrument => {
      const currencyPair: CurrencyPair = {
        id: instrument.symbol.replace("/", ""),
        symbol: instrument.symbol,
        baseCurrency: instrument.baseCurrency,
        quoteCurrency: instrument.quoteCurrency,
        rate: instrument.rate,
        lastUpdated: new Date(),
        isActive: true,
      };
      this.currencyPairs.set(instrument.symbol, currencyPair);
    });
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Currency pair methods
  async getCurrencyPair(symbol: string): Promise<CurrencyPair | undefined> {
    return this.currencyPairs.get(symbol);
  }

  async getAllCurrencyPairs(): Promise<CurrencyPair[]> {
    return Array.from(this.currencyPairs.values()).filter(pair => pair.isActive);
  }

  async updateCurrencyPair(symbol: string, data: Partial<InsertCurrencyPair>): Promise<CurrencyPair | undefined> {
    const existing = this.currencyPairs.get(symbol);
    if (!existing) return undefined;
    
    const updated: CurrencyPair = {
      ...existing,
      ...data,
      lastUpdated: new Date(),
    };
    this.currencyPairs.set(symbol, updated);
    return updated;
  }

  async createCurrencyPair(pair: InsertCurrencyPair & { id: string }): Promise<CurrencyPair> {
    const currencyPair: CurrencyPair = {
      ...pair,
      lastUpdated: new Date(),
      isActive: true,
    };
    this.currencyPairs.set(pair.symbol, currencyPair);
    return currencyPair;
  }

  // Calculator results methods
  async saveCalculatorResult(result: InsertCalculatorResult): Promise<CalculatorResult> {
    const id = randomUUID();
    const calculatorResult: CalculatorResult = {
      ...result,
      id,
      createdAt: new Date(),
    };
    this.calculatorResults.set(id, calculatorResult);
    return calculatorResult;
  }

  async getCalculatorResults(calculatorType: string, limit: number = 10): Promise<CalculatorResult[]> {
    const results = Array.from(this.calculatorResults.values())
      .filter(result => result.calculatorType === calculatorType)
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime())
      .slice(0, limit);
    return results;
  }
}

export const storage = new MemStorage();
