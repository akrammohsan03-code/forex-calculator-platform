// Forex Calculator WordPress Plugin JavaScript

jQuery(document).ready(function($) {
    
    // Position Size Calculator
    window.calculatePositionSize = function() {
        const accountBalance = parseFloat($('#account-balance').val());
        const riskPercentage = parseFloat($('#risk-percentage').val());
        const stopLossPips = parseFloat($('#stop-loss-pips').val());
        const currencyPair = $('#currency-pair').val();
        const entryPrice = parseFloat($('#entry-price').val());
        
        if (!accountBalance || !riskPercentage || !stopLossPips) {
            alert('Please fill in all required fields');
            return;
        }
        
        // Calculate position size
        const riskAmount = (accountBalance * riskPercentage) / 100;
        const pipValue = getPipValue(currencyPair, 1.0);
        const lotSize = riskAmount / (stopLossPips * pipValue);
        const units = lotSize * 100000;
        
        // Display results
        $('#lot-size').text(lotSize.toFixed(2));
        $('#units').text(Math.round(units).toLocaleString());
        $('#money-at-risk').text('$' + riskAmount.toFixed(2));
        $('#pip-value').text('$' + pipValue.toFixed(2));
        $('#position-size-results').slideDown();
    };
    
    // Pip Calculator
    window.calculatePipValue = function() {
        const currencyPair = $('#pip-currency-pair').val();
        const lotSize = parseFloat($('#pip-lot-size').val());
        
        if (!lotSize) {
            alert('Please enter lot size');
            return;
        }
        
        const pipValue = getPipValue(currencyPair, lotSize);
        
        $('#pip-result-value').text('$' + pipValue.toFixed(2));
        $('#pip-results').slideDown();
    };
    
    // Profit Calculator
    window.calculateProfit = function() {
        const currencyPair = $('#profit-currency-pair').val();
        const tradeType = $('#trade-type').val();
        const lotSize = parseFloat($('#lot-size-profit').val());
        const openPrice = parseFloat($('#open-price').val());
        const closePrice = parseFloat($('#close-price').val());
        
        if (!lotSize || !openPrice || !closePrice) {
            alert('Please fill in all fields');
            return;
        }
        
        let pipDifference;
        if (tradeType === 'buy') {
            pipDifference = (closePrice - openPrice) * 10000;
        } else {
            pipDifference = (openPrice - closePrice) * 10000;
        }
        
        const pipValue = getPipValue(currencyPair, lotSize);
        const profit = pipDifference * pipValue / 10;
        
        $('#profit-pips').text(pipDifference.toFixed(1));
        $('#profit-amount').text('$' + profit.toFixed(2));
        $('#profit-results').slideDown();
    };
    
    // Margin Calculator
    window.calculateMargin = function() {
        const currencyPair = $('#margin-currency-pair').val();
        const lotSize = parseFloat($('#margin-lot-size').val());
        const leverage = parseFloat($('#leverage').val());
        
        if (!lotSize || !leverage) {
            alert('Please fill in all fields');
            return;
        }
        
        const contractSize = lotSize * 100000;
        const exchangeRate = getExchangeRate(currencyPair);
        const margin = (contractSize * exchangeRate) / leverage;
        
        $('#required-margin').text('$' + margin.toFixed(2));
        $('#margin-results').slideDown();
    };
    
    // Currency Converter
    window.convertCurrency = function() {
        const fromCurrency = $('#from-currency').val();
        const toCurrency = $('#to-currency').val();
        const amount = parseFloat($('#amount').val());
        
        if (!amount) {
            alert('Please enter amount');
            return;
        }
        
        const pair = fromCurrency + toCurrency;
        const rate = getExchangeRate(pair);
        const convertedAmount = amount * rate;
        
        $('#converted-amount').text(convertedAmount.toFixed(2) + ' ' + toCurrency);
        $('#exchange-rate').text(rate.toFixed(4));
        $('#converter-results').slideDown();
    };
    
    // Helper function to get pip value
    function getPipValue(pair, lotSize) {
        const pipValues = {
            'EURUSD': 10,
            'GBPUSD': 10,
            'USDJPY': 6.69,
            'USDCHF': 11.05,
            'AUDUSD': 10,
            'USDCAD': 7.52,
            'NZDUSD': 10
        };
        
        return (pipValues[pair] || 10) * lotSize;
    }
    
    // Helper function to get exchange rate
    function getExchangeRate(pair) {
        const rates = {
            'EURUSD': 1.0850,
            'GBPUSD': 1.2650,
            'USDJPY': 149.50,
            'USDCHF': 0.9050,
            'AUDUSD': 0.6550,
            'USDCAD': 1.3650,
            'NZDUSD': 0.6050,
            'USDEUR': 0.9217,
            'USDGBP': 0.7905,
            'JPYUSD': 0.0067,
            'CHFUSD': 1.1050,
            'CADUSD': 0.7326,
            'EURUSD': 1.0850,
            'EURGBP': 0.8580,
            'EURJPY': 162.50,
            'GBPJPY': 189.40
        };
        
        return rates[pair] || 1.0;
    }
    
    // Add loading states to buttons
    $('body').on('click', '.calculate-btn', function() {
        $(this).addClass('loading').text('Calculating...');
        
        setTimeout(() => {
            $(this).removeClass('loading').text($(this).data('original-text') || 'Calculate');
        }, 1000);
    });
    
    // Store original button text
    $('.calculate-btn').each(function() {
        $(this).data('original-text', $(this).text());
    });
    
});