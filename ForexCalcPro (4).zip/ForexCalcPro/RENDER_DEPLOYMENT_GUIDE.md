# Render Deployment Guide - Forex Calculator Platform

## 🚀 **Why Render for Your Forex Calculators?**

- **Free tier available** with paid plans starting at $7/month
- **Automatic deployments** from GitHub
- **Built-in SSL certificates** (HTTPS)
- **Easy Node.js hosting** with zero configuration
- **Better than Replit pricing** for production apps

## 📋 **Step-by-Step Deployment Process**

### **Phase 1: Prepare Your Code (5 minutes)**

#### **Step 1.1: Download Your Project**
1. **In Replit**: Click **3 dots menu (⋮)** → **"Download as ZIP"**
2. **Extract ZIP** file on your computer
3. **Open the extracted folder**

#### **Step 1.2: Create Package.json for Production**
Create a new file called `package.json` in your project root:

```json
{
  "name": "forex-calculator-platform",
  "version": "1.0.0",
  "description": "Professional forex trading calculators",
  "main": "dist/index.js",
  "scripts": {
    "start": "node dist/index.js",
    "build": "npm run build:server && npm run build:client",
    "build:server": "esbuild server/index.ts --bundle --platform=node --outfile=dist/index.js --external:express --external:tsx",
    "build:client": "vite build --outDir=dist/public",
    "postinstall": "npm run build"
  },
  "dependencies": {
    "express": "^4.18.2",
    "typescript": "^5.0.0",
    "vite": "^4.4.0",
    "@vitejs/plugin-react": "^4.0.0"
  },
  "engines": {
    "node": "18.x"
  }
}
```

#### **Step 1.3: Create Render Build Script**
Create `render-build.sh` file:

```bash
#!/bin/bash
# Install dependencies
npm install

# Build the application
npm run build

# Ensure the dist directory exists
mkdir -p dist/public

echo "Build completed successfully!"
```

### **Phase 2: Set Up GitHub Repository (10 minutes)**

#### **Step 2.1: Create GitHub Account**
1. **Go to**: `https://github.com`
2. **Sign up** for free account (if you don't have one)
3. **Verify your email**

#### **Step 2.2: Create New Repository**
1. **Click "+" icon** → **"New repository"**
2. **Repository name**: `forex-calculator-platform`
3. **Description**: `Professional forex trading calculators with real-time data`
4. **Set to Public** (required for free Render)
5. **Click "Create repository"**

#### **Step 2.3: Upload Your Code**
**Method A: GitHub Web Interface**
1. **Click "uploading an existing file"**
2. **Drag and drop** all your project files
3. **Commit message**: `Initial forex calculator platform`
4. **Click "Commit changes"**

**Method B: Git Commands (if you have Git installed)**
```bash
git init
git add .
git commit -m "Initial forex calculator platform"
git branch -M main
git remote add origin https://github.com/YOURUSERNAME/forex-calculator-platform.git
git push -u origin main
```

### **Phase 3: Deploy to Render (5 minutes)**

#### **Step 3.1: Create Render Account**
1. **Go to**: `https://render.com`
2. **Click "Get Started for Free"**
3. **Sign up with GitHub** (easiest option)
4. **Authorize Render** to access your repositories

#### **Step 3.2: Create New Web Service**
1. **Click "New +"** → **"Web Service"**
2. **Connect GitHub repository**: Select `forex-calculator-platform`
3. **Service name**: `forex-calculator-pro`
4. **Region**: Choose closest to your target audience
5. **Branch**: `main`
6. **Runtime**: `Node`

#### **Step 3.3: Configure Build Settings**
```
Build Command: chmod +x render-build.sh && ./render-build.sh
Start Command: npm start
```

#### **Step 3.4: Set Environment Variables**
**In Render dashboard, add these environment variables:**
```
NODE_ENV=production
PORT=10000
VITE_GOOGLE_ADSENSE_CLIENT=ca-pub-XXXXXXXXXX
```
*Replace XXXXXXXXXX with your actual Google AdSense Publisher ID*

#### **Step 3.5: Choose Plan**
- **Free Plan**: $0/month (good for testing)
  - 750 hours/month
  - Sleeps after 15 minutes of inactivity
  - Custom domain not included

- **Starter Plan**: $7/month (recommended for production)
  - Always-on service
  - Custom domain included
  - Better performance

#### **Step 3.6: Deploy**
1. **Click "Create Web Service"**
2. **Wait for deployment** (usually 5-10 minutes)
3. **Monitor build logs** for any errors

### **Phase 4: Configure Domain & SSL (5 minutes)**

#### **Step 4.1: Get Your Render URL**
After deployment, you'll get a URL like:
`https://forex-calculator-pro.onrender.com`

#### **Step 4.2: Add Custom Domain (Optional)**
**If you have your own domain:**
1. **In Render dashboard** → **Settings** → **Custom Domains**
2. **Add domain**: `yourdomain.com`
3. **Update DNS records** at your domain registrar:
   ```
   Type: CNAME
   Name: www
   Value: forex-calculator-pro.onrender.com
   
   Type: A
   Name: @
   Value: 216.24.57.1
   ```
4. **SSL certificate** is automatically provided

### **Phase 5: Update WordPress Integration (3 minutes)**

#### **Step 5.1: Update Iframe URLs**
**In your WordPress pages, replace:**
- **FROM**: `https://your-project.replit.app/position-size-calculator`
- **TO**: `https://forex-calculator-pro.onrender.com/position-size-calculator`

#### **Step 5.2: Test All Calculators**
Verify these URLs work:
- `https://forex-calculator-pro.onrender.com/position-size-calculator`
- `https://forex-calculator-pro.onrender.com/pip-calculator`
- `https://forex-calculator-pro.onrender.com/profit-calculator`
- `https://forex-calculator-pro.onrender.com/margin-calculator`

### **Phase 6: Optimize Performance (5 minutes)**

#### **Step 6.1: Enable Auto-Deploy**
**In Render dashboard:**
1. **Settings** → **Build & Deploy**
2. **Enable "Auto-Deploy"**
3. **Now every GitHub push** automatically deploys

#### **Step 6.2: Monitor Performance**
**Render provides:**
- Real-time logs
- Performance metrics
- Uptime monitoring
- Error tracking

#### **Step 6.3: Set Up Health Checks**
Your app already includes a `/health` endpoint that Render will use for monitoring.

## 🔧 **Troubleshooting**

### **Build Fails?**
**Check these common issues:**
1. **Node version**: Ensure `package.json` specifies Node 18.x
2. **Dependencies**: Make sure all required packages are listed
3. **Build command**: Verify `render-build.sh` has execute permissions
4. **Environment variables**: Check all required vars are set

### **App Doesn't Load?**
1. **Check logs** in Render dashboard
2. **Verify start command**: Should be `npm start`
3. **Port binding**: App should listen on `process.env.PORT`
4. **Health check**: Ensure `/health` endpoint responds

### **SSL Issues?**
1. **Custom domain**: DNS propagation can take 24-48 hours
2. **Certificate**: Render auto-generates SSL certificates
3. **HTTPS redirect**: Render handles this automatically

### **Performance Issues?**
1. **Upgrade plan**: Free tier has limitations
2. **Cold starts**: Free tier sleeps after 15 minutes
3. **Memory**: Monitor usage in dashboard
4. **Database**: Consider upgrading to persistent storage

## 💰 **Cost Comparison**

### **Render Pricing:**
- **Free**: $0/month (limited)
- **Starter**: $7/month (recommended)
- **Standard**: $25/month (high traffic)

### **vs Replit:**
- **Replit Hacker**: $20/month
- **Render Starter**: $7/month
- **Savings**: $13/month ($156/year)

### **Revenue Potential:**
- **Conservative**: $200-500/month
- **Optimistic**: $1000-3000/month
- **ROI on $7 hosting**: 2800%+

## 📊 **Deployment Checklist**

**Pre-Deployment:**
- ✅ Code downloaded from Replit
- ✅ `package.json` created with correct scripts
- ✅ GitHub repository created and code uploaded
- ✅ Render account created and connected to GitHub

**During Deployment:**
- ✅ Web service created with correct settings
- ✅ Environment variables configured
- ✅ Build command set: `chmod +x render-build.sh && ./render-build.sh`
- ✅ Start command set: `npm start`
- ✅ Plan selected (Free for testing, Starter for production)

**Post-Deployment:**
- ✅ Application accessible at Render URL
- ✅ All calculators tested and working
- ✅ WordPress iframe URLs updated
- ✅ Custom domain configured (if applicable)
- ✅ Auto-deploy enabled for future updates

**Monetization:**
- ✅ Google AdSense publisher ID configured
- ✅ Ad placements tested and displaying
- ✅ Analytics tracking set up
- ✅ Performance monitoring active

## 🎯 **Success Metrics**

After successful deployment on Render:
- **Fast loading times** (< 2 seconds globally)
- **99.9% uptime** with automatic health checks
- **HTTPS security** with auto-renewed certificates
- **Automatic deployments** from GitHub updates
- **Professional domain** (optional custom domain)
- **Cost-effective hosting** at $7/month vs $20/month

## 🔄 **Future Updates**

**To update your app:**
1. **Make changes** in your local code
2. **Push to GitHub** (via web interface or Git)
3. **Render automatically deploys** new version
4. **Zero downtime** during updates

## 📞 **Support Resources**

### **Render Resources:**
- **Documentation**: `https://render.com/docs`
- **Community**: `https://community.render.com`
- **Support**: Available via dashboard chat

### **GitHub Resources:**
- **Documentation**: `https://docs.github.com`
- **Community**: Large developer community
- **Free tier**: Unlimited public repositories

Your professional forex calculator platform is now ready for cost-effective deployment on Render! This setup provides better performance and lower costs compared to Replit while maintaining all functionality.

## 💡 **Pro Tips**

1. **Use Free Tier First**: Test everything on free plan before upgrading
2. **Monitor Usage**: Check Render dashboard for performance metrics
3. **Optimize Images**: Compress any assets for faster loading
4. **Enable Caching**: Set up browser caching for static assets
5. **Regular Updates**: Keep dependencies updated for security

Your forex calculator platform will be live and earning money on Render! 🚀