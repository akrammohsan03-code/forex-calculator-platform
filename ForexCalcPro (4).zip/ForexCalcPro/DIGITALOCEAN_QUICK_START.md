# DigitalOcean Quick Start - Forex Calculator Deployment

## 🚀 30-Minute Deployment Guide

### Step 1: Create DigitalOcean Account (5 minutes)
1. Go to `https://www.digitalocean.com`
2. Sign up with email
3. Add payment method
4. **Get $200 free credit** with referral link

### Step 2: Create Droplet (3 minutes)
1. Click **"Create"** → **"Droplets"**
2. **Image**: Ubuntu 22.04 LTS
3. **Plan**: Basic $6/month (1GB RAM)
4. **Authentication**: Add SSH key or password
5. **Hostname**: forex-calculator
6. Click **"Create Droplet"**

### Step 3: Server Setup (10 minutes)
```bash
# SSH into your server
ssh root@YOUR_DROPLET_IP

# Install Node.js and tools
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
apt-get install -y nodejs nginx git ufw

# Configure firewall
ufw allow ssh && ufw allow 'Nginx Full' && ufw enable
```

### Step 4: Deploy Your App (7 minutes)
```bash
# Create app directory
mkdir /var/www/forex-calculator
cd /var/www/forex-calculator

# Upload your files (use FileZilla/SCP)
# Then install dependencies
npm install
npm run build

# Install PM2 and start app
npm install -g pm2
pm2 start server/index.ts --name "forex-calculator"
pm2 save && pm2 startup
```

### Step 5: Configure Nginx (3 minutes)
```bash
# Create Nginx config
cat > /etc/nginx/sites-available/forex-calculator << 'EOF'
server {
    listen 80;
    server_name your-domain.com www.your-domain.com;
    
    location / {
        proxy_pass http://localhost:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
EOF

# Enable site
ln -s /etc/nginx/sites-available/forex-calculator /etc/nginx/sites-enabled/
systemctl restart nginx
```

### Step 6: Point Domain & SSL (2 minutes)
```bash
# Install SSL certificate
certbot --nginx -d your-domain.com -d www.your-domain.com
```

**Point your domain nameservers to:**
- `ns1.digitalocean.com`
- `ns2.digitalocean.com` 
- `ns3.digitalocean.com`

## ✅ Done!

Your forex calculators are now live at `https://your-domain.com`

**Total Cost**: $6/month
**Expected Revenue**: $200-1000+/month
**ROI**: 1600%+ return on investment

## 🔄 Update WordPress
Replace all iframe URLs from:
`https://replit-url.app` → `https://your-domain.com`

Your professional forex calculator platform is earning money! 🎯