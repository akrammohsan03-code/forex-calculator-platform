// Move this file - it was created in wrong location

export const useAnalytics = () => {
  const [location] = useLocation();
  const prevLocationRef = useRef<string>(location);
  
  useEffect(() => {
    // Track page view when location changes
    if (location !== prevLocationRef.current) {
      // Get page title based on route
      const pageTitle = getPageTitle(location);
      trackPageView(location, pageTitle);
      prevLocationRef.current = location;
    }
  }, [location]);
};

// Helper function to get page titles for better analytics
const getPageTitle = (path: string): string => {
  const titles: Record<string, string> = {
    '/': 'Forex Calculator Platform - Professional Trading Tools',
    '/position-size-calculator': 'Position Size Calculator - Risk Management Tool',
    '/pip-calculator': 'Pip Calculator - Forex Pip Value Calculator',
    '/profit-calculator': 'Profit Calculator - Trading P&L Calculator',
    '/margin-calculator': 'Margin Calculator - Required Margin Tool',
    '/currency-converter': 'Currency Converter - Live Exchange Rates',
    '/drawdown-calculator': 'Drawdown Calculator - Portfolio Risk Analysis',
    '/fibonacci-calculator': 'Fibonacci Calculator - Technical Analysis Tool',
    '/pivot-calculator': 'Pivot Point Calculator - Support & Resistance',
    '/compounding-calculator': 'Compound Interest Calculator - Investment Growth',
    '/risk-of-ruin-calculator': 'Risk of Ruin Calculator - Bankruptcy Probability',
    '/crypto-fees-calculator': 'Crypto Fees Calculator - Transaction Cost Tool',
    '/forex-charts': 'Live Forex Charts - Real-time Market Data',
    '/forex-news': 'Forex News - Latest Market Updates',
    '/economic-calendar': 'Economic Calendar - Market Events',
    '/about-us': 'About Us - Professional Forex Tools',
    '/contact-us': 'Contact Us - Get in Touch',
    '/privacy-policy': 'Privacy Policy',
    '/terms-of-service': 'Terms of Service',
    '/disclaimer': 'Disclaimer - Trading Risk Notice'
  };
  
  return titles[path] || 'Forex Calculator Platform';
};