import { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown, Radio } from 'lucide-react';

interface AnimatedRateDisplayProps {
  rate: string | number;
  symbol?: string;
  size?: 'sm' | 'md' | 'lg';
  showTrend?: boolean;
  className?: string;
}

export default function AnimatedRateDisplay({ 
  rate, 
  symbol, 
  size = 'md', 
  showTrend = true,
  className = '' 
}: AnimatedRateDisplayProps) {
  const [isAnimating, setIsAnimating] = useState(false);
  const [previousRate, setPreviousRate] = useState<number | null>(null);
  const [trend, setTrend] = useState<'up' | 'down' | 'neutral'>('neutral');

  const currentRate = parseFloat(rate.toString());

  useEffect(() => {
    if (previousRate !== null && currentRate !== previousRate) {
      setIsAnimating(true);
      setTrend(currentRate > previousRate ? 'up' : 'down');
      
      const timer = setTimeout(() => {
        setIsAnimating(false);
      }, 1000);
      
      return () => clearTimeout(timer);
    }
    setPreviousRate(currentRate);
  }, [currentRate, previousRate]);

  const sizeClasses = {
    sm: 'text-sm',
    md: 'text-base',
    lg: 'text-lg'
  };

  const trendColor = trend === 'up' ? 'text-green-600' : trend === 'down' ? 'text-red-600' : 'text-gray-600';

  return (
    <div className={`flex items-center space-x-2 ${className}`}>
      {symbol && (
        <span className="font-semibold text-navy-700">{symbol}</span>
      )}
      
      <span 
        className={`font-mono transition-all duration-300 ${sizeClasses[size]} ${
          isAnimating 
            ? trend === 'up' 
              ? 'text-green-600 scale-105 font-bold rate-flash-up' 
              : trend === 'down'
              ? 'text-red-600 scale-105 font-bold rate-flash-down'
              : 'text-gray-700 scale-105 rate-pulse'
            : 'text-gray-700'
        }`}
      >
        {rate.toString()}
      </span>

      {showTrend && (
        <div className={`flex items-center transition-all duration-300 ${trendColor} ${
          isAnimating ? 'scale-125' : ''
        }`}>
          {trend === 'up' ? (
            <TrendingUp className="w-4 h-4" />
          ) : trend === 'down' ? (
            <TrendingDown className="w-4 h-4" />
          ) : (
            <Radio className={`w-3 h-3 ${isAnimating ? 'animate-ping' : ''}`} />
          )}
        </div>
      )}

      {/* Live pulse indicator */}
      {isAnimating && (
        <div className={`w-2 h-2 rounded-full animate-ping ${
          trend === 'up' ? 'bg-green-400' : trend === 'down' ? 'bg-red-400' : 'bg-blue-400'
        }`}></div>
      )}
    </div>
  );
}