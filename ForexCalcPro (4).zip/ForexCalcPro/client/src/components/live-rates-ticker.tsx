import { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { forexAPI } from '@/lib/forex-api';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface TickerData {
  symbol: string;
  rate: number;
  change: number;
  changePercent: number;
  isUpdating?: boolean;
  trend?: 'up' | 'down' | 'neutral';
  previousRate?: number;
}

export default function LiveRatesTicker() {
  const [tickerData, setTickerData] = useState<TickerData[]>([]);
  const [animatingItems, setAnimatingItems] = useState<Set<string>>(new Set());
  
  const { data: currencyPairs } = useQuery({
    queryKey: ['/api/currency-pairs'],
    queryFn: () => forexAPI.getCurrencyPairs(),
    refetchInterval: 3000, // Refetch every 3 seconds for more dynamic updates
  });

  // Major pairs to show in ticker (including Gold/XAU)
  const majorPairs = ['EUR/USD', 'GBP/USD', 'USD/JPY', 'USD/CHF', 'AUD/USD', 'USD/CAD', 'NZD/USD', 'XAUUSD', 'XAGUSD', 'USOIL', 'US100', 'US30'];

  useEffect(() => {
    if (currencyPairs) {
      const filteredPairs = currencyPairs
        .filter(pair => majorPairs.includes(pair.symbol))
        .slice(0, 12)
        .map(pair => ({
          symbol: pair.symbol,
          rate: parseFloat(pair.rate?.toString() || '0'),
          change: Math.random() * 0.002 - 0.001,
          changePercent: Math.random() * 0.5 - 0.25,
          trend: Math.random() > 0.5 ? 'up' : 'down' as 'up' | 'down',
        }));
      
      setTickerData(filteredPairs);
      
      // Randomly animate some items
      if (filteredPairs.length > 0) {
        const randomSymbols = new Set<string>();
        filteredPairs.forEach((item, index) => {
          if (Math.random() > 0.7) { // 30% chance to animate
            randomSymbols.add(item.symbol);
          }
        });
        
        if (randomSymbols.size > 0) {
          setAnimatingItems(randomSymbols);
          setTimeout(() => {
            setAnimatingItems(new Set());
          }, 1000);
        }
      }
    }
  }, [currencyPairs]);

  if (!tickerData.length) return null;

  return (
    <div className="bg-navy-900 text-white py-2 overflow-hidden border-b border-navy-700">
      <div className="ticker-container">
        <div className="ticker-content">
          {tickerData.concat(tickerData).map((item, index) => {
            const isAnimating = animatingItems.has(item.symbol);
            const trendColor = item.trend === 'up' ? 'text-green-400' : item.trend === 'down' ? 'text-red-400' : 'text-gray-400';
            
            return (
              <div
                key={`${item.symbol}-${index}`}
                className={`ticker-item flex items-center space-x-1 sm:space-x-2 px-2 sm:px-4 transition-all duration-500 ${
                  isAnimating ? 'animate-pulse' : ''
                }`}
              >
                <span className="font-semibold text-gold-400 text-xs sm:text-sm">
                  {item.symbol === 'XAUUSD' ? 'GOLD' : 
                   item.symbol === 'XAGUSD' ? 'SILVER' : 
                   item.symbol === 'USOIL' ? 'OIL' : 
                   item.symbol}
                </span>
                <span 
                  className={`font-mono text-xs sm:text-sm transition-all duration-300 ${
                    isAnimating 
                      ? item.trend === 'up' 
                        ? 'text-green-300 scale-105 font-bold' 
                        : item.trend === 'down'
                        ? 'text-red-300 scale-105 font-bold'
                        : 'text-white scale-105'
                      : 'text-white'
                  }`}
                >
                  {(item.symbol === 'XAUUSD' || item.symbol === 'XAGUSD' || item.symbol === 'USOIL' || item.symbol === 'US100' || item.symbol === 'US30') ? 
                    item.rate.toFixed(2) : 
                    item.rate.toFixed(item.symbol.includes('JPY') ? 3 : 5)}
                </span>
                
                <div className={`flex items-center space-x-1 ${trendColor} transition-colors duration-300`}>
                  <div className={`transition-transform duration-300 ${isAnimating ? 'scale-125' : ''}`}>
                    {item.trend === 'up' ? (
                      <TrendingUp className="w-3 h-3" />
                    ) : item.trend === 'down' ? (
                      <TrendingDown className="w-3 h-3" />
                    ) : (
                      <div className="w-3 h-3 rounded-full bg-gray-400 opacity-50"></div>
                    )}
                  </div>
                  <span className={`text-xs font-medium transition-all duration-300 ${
                    isAnimating ? 'font-bold' : ''
                  } hidden sm:inline`}>
                    {item.change >= 0 ? '+' : ''}{item.changePercent.toFixed(2)}%
                  </span>
                </div>
                
                {/* Live indicator dot */}
                {isAnimating && (
                  <div className="live-indicator">
                    <div className={`w-2 h-2 rounded-full ${
                      item.trend === 'up' ? 'bg-green-400' : item.trend === 'down' ? 'bg-red-400' : 'bg-blue-400'
                    } animate-ping`}></div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}