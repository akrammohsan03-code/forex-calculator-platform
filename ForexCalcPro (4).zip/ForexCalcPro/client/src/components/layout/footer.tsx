import { Link } from 'wouter';
import { Calculator, Twitter, Linkedin, Mail } from 'lucide-react';

export default function Footer() {
  const calculatorLinks = [
    { name: 'Position Size Calculator', href: '/position-size-calculator' },
    { name: 'Pip Calculator', href: '/pip-calculator' },
    { name: 'Profit Calculator', href: '/profit-calculator' },
    { name: 'Margin Calculator', href: '/margin-calculator' },
    { name: 'Currency Converter', href: '/currency-converter' },
    { name: 'Compounding Calculator', href: '/compounding-calculator' },
    { name: 'Fibonacci Calculator', href: '/fibonacci-calculator' },
    { name: 'Pivot Calculator', href: '/pivot-calculator' },
    { name: 'Drawdown Calculator', href: '/drawdown-calculator' },
    { name: 'Risk of Ruin Calculator', href: '/risk-of-ruin-calculator' },
    { name: 'Crypto Fees Calculator', href: '/crypto-fees-calculator' },
  ];

  const marketDataLinks = [
    { name: 'Live Forex Charts', href: '/forex-charts' },
    { name: 'Market News', href: '/forex-news' },
    { name: 'Economic Calendar', href: '/economic-calendar' },
    { name: 'Currency Converter', href: '/currency-converter' },
  ];

  const quickLinks = [
    { name: 'About Us', href: '/about-us' },
    { name: 'Contact', href: '/contact-us' },
    { name: 'Terms of Service', href: '/terms-of-service' },
    { name: 'Privacy Policy', href: '/privacy-policy' },
    { name: 'Disclaimer', href: '/disclaimer' },
  ];

  return (
    <footer className="bg-navy-900 text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="md:col-span-2 lg:col-span-1">
            <div className="flex items-center space-x-3 mb-4">
              <div className="bg-gold-500 p-2 rounded-lg">
                <Calculator className="w-6 h-6 text-white" />
              </div>
              <h2 className="text-xl font-bold text-gold-400">ForexCalculatorPro</h2>
            </div>
            <p className="text-navy-300 mb-6 max-w-md text-sm">
              Professional forex calculators and trading tools with real-time market data. 
              Trusted by traders worldwide for accurate position sizing and risk management.
            </p>
            <div className="flex space-x-4">
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-navy-300 hover:text-gold-400 transition-colors"
              >
                <Twitter className="w-5 h-5" />
              </a>
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-navy-300 hover:text-gold-400 transition-colors"
              >
                <Linkedin className="w-5 h-5" />
              </a>
              <a
                href="mailto:akrammohsan03@gmail.com"
                className="text-navy-300 hover:text-gold-400 transition-colors"
              >
                <Mail className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Calculators */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Trading Calculators</h3>
            <ul className="space-y-2">
              {calculatorLinks.slice(0, 6).map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-navy-300 hover:text-gold-400 transition-colors text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
            <Link
              href="/#calculators"
              className="text-gold-400 hover:text-gold-300 text-sm font-medium mt-3 inline-block"
            >
              View All Calculators →
            </Link>
          </div>

          {/* Market Data */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Market Data</h3>
            <ul className="space-y-2">
              {marketDataLinks.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-navy-300 hover:text-gold-400 transition-colors text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-navy-300 hover:text-gold-400 transition-colors text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-navy-700 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-navy-300 text-sm">
            &copy; 2024 ForexCalculatorPro. All rights reserved.
          </p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="/privacy-policy" className="text-navy-300 hover:text-gold-400 text-sm transition-colors">
              Privacy Policy
            </a>
            <a href="/terms-of-service" className="text-navy-300 hover:text-gold-400 text-sm transition-colors">
              Terms of Service
            </a>
            <a href="/contact" className="text-navy-300 hover:text-gold-400 text-sm transition-colors">
              Contact
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
