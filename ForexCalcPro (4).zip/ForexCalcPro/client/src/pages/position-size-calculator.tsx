import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import SEOHead from '@/components/seo-head';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calculator, Zap, DollarSign, BarChart3, TrendingUp } from 'lucide-react';
import { forexAPI } from '@/lib/forex-api';
import { CalculatorUtils } from '@/lib/calculator-utils';
import BannerAd from '@/components/ads/banner-ad';
import WordPressIframe from '@/components/wordpress-iframe';
import { 
  MAJOR_PAIRS, 
  MINOR_PAIRS, 
  EXOTIC_PAIRS,
  MAJOR_CURRENCIES, 
  METALS, 
  ENERGIES, 
  INDICES, 
  CRYPTOCURRENCIES,
  getAllInstruments,
  getInstrumentsByGroups
} from '@/data/currency-pairs';
import { useToast } from '@/hooks/use-toast';

interface CalculationResult {
  lotSize: number;
  units: number;
  moneyAtRisk: number;
  pipValue: number;
}

export default function PositionSizeCalculator() {
  const [currencyPair, setCurrencyPair] = useState('EUR/USD');
  const [accountCurrency, setAccountCurrency] = useState('USD');
  const [accountBalance, setAccountBalance] = useState<string>('10000');
  const [riskPercentage, setRiskPercentage] = useState<string>('2');
  const [stopLossPips, setStopLossPips] = useState<string>('50');
  const [entryPrice, setEntryPrice] = useState<string>('1.1000');
  const [result, setResult] = useState<CalculationResult | null>(null);
  
  const { toast } = useToast();

  const { data: currencyPairs, isLoading } = useQuery({
    queryKey: ['/api/currency-pairs'],
    queryFn: () => forexAPI.getCurrencyPairs(),
  });

  const { data: forexRates } = useQuery({
    queryKey: ['/api/forex-rates', accountCurrency],
    queryFn: () => forexAPI.getForexRates(accountCurrency),
  });

  const calculatePositionSize = async () => {
    const balance = parseFloat(accountBalance);
    const risk = parseFloat(riskPercentage);
    const stopLoss = parseFloat(stopLossPips);
    
    if (!balance || !risk || !stopLoss) {
      toast({
        title: 'Invalid Input',
        description: 'Please enter valid values for all fields.',
        variant: 'destructive',
      });
      return;
    }

    try {
      // Calculate pip value
      const pipValue = CalculatorUtils.calculatePipValue({
        currencyPair,
        lotSize: 1,
        accountCurrency,
        exchangeRate: forexRates?.conversion_rates?.[currencyPair.split('/')[1]] || 1,
      });

      // Calculate position size
      const positionResult = CalculatorUtils.calculatePositionSize({
        accountBalance: balance,
        riskPercentage: risk,
        stopLossPips: stopLoss,
        pipValue,
        exchangeRate: forexRates?.conversion_rates?.[currencyPair.split('/')[1]] || 1,
      });

      setResult(positionResult);

      // Save calculation result
      await forexAPI.saveCalculatorResult('position-size', {
        currencyPair,
        accountCurrency,
        accountBalance: balance,
        riskPercentage: risk,
        stopLossPips: stopLoss,
        entryPrice: parseFloat(entryPrice),
      }, positionResult);

      toast({
        title: 'Calculation Complete',
        description: 'Position size calculated successfully!',
      });

    } catch (error) {
      toast({
        title: 'Calculation Error',
        description: 'Failed to calculate position size. Please try again.',
        variant: 'destructive',
      });
    }
  };

  const currentRate = currencyPairs?.find(pair => pair.symbol === currencyPair)?.rate || '1.0000';

  return (
    <>
      <SEOHead
        title="Position Size Calculator | Calculate Optimal Forex Lot Size - ForexCalculatorPro"
        description="Free position size calculator to determine optimal lot size based on your account balance, risk percentage, and stop loss. Professional forex risk management tool with live rates."
        keywords="position size calculator, lot size calculator, forex risk management, trading position size, forex calculator"
        canonicalUrl="https://forexcalculatorpro.com/position-size-calculator"
      />

      <div className="min-h-screen bg-navy-50">
        <Header />

        {/* Hero Section */}
        <section className="navy-gradient text-white py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                Professional <span className="text-gold-400">Position Size Calculator</span>
              </h1>
              <p className="text-xl mb-8 text-navy-100 max-w-3xl mx-auto">
                Calculate your optimal position size, manage risk effectively, and maximize your trading potential 
                with our comprehensive forex calculator tools.
              </p>
            </div>
          </div>
        </section>

        {/* Main Calculator Section */}
        <section className="py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Calculator Card */}
              <div className="lg:col-span-2">
                <Card className="calculator-card">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <div className="bg-gold-500 p-2 rounded-lg mr-3">
                        <Calculator className="w-6 h-6 text-white" />
                      </div>
                      Position Size Calculator
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      {/* Currency Pair Selection */}
                      <div className="space-y-2">
                        <Label htmlFor="currencyPair">Trading Instrument</Label>
                        <Select value={currencyPair} onValueChange={setCurrencyPair}>
                          <SelectTrigger className="input-field">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {/* Major Forex Pairs */}
                            <div className="px-2 py-1 text-xs font-semibold text-navy-700 bg-navy-50">
                              Major Forex Pairs
                            </div>
                            {MAJOR_PAIRS.map((pair) => (
                              <SelectItem key={pair} value={pair}>
                                {pair}
                              </SelectItem>
                            ))}

                            {/* Minor Forex Pairs */}
                            <div className="px-2 py-1 text-xs font-semibold text-navy-700 bg-navy-50 mt-2">
                              Minor Forex Pairs
                            </div>
                            {MINOR_PAIRS.map((pair) => (
                              <SelectItem key={pair} value={pair}>
                                {pair}
                              </SelectItem>
                            ))}

                            {/* Exotic Pairs */}
                            <div className="px-2 py-1 text-xs font-semibold text-navy-700 bg-navy-50 mt-2">
                              Exotic Pairs
                            </div>
                            {EXOTIC_PAIRS.slice(0, 10).map((pair) => (
                              <SelectItem key={pair} value={pair}>
                                {pair}
                              </SelectItem>
                            ))}

                            {/* Precious Metals */}
                            <div className="px-2 py-1 text-xs font-semibold text-navy-700 bg-navy-50 mt-2">
                              Precious Metals
                            </div>
                            {METALS.map((metal) => (
                              <SelectItem key={metal.code} value={metal.code}>
                                <div className="flex items-center">
                                  <span className="font-mono mr-2">{metal.symbol}</span>
                                  <span className="text-sm text-navy-600">{metal.name}</span>
                                </div>
                              </SelectItem>
                            ))}

                            {/* Energy Commodities */}
                            <div className="px-2 py-1 text-xs font-semibold text-navy-700 bg-navy-50 mt-2">
                              Energy & Oil
                            </div>
                            {ENERGIES.map((energy) => (
                              <SelectItem key={energy.code} value={energy.code}>
                                <div className="flex items-center">
                                  <span className="font-mono mr-2">{energy.symbol}</span>
                                  <span className="text-sm text-navy-600">{energy.name}</span>
                                </div>
                              </SelectItem>
                            ))}

                            {/* Major Indices */}
                            <div className="px-2 py-1 text-xs font-semibold text-navy-700 bg-navy-50 mt-2">
                              Stock Indices
                            </div>
                            {INDICES.slice(0, 8).map((index) => (
                              <SelectItem key={index.code} value={index.code}>
                                <div className="flex items-center">
                                  <span className="font-mono mr-2">{index.symbol}</span>
                                  <span className="text-sm text-navy-600">{index.name}</span>
                                </div>
                              </SelectItem>
                            ))}

                            {/* Major Cryptocurrencies */}
                            <div className="px-2 py-1 text-xs font-semibold text-navy-700 bg-navy-50 mt-2">
                              Cryptocurrencies
                            </div>
                            {CRYPTOCURRENCIES.slice(0, 6).map((crypto) => (
                              <SelectItem key={crypto.code} value={crypto.code}>
                                <div className="flex items-center">
                                  <span className="font-mono mr-2">{crypto.symbol}</span>
                                  <span className="text-sm text-navy-600">{crypto.name}</span>
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      {/* Account Currency */}
                      <div className="space-y-2">
                        <Label htmlFor="accountCurrency">Account Currency</Label>
                        <Select value={accountCurrency} onValueChange={setAccountCurrency}>
                          <SelectTrigger className="input-field">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {MAJOR_CURRENCIES.map((currency) => (
                              <SelectItem key={currency.code} value={currency.code}>
                                {currency.name} ({currency.code})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      {/* Account Balance */}
                      <div className="space-y-2">
                        <Label htmlFor="accountBalance">Account Balance</Label>
                        <Input
                          id="accountBalance"
                          type="number"
                          placeholder="10000"
                          value={accountBalance}
                          onChange={(e) => setAccountBalance(e.target.value)}
                          className="input-field"
                        />
                      </div>

                      {/* Risk Percentage */}
                      <div className="space-y-2">
                        <Label htmlFor="riskPercentage">Risk (%)</Label>
                        <Input
                          id="riskPercentage"
                          type="number"
                          placeholder="2"
                          step="0.1"
                          value={riskPercentage}
                          onChange={(e) => setRiskPercentage(e.target.value)}
                          className="input-field"
                        />
                      </div>

                      {/* Stop Loss */}
                      <div className="space-y-2">
                        <Label htmlFor="stopLossPips">Stop Loss (pips)</Label>
                        <Input
                          id="stopLossPips"
                          type="number"
                          placeholder="50"
                          value={stopLossPips}
                          onChange={(e) => setStopLossPips(e.target.value)}
                          className="input-field"
                        />
                      </div>

                      {/* Entry Price */}
                      <div className="space-y-2">
                        <Label htmlFor="entryPrice">Entry Price (Current: {currentRate})</Label>
                        <Input
                          id="entryPrice"
                          type="number"
                          placeholder="1.1000"
                          step="0.0001"
                          value={entryPrice}
                          onChange={(e) => setEntryPrice(e.target.value)}
                          className="input-field"
                        />
                      </div>
                    </div>

                    <Button 
                      onClick={calculatePositionSize}
                      disabled={isLoading}
                      className="btn-primary w-full"
                    >
                      <Calculator className="w-5 h-5 mr-2" />
                      Calculate Position Size
                    </Button>

                    {/* Results Panel */}
                    {result && (
                      <div className="mt-8 p-6 bg-navy-50 rounded-lg">
                        <h3 className="text-lg font-semibold text-navy-900 mb-4">Calculation Results</h3>
                        <div className="grid md:grid-cols-4 gap-4">
                          <Card className="border">
                            <CardContent className="p-4 text-center">
                              <div className="text-2xl font-bold text-gold-600">
                                {result.lotSize.toFixed(2)}
                              </div>
                              <div className="text-sm text-navy-600">Lots (Trade Size)</div>
                            </CardContent>
                          </Card>
                          <Card className="border">
                            <CardContent className="p-4 text-center">
                              <div className="text-2xl font-bold text-green-600">
                                {result.units.toLocaleString()}
                              </div>
                              <div className="text-sm text-navy-600">Units</div>
                            </CardContent>
                          </Card>
                          <Card className="border">
                            <CardContent className="p-4 text-center">
                              <div className="text-2xl font-bold text-red-600">
                                {accountCurrency === 'USD' ? '$' : ''}{result.moneyAtRisk.toFixed(2)}
                              </div>
                              <div className="text-sm text-navy-600">Money at Risk</div>
                            </CardContent>
                          </Card>
                          <Card className="border">
                            <CardContent className="p-4 text-center">
                              <div className="text-2xl font-bold text-blue-600">
                                {accountCurrency === 'USD' ? '$' : ''}{result.pipValue.toFixed(2)}
                              </div>
                              <div className="text-sm text-navy-600">Pip Value</div>
                            </CardContent>
                          </Card>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              {/* Side Panel */}
              <div className="space-y-6">
                {/* Quick Tools */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Quick Access Tools</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <a href="/pip-calculator" className="flex items-center p-3 hover:bg-navy-50 rounded-lg transition-colors group">
                      <div className="bg-gold-100 p-2 rounded mr-3 group-hover:bg-gold-200">
                        <Zap className="w-4 h-4 text-gold-600" />
                      </div>
                      <span className="text-navy-700 font-medium">Pip Calculator</span>
                    </a>
                    <a href="/profit-calculator" className="flex items-center p-3 hover:bg-navy-50 rounded-lg transition-colors group">
                      <div className="bg-gold-100 p-2 rounded mr-3 group-hover:bg-gold-200">
                        <DollarSign className="w-4 h-4 text-gold-600" />
                      </div>
                      <span className="text-navy-700 font-medium">Profit Calculator</span>
                    </a>
                    <a href="/margin-calculator" className="flex items-center p-3 hover:bg-navy-50 rounded-lg transition-colors group">
                      <div className="bg-gold-100 p-2 rounded mr-3 group-hover:bg-gold-200">
                        <BarChart3 className="w-4 h-4 text-gold-600" />
                      </div>
                      <span className="text-navy-700 font-medium">Margin Calculator</span>
                    </a>
                    <a href="/compounding-calculator" className="flex items-center p-3 hover:bg-navy-50 rounded-lg transition-colors group">
                      <div className="bg-gold-100 p-2 rounded mr-3 group-hover:bg-gold-200">
                        <TrendingUp className="w-4 h-4 text-gold-600" />
                      </div>
                      <span className="text-navy-700 font-medium">Compounding Calculator</span>
                    </a>
                  </CardContent>
                </Card>

                {/* Market Info */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Live Market Data</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 text-sm">
                      {currencyPairs?.slice(0, 6).map((pair) => (
                        <div key={pair.symbol} className="flex justify-between items-center">
                          <span className="text-navy-600">{pair.symbol}</span>
                          <span className="font-semibold text-green-600">
{parseFloat(pair.rate?.toString() || '0').toFixed(5)}
                          </span>
                        </div>
                      ))}
                    </div>
                    <div className="mt-4 text-xs text-navy-500">
                      * Live market data updated in real-time
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* WordPress Integration Guide */}
            <WordPressIframe 
              calculatorName="Position Size Calculator" 
              calculatorPath="/position-size-calculator"
            />

            {/* Advertisement Space */}
            <div className="mt-8">
              <BannerAd position="content" className="max-w-4xl mx-auto" />
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
}
