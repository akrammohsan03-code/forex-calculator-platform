import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import SEOHead from '@/components/seo-head';
import { Users, Target, Award, Heart, Calculator, TrendingUp, Shield, Zap } from 'lucide-react';

export default function AboutUs() {
  return (
    <>
      <SEOHead
        title="About Us - ForexCalculatorPro"
        description="Learn about ForexCalculatorPro's mission to provide professional trading calculators and tools for forex, commodities, and financial markets."
        canonicalUrl="https://forexcalculatorpro.com/about-us"
      />
      
      <div className="min-h-screen bg-navy-50">
        <Header />

        {/* Hero Section */}
        <section className="navy-gradient text-white py-16">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div className="flex items-center justify-center mb-6">
              <div className="bg-gold-500 p-4 rounded-lg mr-4">
                <Users className="w-12 h-12 text-white" />
              </div>
              <h1 className="text-3xl md:text-5xl font-bold">About ForexCalculatorPro</h1>
            </div>
            <p className="text-xl text-navy-100 max-w-3xl mx-auto leading-relaxed">
              Empowering traders worldwide with professional-grade calculators and tools for informed trading decisions across forex, commodities, and financial markets.
            </p>
          </div>
        </section>

        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          
          {/* Mission & Vision */}
          <div className="grid md:grid-cols-2 gap-8 mb-16">
            <div className="bg-white rounded-lg shadow-lg p-8">
              <div className="flex items-center mb-6">
                <div className="bg-gold-500 p-3 rounded-lg mr-4">
                  <Target className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-navy-900">Our Mission</h2>
              </div>
              <p className="text-navy-700 leading-relaxed">
                To democratize access to professional trading tools by providing accurate, reliable, and easy-to-use calculators that help traders of all levels make informed decisions and manage risk effectively in the financial markets.
              </p>
            </div>

            <div className="bg-white rounded-lg shadow-lg p-8">
              <div className="flex items-center mb-6">
                <div className="bg-gold-500 p-3 rounded-lg mr-4">
                  <Award className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-navy-900">Our Vision</h2>
              </div>
              <p className="text-navy-700 leading-relaxed">
                To become the world's most trusted platform for trading calculators and financial tools, setting the standard for accuracy, reliability, and user experience in the trading community.
              </p>
            </div>
          </div>

          {/* Our Story */}
          <section className="mb-16">
            <div className="bg-white rounded-lg shadow-lg p-8 md:p-12">
              <div className="flex items-center mb-8">
                <div className="bg-gold-500 p-3 rounded-lg mr-4">
                  <Heart className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-3xl font-bold text-navy-900">Our Story</h2>
              </div>
              
              <div className="grid md:grid-cols-2 gap-8 items-center">
                <div className="space-y-6">
                  <p className="text-navy-700 leading-relaxed">
                    ForexCalculatorPro was born from a simple observation: traders needed better, more accessible tools to make calculated decisions in the fast-paced world of financial markets.
                  </p>
                  
                  <p className="text-navy-700 leading-relaxed">
                    Founded by experienced traders and developers, we recognized that while sophisticated trading platforms existed, there was a gap in providing simple, accurate calculators that could be used by anyone, anywhere, without complex setups or expensive subscriptions.
                  </p>
                  
                  <p className="text-navy-700 leading-relaxed">
                    Today, we serve thousands of traders worldwide, from beginners learning the basics of position sizing to professional traders managing complex portfolios across multiple markets.
                  </p>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-gray-50 rounded-lg">
                    <div className="text-3xl font-bold text-gold-500 mb-2">70+</div>
                    <p className="text-sm text-navy-600">Trading Instruments</p>
                  </div>
                  <div className="text-center p-4 bg-gray-50 rounded-lg">
                    <div className="text-3xl font-bold text-gold-500 mb-2">11</div>
                    <p className="text-sm text-navy-600">Professional Calculators</p>
                  </div>
                  <div className="text-center p-4 bg-gray-50 rounded-lg">
                    <div className="text-3xl font-bold text-gold-500 mb-2">24/7</div>
                    <p className="text-sm text-navy-600">Real-time Data</p>
                  </div>
                  <div className="text-center p-4 bg-gray-50 rounded-lg">
                    <div className="text-3xl font-bold text-gold-500 mb-2">Free</div>
                    <p className="text-sm text-navy-600">Always Available</p>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* What We Offer */}
          <section className="mb-16">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-navy-900 mb-4">What We Offer</h2>
              <p className="text-lg text-navy-600 max-w-3xl mx-auto">
                Comprehensive trading tools designed for accuracy, simplicity, and professional-grade results.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-white rounded-lg shadow-lg p-6 text-center">
                <div className="bg-gold-500 p-3 rounded-lg inline-block mb-4">
                  <Calculator className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-navy-900 mb-2">Trading Calculators</h3>
                <p className="text-sm text-navy-600">Position size, pip value, profit/loss, and margin calculators</p>
              </div>

              <div className="bg-white rounded-lg shadow-lg p-6 text-center">
                <div className="bg-gold-500 p-3 rounded-lg inline-block mb-4">
                  <TrendingUp className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-navy-900 mb-2">Live Market Data</h3>
                <p className="text-sm text-navy-600">Real-time forex rates, charts, and market analysis</p>
              </div>

              <div className="bg-white rounded-lg shadow-lg p-6 text-center">
                <div className="bg-gold-500 p-3 rounded-lg inline-block mb-4">
                  <Shield className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-navy-900 mb-2">Risk Management</h3>
                <p className="text-sm text-navy-600">Drawdown, risk of ruin, and compounding calculators</p>
              </div>

              <div className="bg-white rounded-lg shadow-lg p-6 text-center">
                <div className="bg-gold-500 p-3 rounded-lg inline-block mb-4">
                  <Zap className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-navy-900 mb-2">Advanced Tools</h3>
                <p className="text-sm text-navy-600">Fibonacci, pivot points, and technical analysis tools</p>
              </div>
            </div>
          </section>

          {/* Our Values */}
          <section className="mb-16">
            <div className="bg-white rounded-lg shadow-lg p-8 md:p-12">
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold text-navy-900 mb-4">Our Core Values</h2>
                <p className="text-lg text-navy-600">The principles that guide everything we do</p>
              </div>

              <div className="grid md:grid-cols-3 gap-8">
                <div className="text-center">
                  <div className="bg-gold-100 p-4 rounded-full inline-block mb-4">
                    <Shield className="w-8 h-8 text-gold-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-navy-900 mb-3">Accuracy</h3>
                  <p className="text-navy-600">We prioritize precision in every calculation and data point, ensuring traders can rely on our tools for critical decisions.</p>
                </div>

                <div className="text-center">
                  <div className="bg-gold-100 p-4 rounded-full inline-block mb-4">
                    <Users className="w-8 h-8 text-gold-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-navy-900 mb-3">Accessibility</h3>
                  <p className="text-navy-600">Professional trading tools should be available to everyone, regardless of experience level or financial background.</p>
                </div>

                <div className="text-center">
                  <div className="bg-gold-100 p-4 rounded-full inline-block mb-4">
                    <Zap className="w-8 h-8 text-gold-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-navy-900 mb-3">Innovation</h3>
                  <p className="text-navy-600">We continuously improve and expand our offerings to meet the evolving needs of the trading community.</p>
                </div>
              </div>
            </div>
          </section>

          {/* Contact Information */}
          <section>
            <div className="bg-navy-900 text-white rounded-lg shadow-lg p-8 md:p-12 text-center">
              <h2 className="text-3xl font-bold mb-4">Get In Touch</h2>
              <p className="text-navy-100 mb-8 max-w-2xl mx-auto">
                Have questions, suggestions, or feedback? We'd love to hear from you. Our team is committed to helping you succeed in your trading journey.
              </p>
              
              <div className="grid md:grid-cols-2 gap-8 max-w-2xl mx-auto">
                <div>
                  <h3 className="text-xl font-semibold text-gold-400 mb-3">Contact Information</h3>
                  <div className="space-y-2 text-navy-100">
                    <p><strong>Email:</strong> akrammohsan03@gmail.com</p>
                    <p><strong>Website:</strong> forexcalculatorpro.com</p>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-xl font-semibold text-gold-400 mb-3">Our Location</h3>
                  <div className="text-navy-100">
                    <p>House 456, Street No 11</p>
                    <p>J2 Block, Johar Town</p>
                    <p>Lahore, Pakistan</p>
                  </div>
                </div>
              </div>
            </div>
          </section>

        </div>

        <Footer />
      </div>
    </>
  );
}