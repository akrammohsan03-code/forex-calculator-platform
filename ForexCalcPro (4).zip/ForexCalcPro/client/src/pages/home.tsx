import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import CalculatorCard from '@/components/calculator-card';
import SEOHead from '@/components/seo-head';
import TradingViewChart from '@/components/trading-view-chart';
import ForexNewsFeed from '@/components/forex-news-feed';
import { Card, CardContent } from '@/components/ui/card';
import { 
  Calculator, 
  Zap, 
  DollarSign, 
  BarChart3, 
  TrendingUp, 
  Target, 
  PieChart, 
  AlertTriangle,
  Activity,
  Shuffle,
  Bitcoin,
  Shield
} from 'lucide-react';

export default function Home() {
  const calculators = [
    {
      title: 'Position Size Calculator',
      description: 'Calculate optimal position size based on your risk tolerance and account balance for effective risk management.',
      href: '/position-size-calculator',
      icon: <Calculator className="w-6 h-6 text-white" />,
    },
    {
      title: 'Pip Calculator',
      description: 'Calculate pip values using live market rates for accurate position sizing and profit/loss estimation.',
      href: '/pip-calculator',
      icon: <Zap className="w-6 h-6 text-white" />,
    },
    {
      title: 'Profit Calculator',
      description: 'Calculate potential profits and losses with live market data across 145K+ trading symbols.',
      href: '/profit-calculator',
      icon: <DollarSign className="w-6 h-6 text-white" />,
    },
    {
      title: 'Margin Calculator',
      description: 'Determine required margin for your positions based on leverage and position size.',
      href: '/margin-calculator',
      icon: <BarChart3 className="w-6 h-6 text-white" />,
    },
    {
      title: 'Compounding Calculator',
      description: 'Simulate account growth over time with customizable win rates and compounding strategies.',
      href: '/compounding-calculator',
      icon: <TrendingUp className="w-6 h-6 text-white" />,
    },
    {
      title: 'Fibonacci Calculator',
      description: 'Calculate Fibonacci retracement and extension levels for technical analysis across all markets.',
      href: '/fibonacci-calculator',
      icon: <Target className="w-6 h-6 text-white" />,
    },
    {
      title: 'Pivot Points Calculator',
      description: 'Calculate support and resistance levels using standard and DeMark pivot point methods.',
      href: '/pivot-calculator',
      icon: <PieChart className="w-6 h-6 text-white" />,
    },
    {
      title: 'Drawdown Calculator',
      description: 'Calculate how your account equity is affected after a series of losing trades.',
      href: '/drawdown-calculator',
      icon: <AlertTriangle className="w-6 h-6 text-white" />,
    },
    {
      title: 'Risk of Ruin Calculator',
      description: 'Calculate the probability of reaching maximum drawdown based on your trading statistics.',
      href: '/risk-of-ruin-calculator',
      icon: <Activity className="w-6 h-6 text-white" />,
    },
    {
      title: 'Currency Converter',
      description: 'Real-time currency conversion with live interbank rates for major and exotic currencies.',
      href: '/currency-converter',
      icon: <Shuffle className="w-6 h-6 text-white" />,
    },
    {
      title: 'Crypto Fees Calculator',
      description: 'Calculate trading fees for multiple crypto exchanges with maker and taker fee structures.',
      href: '/crypto-fees-calculator',
      icon: <Bitcoin className="w-6 h-6 text-white" />,
    },
  ];

  const features = [
    {
      icon: <Zap className="w-8 h-8 text-white" />,
      title: 'Real-Time Data',
      description: 'Live market rates across 145K+ trading symbols for accurate calculations.',
    },
    {
      icon: <Shield className="w-8 h-8 text-white" />,
      title: 'Secure & Private',
      description: 'Your trading data remains private and secure with no registration required.',
    },
    {
      icon: <Target className="w-8 h-8 text-white" />,
      title: 'Professional Grade',
      description: 'Institutional-level accuracy with user-friendly interfaces for all skill levels.',
    },
    {
      icon: <Calculator className="w-8 h-8 text-white" />,
      title: 'Mobile Optimized',
      description: 'Perfectly responsive design that works flawlessly on all devices.',
    },
  ];

  return (
    <>
      <SEOHead
        title="Trading Calculator Pro - Forex, Gold, Oil, NASDAQ100, US30 & 70+ Instruments"
        description="Professional trading calculators for Forex pairs, Gold, Silver, Crude Oil, NASDAQ100, US30, and 70+ instruments. Position size, pip value, profit/loss calculators with real-time data."
        keywords="forex calculator, position size calculator, pip calculator, gold calculator, oil calculator, nasdaq100 calculator, us30 calculator, trading calculator, risk management"
        canonicalUrl="https://forexcalculatorpro.com"
      />
      
      <div className="min-h-screen bg-navy-50">
        <Header />

        {/* Hero Section */}
        <section className="navy-gradient text-white py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-2xl sm:text-3xl md:text-5xl font-bold mb-4 leading-tight">
                Professional <span className="text-gold-400">Trading Calculators</span>
              </h1>
              <p className="text-base sm:text-lg md:text-xl mb-6 sm:mb-8 text-navy-100 max-w-3xl mx-auto px-4">
                Comprehensive trading calculators for Forex pairs, Gold, Silver, Crude Oil, NASDAQ100, US30, 
                and 70+ instruments with real-time market data and professional-grade risk management tools.
              </p>
              <div className="flex flex-wrap justify-center gap-2 sm:gap-3 mb-6 sm:mb-8 px-4">
                <div className="bg-navy-700 px-2 sm:px-4 py-1 sm:py-2 rounded-full">
                  <span className="text-gold-400 font-semibold text-xs sm:text-sm">70+ Instruments</span>
                </div>
                <div className="bg-navy-700 px-2 sm:px-4 py-1 sm:py-2 rounded-full">
                  <span className="text-gold-400 font-semibold text-xs sm:text-sm">Forex • Metals • Oil</span>
                </div>
                <div className="bg-navy-700 px-2 sm:px-4 py-1 sm:py-2 rounded-full">
                  <span className="text-gold-400 font-semibold text-xs sm:text-sm">NASDAQ • US30</span>
                </div>
                <div className="bg-navy-700 px-2 sm:px-4 py-1 sm:py-2 rounded-full">
                  <span className="text-gold-400 font-semibold text-xs sm:text-sm">Crypto • Indices</span>
                </div>
                <div className="bg-navy-700 px-2 sm:px-4 py-1 sm:py-2 rounded-full">
                  <span className="text-gold-400 font-semibold text-xs sm:text-sm">Real-time Data</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Trading Instruments Showcase */}
        <section className="py-12 bg-white border-b">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-navy-900 mb-3">Trade Across All Major Markets</h2>
              <p className="text-navy-600">Calculate position sizes, pip values, and profits for the world's most popular trading instruments</p>
            </div>
            
            <div className="grid md:grid-cols-6 gap-4 text-center">
              <div className="p-4">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <span className="text-blue-600 font-bold text-lg">FX</span>
                </div>
                <h3 className="font-semibold text-navy-900 text-sm">Major & Minor Pairs</h3>
                <p className="text-xs text-navy-600">EUR/USD, GBP/USD, USD/JPY</p>
              </div>
              
              <div className="p-4">
                <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <span className="text-yellow-600 font-bold text-lg">Au</span>
                </div>
                <h3 className="font-semibold text-navy-900 text-sm">Precious Metals</h3>
                <p className="text-xs text-navy-600">Gold, Silver, Platinum</p>
              </div>
              
              <div className="p-4">
                <div className="w-12 h-12 bg-black rounded-full flex items-center justify-center mx-auto mb-2">
                  <span className="text-white font-bold text-lg">Oil</span>
                </div>
                <h3 className="font-semibold text-navy-900 text-sm">Energy & Oil</h3>
                <p className="text-xs text-navy-600">Crude Oil, Brent, Gas</p>
              </div>
              
              <div className="p-4">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <span className="text-green-600 font-bold text-sm">US100</span>
                </div>
                <h3 className="font-semibold text-navy-900 text-sm">NASDAQ 100</h3>
                <p className="text-xs text-navy-600">Tech Stock Index</p>
              </div>
              
              <div className="p-4">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <span className="text-purple-600 font-bold text-sm">US30</span>
                </div>
                <h3 className="font-semibold text-navy-900 text-sm">Dow Jones 30</h3>
                <p className="text-xs text-navy-600">Blue Chip Index</p>
              </div>
              
              <div className="p-4">
                <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <span className="text-orange-600 font-bold text-lg">₿</span>
                </div>
                <h3 className="font-semibold text-navy-900 text-sm">Cryptocurrencies</h3>
                <p className="text-xs text-navy-600">Bitcoin, Ethereum</p>
              </div>
            </div>
            
            <div className="text-center mt-6">
              <p className="text-sm text-navy-500">
                <strong>70+ instruments supported:</strong> Major & minor forex pairs, exotic currencies, precious metals, energy commodities, stock indices, and cryptocurrencies
              </p>
            </div>
          </div>
        </section>

        {/* Calculator Tools Grid */}
        <section className="py-16 bg-white" id="calculators">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-navy-900 mb-4">Complete Trading Calculator Suite</h2>
              <p className="text-lg text-navy-600 max-w-3xl mx-auto">
                Professional forex calculators with real-time market data to optimize your trading strategy and risk management.
              </p>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
              {calculators.map((calculator) => (
                <CalculatorCard
                  key={calculator.title}
                  title={calculator.title}
                  description={calculator.description}
                  href={calculator.href}
                  icon={calculator.icon}
                />
              ))}
            </div>
          </div>
        </section>

        {/* Live Market Analysis Section */}
        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-navy-900 mb-4">Live Market Analysis</h2>
              <p className="text-lg text-navy-600 max-w-3xl mx-auto">
                Real-time forex charts and market news to stay ahead of market movements and make informed trading decisions.
              </p>
            </div>

            <div className="grid lg:grid-cols-3 gap-6 lg:gap-8">
              {/* Live Chart - Takes up 2 columns on desktop */}
              <div className="lg:col-span-2">
                <TradingViewChart
                  symbol="EUR/USD"
                  height={350}
                  showControls={true}
                />
              </div>

              {/* Compact News Feed - Takes up 1 column */}
              <div className="mt-6 lg:mt-0">
                <ForexNewsFeed
                  compact={true}
                  showSearch={false}
                  maxArticles={6}
                />
              </div>
            </div>

            <div className="mt-8 text-center">
              <p className="text-sm text-gray-600">
                <strong>Real-time data:</strong> Charts and news update automatically with live market information
              </p>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-16 navy-gradient text-white" id="features">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Why Choose ForexCalculatorPro?</h2>
              <p className="text-lg text-navy-100 max-w-3xl mx-auto">
                Professional-grade tools trusted by traders worldwide for accurate calculations and risk management.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {features.map((feature) => (
                <div key={feature.title} className="text-center">
                  <div className="bg-gold-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    {feature.icon}
                  </div>
                  <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                  <p className="text-navy-300 text-sm">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Trading Tools Section */}
        <section className="py-16 bg-navy-50" id="trading-tools">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-navy-900 mb-4">Professional Trading Tools</h2>
              <p className="text-lg text-navy-600 max-w-3xl mx-auto">
                Access advanced trading tools and market data to enhance your trading strategy and decision-making process.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              <Card className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6 text-center">
                  <div className="bg-gold-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Activity className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-navy-900 mb-3">Economic Calendar</h3>
                  <p className="text-navy-600 mb-4">
                    Stay updated with major economic events that impact forex markets. Filter by currency and impact level.
                  </p>
                  <a 
                    href="/economic-calendar" 
                    className="inline-flex items-center text-gold-600 hover:text-gold-700 font-medium"
                  >
                    View Calendar →
                  </a>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6 text-center">
                  <div className="bg-gold-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <BarChart3 className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-navy-900 mb-3">Market News</h3>
                  <p className="text-navy-600 mb-4">
                    Real-time forex news with market impact analysis from trusted financial sources worldwide.
                  </p>
                  <a 
                    href="/forex-news" 
                    className="inline-flex items-center text-gold-600 hover:text-gold-700 font-medium"
                  >
                    Read News →
                  </a>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6 text-center">
                  <div className="bg-gold-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <TrendingUp className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-navy-900 mb-3">Live Forex Charts</h3>
                  <p className="text-navy-600 mb-4">
                    Professional TradingView charts with real-time data, candlestick analysis, and multiple timeframes.
                  </p>
                  <a 
                    href="/forex-charts" 
                    className="inline-flex items-center text-gold-600 hover:text-gold-700 font-medium"
                  >
                    View Charts →
                  </a>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6 text-center">
                  <div className="bg-gold-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Shield className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-navy-900 mb-3">Risk Management</h3>
                  <p className="text-navy-600 mb-4">
                    Comprehensive risk analysis tools including position sizing, drawdown calculation, and risk-of-ruin assessment.
                  </p>
                  <a 
                    href="/position-size-calculator" 
                    className="inline-flex items-center text-gold-600 hover:text-gold-700 font-medium"
                  >
                    Calculate Risk →
                  </a>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6 text-center">
                  <div className="bg-gold-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <BarChart3 className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-navy-900 mb-3">Technical Analysis</h3>
                  <p className="text-navy-600 mb-4">
                    Advanced calculators for Fibonacci retracements, pivot points, and support/resistance levels.
                  </p>
                  <a 
                    href="/fibonacci-calculator" 
                    className="inline-flex items-center text-gold-600 hover:text-gold-700 font-medium"
                  >
                    Analyze Charts →
                  </a>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6 text-center">
                  <div className="bg-gold-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Shuffle className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-navy-900 mb-3">Currency Converter</h3>
                  <p className="text-navy-600 mb-4">
                    Real-time currency conversion with live exchange rates for all major and exotic currency pairs.
                  </p>
                  <a 
                    href="/currency-converter" 
                    className="inline-flex items-center text-gold-600 hover:text-gold-700 font-medium"
                  >
                    Convert Now →
                  </a>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6 text-center">
                  <div className="bg-gold-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Bitcoin className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-navy-900 mb-3">Crypto Tools</h3>
                  <p className="text-navy-600 mb-4">
                    Specialized calculators for cryptocurrency trading fees and profit/loss calculations.
                  </p>
                  <a 
                    href="/crypto-fees-calculator" 
                    className="inline-flex items-center text-gold-600 hover:text-gold-700 font-medium"
                  >
                    Calculate Fees →
                  </a>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-16 bg-white" id="faq">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-navy-900 mb-4">Frequently Asked Questions</h2>
              <p className="text-lg text-navy-600">
                Get answers to common questions about position sizing and risk management.
              </p>
            </div>

            <div className="space-y-6">
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold text-navy-900 mb-2">What is position sizing in forex trading?</h3>
                  <p className="text-navy-600 text-sm leading-relaxed">
                    Position sizing is the process of determining how much of a currency pair to buy or sell in a trade. 
                    It's calculated based on your account balance, risk tolerance, and the distance to your stop loss level. 
                    Proper position sizing ensures you don't risk more than you can afford to lose on any single trade.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold text-navy-900 mb-2">How much should I risk per trade?</h3>
                  <p className="text-navy-600 text-sm leading-relaxed">
                    Most professional traders recommend risking no more than 1-2% of your account balance per trade. 
                    This conservative approach helps preserve capital during losing streaks and allows your account to grow 
                    over time through compounding gains.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold text-navy-900 mb-2">What is a lot in forex trading?</h3>
                  <p className="text-navy-600 text-sm leading-relaxed">
                    A standard lot in forex is 100,000 units of the base currency. Mini lots are 10,000 units (0.1 lots), 
                    micro lots are 1,000 units (0.01 lots), and nano lots are 100 units (0.001 lots). 
                    Most retail brokers allow trading with fractional lot sizes.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold text-navy-900 mb-2">How do I calculate pip value?</h3>
                  <p className="text-navy-600 text-sm leading-relaxed">
                    Pip value depends on the currency pair, lot size, and your account currency. For USD-based accounts 
                    trading major pairs, one pip for a standard lot is typically worth $10. Our pip calculator automatically 
                    determines the exact pip value for any currency pair and account configuration.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
}
