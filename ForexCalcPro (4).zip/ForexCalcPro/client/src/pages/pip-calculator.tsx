import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import SEOHead from '@/components/seo-head';
import AnimatedRateDisplay from '@/components/animated-rate-display';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Zap, Calculator, DollarSign, TrendingUp } from 'lucide-react';
import { forexAPI } from '@/lib/forex-api';
import { CalculatorUtils } from '@/lib/calculator-utils';
import { getPairsByGroups, MAJOR_CURRENCIES } from '@/data/currency-pairs';
import { useToast } from '@/hooks/use-toast';

export default function PipCalculator() {
  const [currencyPair, setCurrencyPair] = useState('EUR/USD');
  const [accountCurrency, setAccountCurrency] = useState('USD');
  const [lotSize, setLotSize] = useState<string>('1');
  const [pipValue, setPipValue] = useState<number | null>(null);
  
  const { toast } = useToast();

  const pairGroups = getPairsByGroups();

  const { data: currencyPairs, isLoading } = useQuery({
    queryKey: ['/api/currency-pairs'],
    queryFn: () => forexAPI.getCurrencyPairs(),
    refetchInterval: 3000, // Real-time updates
  });

  const { data: forexRates } = useQuery({
    queryKey: ['/api/forex-rates', accountCurrency],
    queryFn: () => forexAPI.getForexRates(accountCurrency),
  });

  const calculatePipValue = async () => {
    const lots = parseFloat(lotSize);
    
    if (!lots || lots <= 0) {
      toast({
        title: 'Invalid Input',
        description: 'Please enter a valid lot size.',
        variant: 'destructive',
      });
      return;
    }

    try {
      const calculatedPipValue = CalculatorUtils.calculatePipValue({
        currencyPair,
        lotSize: lots,
        accountCurrency,
        exchangeRate: forexRates?.conversion_rates?.[currencyPair.split('/')[1]] || 1,
      });

      setPipValue(calculatedPipValue);

      // Save calculation result
      await forexAPI.saveCalculatorResult('pip-value', {
        currencyPair,
        accountCurrency,
        lotSize: lots,
      }, {
        pipValue: calculatedPipValue,
      });

      toast({
        title: 'Calculation Complete',
        description: 'Pip value calculated successfully!',
      });

    } catch (error) {
      toast({
        title: 'Calculation Error',
        description: 'Failed to calculate pip value. Please try again.',
        variant: 'destructive',
      });
    }
  };

  const currentRate = currencyPairs?.find(pair => pair.symbol === currencyPair)?.rate || '1.0000';

  return (
    <>
      <SEOHead
        title="Pip Calculator | Calculate Pip Values for Forex Trading - ForexCalculatorPro"
        description="Free pip calculator to determine pip values using live market rates. Calculate pip worth for any currency pair, lot size, and account currency. Essential forex trading tool."
        keywords="pip calculator, forex pip value, pip worth calculator, forex trading tools, currency pip calculator"
        canonicalUrl="https://forexcalculatorpro.com/pip-calculator"
      />

      <div className="min-h-screen bg-navy-50">
        <Header />

        {/* Hero Section */}
        <section className="navy-gradient text-white py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                Professional <span className="text-gold-400">Pip Calculator</span>
              </h1>
              <p className="text-xl mb-8 text-navy-100 max-w-3xl mx-auto">
                Calculate pip values using live market rates for accurate position sizing and profit/loss estimation across all forex pairs.
              </p>
            </div>
          </div>
        </section>

        {/* Main Calculator Section */}
        <section className="py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Calculator Card */}
              <div className="lg:col-span-2">
                <Card className="calculator-card">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <div className="bg-gold-500 p-2 rounded-lg mr-3">
                        <Zap className="w-6 h-6 text-white" />
                      </div>
                      Pip Value Calculator
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      {/* Currency Pair Selection */}
                      <div className="space-y-2">
                        <Label htmlFor="currencyPair">Currency Pair</Label>
                        <Select value={currencyPair} onValueChange={setCurrencyPair}>
                          <SelectTrigger className="input-field">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <div className="px-2 py-1 text-xs font-semibold text-navy-700 bg-navy-50">
                              Major Pairs
                            </div>
                            {pairGroups.major.map((pair) => (
                              <SelectItem key={pair} value={pair}>
                                {pair}
                              </SelectItem>
                            ))}
                            <div className="px-2 py-1 text-xs font-semibold text-navy-700 bg-navy-50 mt-2">
                              Minor Pairs
                            </div>
                            {pairGroups.minor.map((pair) => (
                              <SelectItem key={pair} value={pair}>
                                {pair}
                              </SelectItem>
                            ))}
                            <div className="px-2 py-1 text-xs font-semibold text-navy-700 bg-navy-50 mt-2">
                              Metals & Commodities
                            </div>
                            {pairGroups.metals.map((pair) => (
                              <SelectItem key={pair} value={pair}>
                                {pair}
                              </SelectItem>
                            ))}
                            {pairGroups.energies.map((pair) => (
                              <SelectItem key={pair} value={pair}>
                                {pair}
                              </SelectItem>
                            ))}
                            <div className="px-2 py-1 text-xs font-semibold text-navy-700 bg-navy-50 mt-2">
                              Indices & Crypto
                            </div>
                            {pairGroups.indices.map((pair) => (
                              <SelectItem key={pair} value={pair}>
                                {pair}
                              </SelectItem>
                            ))}
                            {pairGroups.crypto.map((pair) => (
                              <SelectItem key={pair} value={pair}>
                                {pair}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      {/* Account Currency */}
                      <div className="space-y-2">
                        <Label htmlFor="accountCurrency">Account Currency</Label>
                        <Select value={accountCurrency} onValueChange={setAccountCurrency}>
                          <SelectTrigger className="input-field">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {MAJOR_CURRENCIES.map((currency) => (
                              <SelectItem key={currency.code} value={currency.code}>
                                {currency.name} ({currency.code})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      {/* Lot Size */}
                      <div className="space-y-2">
                        <Label htmlFor="lotSize">Lot Size</Label>
                        <Input
                          id="lotSize"
                          type="number"
                          placeholder="1"
                          step="0.01"
                          value={lotSize}
                          onChange={(e) => setLotSize(e.target.value)}
                          className="input-field"
                        />
                        <div className="text-xs text-navy-600">
                          Standard lot = 1.0, Mini lot = 0.1, Micro lot = 0.01
                        </div>
                      </div>

                      {/* Current Rate Display */}
                      <div className="space-y-2">
                        <Label>Live Market Rate</Label>
                        <div className="input-field bg-navy-50 flex items-center justify-center py-4">
                          <AnimatedRateDisplay 
                            rate={currentRate}
                            symbol={currencyPair}
                            size="lg"
                            className="justify-center"
                          />
                        </div>
                        <div className="text-xs text-navy-600 flex items-center justify-center">
                          <span>Real-time updates every 3 seconds</span>
                        </div>
                      </div>
                    </div>

                    <Button 
                      onClick={calculatePipValue}
                      disabled={isLoading}
                      className="btn-primary w-full"
                    >
                      <Zap className="w-5 h-5 mr-2" />
                      Calculate Pip Value
                    </Button>

                    {/* Results Panel */}
                    {pipValue !== null && (
                      <div className="mt-8 p-6 bg-navy-50 rounded-lg">
                        <h3 className="text-lg font-semibold text-navy-900 mb-4">Pip Value Result</h3>
                        <div className="grid md:grid-cols-2 gap-4">
                          <Card className="border">
                            <CardContent className="p-6 text-center">
                              <div className="text-3xl font-bold text-gold-600 mb-2">
                                {accountCurrency === 'USD' ? '$' : ''}{pipValue.toFixed(2)}
                              </div>
                              <div className="text-sm text-navy-600">Per Pip Value</div>
                              <div className="text-xs text-navy-500 mt-1">
                                For {parseFloat(lotSize)} lots of {currencyPair}
                              </div>
                            </CardContent>
                          </Card>
                          <Card className="border">
                            <CardContent className="p-6 text-center">
                              <div className="text-3xl font-bold text-green-600 mb-2">
                                {accountCurrency === 'USD' ? '$' : ''}{(pipValue * 10).toFixed(2)}
                              </div>
                              <div className="text-sm text-navy-600">10 Pips Value</div>
                              <div className="text-xs text-navy-500 mt-1">
                                Typical stop loss value
                              </div>
                            </CardContent>
                          </Card>
                        </div>
                        
                        {/* Pip Value Table */}
                        <div className="mt-6">
                          <h4 className="font-semibold text-navy-900 mb-3">Pip Values for Different Lot Sizes</h4>
                          <div className="overflow-x-auto">
                            <table className="w-full text-sm">
                              <thead>
                                <tr className="border-b">
                                  <th className="text-left py-2 text-navy-700">Lot Size</th>
                                  <th className="text-left py-2 text-navy-700">Units</th>
                                  <th className="text-left py-2 text-navy-700">Pip Value</th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr className="border-b">
                                  <td className="py-2">1.0 (Standard)</td>
                                  <td className="py-2">100,000</td>
                                  <td className="py-2 font-semibold">
                                    {accountCurrency === 'USD' ? '$' : ''}{CalculatorUtils.calculatePipValue({
                                      currencyPair,
                                      lotSize: 1,
                                      accountCurrency,
                                      exchangeRate: forexRates?.conversion_rates?.[currencyPair.split('/')[1]] || 1,
                                    }).toFixed(2)}
                                  </td>
                                </tr>
                                <tr className="border-b">
                                  <td className="py-2">0.1 (Mini)</td>
                                  <td className="py-2">10,000</td>
                                  <td className="py-2 font-semibold">
                                    {accountCurrency === 'USD' ? '$' : ''}{CalculatorUtils.calculatePipValue({
                                      currencyPair,
                                      lotSize: 0.1,
                                      accountCurrency,
                                      exchangeRate: forexRates?.conversion_rates?.[currencyPair.split('/')[1]] || 1,
                                    }).toFixed(2)}
                                  </td>
                                </tr>
                                <tr>
                                  <td className="py-2">0.01 (Micro)</td>
                                  <td className="py-2">1,000</td>
                                  <td className="py-2 font-semibold">
                                    {accountCurrency === 'USD' ? '$' : ''}{CalculatorUtils.calculatePipValue({
                                      currencyPair,
                                      lotSize: 0.01,
                                      accountCurrency,
                                      exchangeRate: forexRates?.conversion_rates?.[currencyPair.split('/')[1]] || 1,
                                    }).toFixed(2)}
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Educational Content */}
                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle>Understanding Pip Values</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4 text-sm text-navy-600">
                    <p>
                      A pip (Percentage in Point) is the smallest price movement in a currency pair. For most pairs, 
                      a pip is the fourth decimal place (0.0001), but for JPY pairs, it's the second decimal place (0.01).
                    </p>
                    <div className="space-y-2">
                      <h4 className="font-semibold text-navy-900">Key Points:</h4>
                      <ul className="list-disc pl-5 space-y-1">
                        <li>Pip values depend on the currency pair, lot size, and your account currency</li>
                        <li>USD account trading EUR/USD: 1 pip = $10 per standard lot</li>
                        <li>JPY pairs: 1 pip = 0.01 (not 0.0001)</li>
                        <li>Accurate pip values are essential for proper risk management</li>
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Side Panel */}
              <div className="space-y-6">
                {/* Quick Tools */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Related Tools</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <a href="/position-size-calculator" className="flex items-center p-3 hover:bg-navy-50 rounded-lg transition-colors group">
                      <div className="bg-gold-100 p-2 rounded mr-3 group-hover:bg-gold-200">
                        <Calculator className="w-4 h-4 text-gold-600" />
                      </div>
                      <span className="text-navy-700 font-medium">Position Size Calculator</span>
                    </a>
                    <a href="/profit-calculator" className="flex items-center p-3 hover:bg-navy-50 rounded-lg transition-colors group">
                      <div className="bg-gold-100 p-2 rounded mr-3 group-hover:bg-gold-200">
                        <DollarSign className="w-4 h-4 text-gold-600" />
                      </div>
                      <span className="text-navy-700 font-medium">Profit Calculator</span>
                    </a>
                    <a href="/compounding-calculator" className="flex items-center p-3 hover:bg-navy-50 rounded-lg transition-colors group">
                      <div className="bg-gold-100 p-2 rounded mr-3 group-hover:bg-gold-200">
                        <TrendingUp className="w-4 h-4 text-gold-600" />
                      </div>
                      <span className="text-navy-700 font-medium">Compounding Calculator</span>
                    </a>
                  </CardContent>
                </Card>

                {/* Market Data */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Live Rates</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 text-sm">
                      {currencyPairs?.slice(0, 6).map((pair) => (
                        <div key={pair.symbol} className="flex justify-between items-center">
                          <span className="text-navy-600">{pair.symbol}</span>
                          <span className="font-semibold text-green-600">
                            {parseFloat(pair.rate.toString()).toFixed(5)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
}
