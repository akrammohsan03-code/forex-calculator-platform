import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import SEOHead from '@/components/seo-head';
import { AlertTriangle, Shield, Info, ExternalLink } from 'lucide-react';

export default function Disclaimer() {
  return (
    <>
      <SEOHead
        title="Disclaimer - ForexCalculatorPro"
        description="Important disclaimer and risk warnings for using ForexCalculatorPro trading calculators and financial tools."
        canonicalUrl="https://forexcalculatorpro.com/disclaimer"
      />
      
      <div className="min-h-screen bg-navy-50">
        <Header />

        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="bg-white rounded-lg shadow-lg p-8 md:p-12">
            <div className="flex items-center mb-8">
              <div className="bg-red-500 p-3 rounded-lg mr-4">
                <AlertTriangle className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-3xl md:text-4xl font-bold text-navy-900">Disclaimer</h1>
                <p className="text-navy-600 mt-2">Important Risk Warnings and Legal Information</p>
              </div>
            </div>

            {/* Risk Warning Banner */}
            <div className="bg-red-50 border-l-4 border-red-500 p-6 mb-8">
              <div className="flex items-start">
                <AlertTriangle className="w-8 h-8 text-red-500 mr-4 mt-1 flex-shrink-0" />
                <div>
                  <h2 className="text-xl font-bold text-red-800 mb-3">IMPORTANT RISK WARNING</h2>
                  <p className="text-red-700 leading-relaxed">
                    Trading in foreign exchange, commodities, cryptocurrencies, and other financial instruments involves substantial risk of loss and is not suitable for all investors. Past performance is not indicative of future results. You should carefully consider whether such trading is suitable for you in light of your circumstances, knowledge, and financial resources.
                  </p>
                </div>
              </div>
            </div>

            <div className="prose max-w-none">
              <div className="space-y-8">
                
                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">General Disclaimer</h2>
                  <p className="text-navy-700 leading-relaxed">
                    The information provided by ForexCalculatorPro ("we," "us," or "our") on this website is for general informational and educational purposes only. All information on the site is provided in good faith, however we make no representation or warranty of any kind, express or implied, regarding the accuracy, adequacy, validity, reliability, availability or completeness of any information on the site.
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">Not Financial Advice</h2>
                  <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-4">
                    <div className="flex">
                      <Info className="w-6 h-6 text-yellow-600 mr-3 mt-0.5" />
                      <div>
                        <p className="text-navy-700 leading-relaxed">
                          <strong>No Investment Advice:</strong> The calculators, tools, and content provided on this website do not constitute financial, investment, trading, or other types of advice or recommendations. You should not treat any of the website's content as such.
                        </p>
                      </div>
                    </div>
                  </div>
                  <p className="text-navy-700 leading-relaxed">
                    Before making any financial decisions, you should conduct your own research, review, analyze and verify our content. Trading is a high-risk activity that can lead to major losses, therefore please consult your financial advisor before making any decision.
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">Trading Risk Disclosures</h2>
                  
                  <div className="grid md:grid-cols-2 gap-6 mb-6">
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h3 className="font-semibold text-navy-900 mb-2">Forex Trading Risks</h3>
                      <ul className="text-sm text-navy-600 space-y-1">
                        <li>• High volatility and leverage</li>
                        <li>• Currency fluctuations</li>
                        <li>• Economic and political events</li>
                        <li>• Market liquidity variations</li>
                      </ul>
                    </div>
                    
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h3 className="font-semibold text-navy-900 mb-2">Commodity Trading Risks</h3>
                      <ul className="text-sm text-navy-600 space-y-1">
                        <li>• Supply and demand factors</li>
                        <li>• Weather and natural disasters</li>
                        <li>• Storage and transportation costs</li>
                        <li>• Regulatory changes</li>
                      </ul>
                    </div>
                  </div>

                  <p className="text-navy-700 leading-relaxed">
                    You could lose some or all of your initial investment; do not invest money that you cannot afford to lose. You should be aware of all the risks associated with trading and seek advice from an independent financial advisor if you have any doubts.
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">Accuracy and Reliability</h2>
                  <p className="text-navy-700 leading-relaxed mb-4">
                    While we strive to provide accurate and up-to-date information, we make no warranties about the completeness, reliability, and accuracy of this information. Any action you take upon the information on this website is strictly at your own risk.
                  </p>
                  
                  <div className="bg-blue-50 border-l-4 border-blue-400 p-4">
                    <div className="flex">
                      <Shield className="w-6 h-6 text-blue-600 mr-3 mt-0.5" />
                      <div>
                        <p className="text-navy-700 leading-relaxed">
                          <strong>Verification Required:</strong> All calculations and data should be verified independently before making any trading decisions. Market conditions change rapidly, and our tools should be used as a reference only.
                        </p>
                      </div>
                    </div>
                  </div>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">External Links Disclaimer</h2>
                  <p className="text-navy-700 leading-relaxed">
                    Our website may contain links to external websites that are not provided or maintained by us. We do not guarantee the accuracy, relevance, timeliness, or completeness of any information on these external websites. The inclusion of any links does not necessarily imply a recommendation or endorsement of the views expressed within them.
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">Limitation of Liability</h2>
                  <p className="text-navy-700 leading-relaxed mb-4">
                    In no event shall ForexCalculatorPro, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, punitive, consequential, or similar damages whatsoever (including, but not limited to, damages for loss of data, information, revenue, profits, or other business or personal losses) arising out of the use of, or inability to use, the calculators or information provided on this website.
                  </p>
                  
                  <p className="text-navy-700 leading-relaxed">
                    This includes any losses that may be attributable to errors, omissions, or other inaccuracies in the website or its content, or the use of any content posted, emailed, transmitted, or otherwise made available via the website.
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">Professional Consultation</h2>
                  <p className="text-navy-700 leading-relaxed">
                    We strongly recommend that you consult with qualified financial professionals before making any investment decisions. This may include consulting with:
                  </p>
                  <ul className="list-disc list-inside text-navy-700 space-y-2 mt-4">
                    <li>Licensed financial advisors</li>
                    <li>Certified public accountants</li>
                    <li>Tax professionals</li>
                    <li>Legal counsel specializing in financial matters</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">Regulatory Compliance</h2>
                  <p className="text-navy-700 leading-relaxed">
                    ForexCalculatorPro is not a licensed financial institution, broker, or advisor. We do not provide trading services, hold client funds, or execute trades. Users are responsible for ensuring their trading activities comply with applicable laws and regulations in their jurisdiction.
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">Updates to Disclaimer</h2>
                  <p className="text-navy-700 leading-relaxed">
                    We reserve the right to modify this disclaimer at any time. Changes will be effective immediately upon posting on the website. Your continued use of the website following the posting of changes constitutes acceptance of those changes.
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-navy-900 mb-4">Contact Information</h2>
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <p className="text-navy-700 leading-relaxed mb-4">
                      If you have any questions about this disclaimer or need clarification on any point, please contact us:
                    </p>
                    <div className="space-y-2 text-navy-700">
                      <p><strong>Email:</strong> akrammohsan03@gmail.com</p>
                      <p><strong>Address:</strong> House 456, Street No 11, J2 Block, Johar Town, Lahore, Pakistan</p>
                      <p><strong>Website:</strong> forexcalculatorpro.com</p>
                    </div>
                  </div>
                </section>

                <div className="bg-red-50 border border-red-200 p-6 rounded-lg mt-8">
                  <div className="flex items-start">
                    <AlertTriangle className="w-6 h-6 text-red-500 mr-3 mt-1" />
                    <div>
                      <h3 className="text-lg font-semibold text-red-800 mb-2">Final Warning</h3>
                      <p className="text-red-700 leading-relaxed">
                        By using ForexCalculatorPro, you acknowledge that you have read, understood, and agreed to this disclaimer. 
                        You accept full responsibility for your trading decisions and any resulting profits or losses.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <Footer />
      </div>
    </>
  );
}