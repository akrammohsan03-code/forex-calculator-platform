export interface InstrumentInfo {
  code: string;
  name: string;
  symbol: string;
  category: 'major' | 'minor' | 'exotic' | 'crypto' | 'metal' | 'energy' | 'index';
  type: 'currency' | 'commodity' | 'index';
  flag?: string;
}

// Major Forex Currencies
export const MAJOR_CURRENCIES: InstrumentInfo[] = [
  { code: 'USD', name: 'US Dollar', symbol: '$', category: 'major', type: 'currency' },
  { code: 'EUR', name: 'Euro', symbol: '€', category: 'major', type: 'currency' },
  { code: 'GBP', name: 'British Pound', symbol: '£', category: 'major', type: 'currency' },
  { code: 'JPY', name: 'Japanese Yen', symbol: '¥', category: 'major', type: 'currency' },
  { code: 'CHF', name: 'Swiss Franc', symbol: 'CHF', category: 'major', type: 'currency' },
  { code: 'AUD', name: 'Australian Dollar', symbol: 'A$', category: 'major', type: 'currency' },
  { code: 'CAD', name: 'Canadian Dollar', symbol: 'C$', category: 'major', type: 'currency' },
  { code: 'NZD', name: 'New Zealand Dollar', symbol: 'NZ$', category: 'major', type: 'currency' },
];

// Major Forex Pairs
export const MAJOR_PAIRS = [
  'EUR/USD', 'GBP/USD', 'USD/JPY', 'USD/CHF', 
  'AUD/USD', 'USD/CAD', 'NZD/USD'
];

// Minor Forex Pairs (Cross Currency Pairs)
export const MINOR_PAIRS = [
  'EUR/GBP', 'EUR/CHF', 'EUR/AUD', 'EUR/CAD', 'EUR/JPY', 'EUR/NZD',
  'GBP/CHF', 'GBP/AUD', 'GBP/CAD', 'GBP/JPY', 'GBP/NZD',
  'AUD/CHF', 'AUD/CAD', 'AUD/JPY', 'AUD/NZD',
  'CAD/CHF', 'CAD/JPY', 'CHF/JPY', 
  'NZD/CHF', 'NZD/CAD', 'NZD/JPY'
];

// Exotic Currencies
export const EXOTIC_CURRENCIES: InstrumentInfo[] = [
  { code: 'ZAR', name: 'South African Rand', symbol: 'R', category: 'exotic', type: 'currency' },
  { code: 'MXN', name: 'Mexican Peso', symbol: 'MX$', category: 'exotic', type: 'currency' },
  { code: 'SGD', name: 'Singapore Dollar', symbol: 'S$', category: 'exotic', type: 'currency' },
  { code: 'HKD', name: 'Hong Kong Dollar', symbol: 'HK$', category: 'exotic', type: 'currency' },
  { code: 'NOK', name: 'Norwegian Krone', symbol: 'kr', category: 'exotic', type: 'currency' },
  { code: 'SEK', name: 'Swedish Krona', symbol: 'kr', category: 'exotic', type: 'currency' },
  { code: 'DKK', name: 'Danish Krone', symbol: 'kr', category: 'exotic', type: 'currency' },
  { code: 'TRY', name: 'Turkish Lira', symbol: '₺', category: 'exotic', type: 'currency' },
  { code: 'PLN', name: 'Polish Złoty', symbol: 'zł', category: 'exotic', type: 'currency' },
  { code: 'CZK', name: 'Czech Koruna', symbol: 'Kč', category: 'exotic', type: 'currency' },
  { code: 'HUF', name: 'Hungarian Forint', symbol: 'Ft', category: 'exotic', type: 'currency' },
  { code: 'RUB', name: 'Russian Ruble', symbol: '₽', category: 'exotic', type: 'currency' },
  { code: 'BRL', name: 'Brazilian Real', symbol: 'R$', category: 'exotic', type: 'currency' },
  { code: 'INR', name: 'Indian Rupee', symbol: '₹', category: 'exotic', type: 'currency' },
  { code: 'CNY', name: 'Chinese Yuan', symbol: '¥', category: 'exotic', type: 'currency' },
  { code: 'KRW', name: 'South Korean Won', symbol: '₩', category: 'exotic', type: 'currency' },
  { code: 'THB', name: 'Thai Baht', symbol: '฿', category: 'exotic', type: 'currency' },
  { code: 'MYR', name: 'Malaysian Ringgit', symbol: 'RM', category: 'exotic', type: 'currency' },
  { code: 'PHP', name: 'Philippine Peso', symbol: '₱', category: 'exotic', type: 'currency' },
  { code: 'IDR', name: 'Indonesian Rupiah', symbol: 'Rp', category: 'exotic', type: 'currency' },
];

// Exotic Forex Pairs
export const EXOTIC_PAIRS = [
  'USD/ZAR', 'USD/MXN', 'USD/SGD', 'USD/HKD', 'USD/NOK', 'USD/SEK', 'USD/DKK',
  'USD/TRY', 'USD/PLN', 'USD/CZK', 'USD/HUF', 'USD/RUB', 'USD/BRL', 'USD/INR',
  'USD/CNY', 'USD/KRW', 'USD/THB', 'USD/MYR', 'USD/PHP', 'USD/IDR',
  'EUR/ZAR', 'EUR/MXN', 'EUR/SGD', 'EUR/HKD', 'EUR/NOK', 'EUR/SEK', 'EUR/DKK',
  'EUR/TRY', 'EUR/PLN', 'EUR/CZK', 'EUR/HUF', 'EUR/RUB', 'EUR/BRL',
  'GBP/ZAR', 'GBP/MXN', 'GBP/SGD', 'GBP/HKD', 'GBP/NOK', 'GBP/SEK', 'GBP/DKK',
  'GBP/TRY', 'GBP/PLN', 'GBP/CZK', 'GBP/HUF',
];

// Precious Metals
export const METALS: InstrumentInfo[] = [
  { code: 'XAUUSD', name: 'Gold vs US Dollar', symbol: 'Au', category: 'metal', type: 'commodity' },
  { code: 'XAGUSD', name: 'Silver vs US Dollar', symbol: 'Ag', category: 'metal', type: 'commodity' },
  { code: 'XPTUSD', name: 'Platinum vs US Dollar', symbol: 'Pt', category: 'metal', type: 'commodity' },
  { code: 'XPDUSD', name: 'Palladium vs US Dollar', symbol: 'Pd', category: 'metal', type: 'commodity' },
  { code: 'XAUEUR', name: 'Gold vs Euro', symbol: 'Au', category: 'metal', type: 'commodity' },
  { code: 'XAUGBP', name: 'Gold vs British Pound', symbol: 'Au', category: 'metal', type: 'commodity' },
  { code: 'XAUJPY', name: 'Gold vs Japanese Yen', symbol: 'Au', category: 'metal', type: 'commodity' },
  { code: 'XAUAUD', name: 'Gold vs Australian Dollar', symbol: 'Au', category: 'metal', type: 'commodity' },
  { code: 'XAUCHF', name: 'Gold vs Swiss Franc', symbol: 'Au', category: 'metal', type: 'commodity' },
  { code: 'XAUCAD', name: 'Gold vs Canadian Dollar', symbol: 'Au', category: 'metal', type: 'commodity' },
];

// Energy Commodities
export const ENERGIES: InstrumentInfo[] = [
  { code: 'USOIL', name: 'US Crude Oil (WTI)', symbol: 'Oil', category: 'energy', type: 'commodity' },
  { code: 'UKOIL', name: 'UK Brent Crude Oil', symbol: 'Brent', category: 'energy', type: 'commodity' },
  { code: 'NGAS', name: 'Natural Gas', symbol: 'Gas', category: 'energy', type: 'commodity' },
  { code: 'OIL', name: 'Crude Oil', symbol: 'Oil', category: 'energy', type: 'commodity' },
  { code: 'XNGUSD', name: 'Natural Gas vs US Dollar', symbol: 'NG', category: 'energy', type: 'commodity' },
];

// Major Stock Indices
export const INDICES: InstrumentInfo[] = [
  { code: 'US100', name: 'NASDAQ 100', symbol: 'NDX', category: 'index', type: 'index' },
  { code: 'US30', name: 'Dow Jones 30', symbol: 'DJI', category: 'index', type: 'index' },
  { code: 'SPX500', name: 'S&P 500', symbol: 'SPX', category: 'index', type: 'index' },
  { code: 'UK100', name: 'FTSE 100', symbol: 'UKX', category: 'index', type: 'index' },
  { code: 'GER40', name: 'DAX 40', symbol: 'DAX', category: 'index', type: 'index' },
  { code: 'FRA40', name: 'CAC 40', symbol: 'CAC', category: 'index', type: 'index' },
  { code: 'JPN225', name: 'Nikkei 225', symbol: 'N225', category: 'index', type: 'index' },
  { code: 'AUS200', name: 'ASX 200', symbol: 'AS51', category: 'index', type: 'index' },
  { code: 'HK50', name: 'Hong Kong 50', symbol: 'HSI', category: 'index', type: 'index' },
  { code: 'EUSTX50', name: 'Euro Stoxx 50', symbol: 'SX5E', category: 'index', type: 'index' },
  { code: 'ITA40', name: 'FTSE MIB', symbol: 'FTSEMIB', category: 'index', type: 'index' },
  { code: 'ESP35', name: 'IBEX 35', symbol: 'IBEX', category: 'index', type: 'index' },
  { code: 'NLD25', name: 'AEX 25', symbol: 'AEX', category: 'index', type: 'index' },
  { code: 'SWI20', name: 'SMI 20', symbol: 'SMI', category: 'index', type: 'index' },
  { code: 'CHINAH', name: 'China A50', symbol: 'FTXIN9', category: 'index', type: 'index' },
];

// Cryptocurrencies
export const CRYPTOCURRENCIES: InstrumentInfo[] = [
  { code: 'BTCUSD', name: 'Bitcoin vs US Dollar', symbol: '₿', category: 'crypto', type: 'currency' },
  { code: 'ETHUSD', name: 'Ethereum vs US Dollar', symbol: 'Ξ', category: 'crypto', type: 'currency' },
  { code: 'BNBUSD', name: 'Binance Coin vs US Dollar', symbol: 'BNB', category: 'crypto', type: 'currency' },
  { code: 'ADAUSD', name: 'Cardano vs US Dollar', symbol: 'ADA', category: 'crypto', type: 'currency' },
  { code: 'DOTUSD', name: 'Polkadot vs US Dollar', symbol: 'DOT', category: 'crypto', type: 'currency' },
  { code: 'XRPUSD', name: 'Ripple vs US Dollar', symbol: 'XRP', category: 'crypto', type: 'currency' },
  { code: 'LTCUSD', name: 'Litecoin vs US Dollar', symbol: 'Ł', category: 'crypto', type: 'currency' },
  { code: 'LINKUSD', name: 'Chainlink vs US Dollar', symbol: 'LINK', category: 'crypto', type: 'currency' },
  { code: 'SOLUSD', name: 'Solana vs US Dollar', symbol: 'SOL', category: 'crypto', type: 'currency' },
  { code: 'AVAXUSD', name: 'Avalanche vs US Dollar', symbol: 'AVAX', category: 'crypto', type: 'currency' },
  { code: 'MATICUSD', name: 'Polygon vs US Dollar', symbol: 'MATIC', category: 'crypto', type: 'currency' },
  { code: 'UNIUSD', name: 'Uniswap vs US Dollar', symbol: 'UNI', category: 'crypto', type: 'currency' },
];

// All Trading Pairs (Comprehensive)
export const ALL_PAIRS = [
  ...MAJOR_PAIRS,
  ...MINOR_PAIRS,
  ...EXOTIC_PAIRS,
];

// Helper Functions
export const getAllInstruments = () => [
  ...MAJOR_CURRENCIES,
  ...EXOTIC_CURRENCIES,
  ...METALS,
  ...ENERGIES,
  ...INDICES,
  ...CRYPTOCURRENCIES,
];

export const getAllCurrencies = () => [
  ...MAJOR_CURRENCIES,
  ...EXOTIC_CURRENCIES,
];

export const getInstrumentsByCategory = (category: InstrumentInfo['category']) =>
  getAllInstruments().filter(instrument => instrument.category === category);

export const getInstrumentsByType = (type: InstrumentInfo['type']) =>
  getAllInstruments().filter(instrument => instrument.type === type);

export const getInstrumentByCode = (code: string) => 
  getAllInstruments().find(instrument => instrument.code === code);

export const getCurrencyByCode = (code: string) => 
  getAllCurrencies().find(currency => currency.code === code);

export const formatCurrencyPair = (base: string, quote: string) => `${base}/${quote}`;

export const parseCurrencyPair = (pair: string) => {
  const [base, quote] = pair.split('/');
  return { base, quote };
};

export const isPairSupported = (pair: string) => {
  return ALL_PAIRS.includes(pair) || 
         METALS.some(m => m.code === pair) ||
         ENERGIES.some(e => e.code === pair) ||
         INDICES.some(i => i.code === pair) ||
         CRYPTOCURRENCIES.some(c => c.code === pair);
};

// Get all tradeable instruments grouped by category
export const getInstrumentsByGroups = () => ({
  major: MAJOR_CURRENCIES,
  exotic: EXOTIC_CURRENCIES,
  metals: METALS,
  energies: ENERGIES,
  indices: INDICES,
  crypto: CRYPTOCURRENCIES,
});

// Get all pairs grouped by category
export const getPairsByGroups = () => ({
  major: MAJOR_PAIRS,
  minor: MINOR_PAIRS,
  exotic: EXOTIC_PAIRS,
  metals: METALS.map(m => m.code),
  energies: ENERGIES.map(e => e.code),
  indices: INDICES.map(i => i.code),
  crypto: CRYPTOCURRENCIES.map(c => c.code),
});
