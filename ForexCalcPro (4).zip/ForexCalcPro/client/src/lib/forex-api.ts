export interface ForexRate {
  base_code: string;
  conversion_rates: Record<string, number>;
  time_last_update_utc: string;
}

export interface CurrencyPair {
  symbol: string;
  rate: number;
  lastUpdated: string;
}

class ForexAPI {
  private baseUrl = '/api';

  async getForexRates(baseCurrency: string = 'USD'): Promise<ForexRate> {
    const response = await fetch(`${this.baseUrl}/forex-rates/${baseCurrency}`);
    if (!response.ok) {
      throw new Error('Failed to fetch forex rates');
    }
    return response.json();
  }

  async getCurrencyPairs(): Promise<CurrencyPair[]> {
    const response = await fetch(`${this.baseUrl}/currency-pairs`);
    if (!response.ok) {
      throw new Error('Failed to fetch currency pairs');
    }
    return response.json();
  }

  async getCurrencyPair(symbol: string): Promise<CurrencyPair> {
    const response = await fetch(`${this.baseUrl}/currency-pairs/${symbol}`);
    if (!response.ok) {
      throw new Error('Failed to fetch currency pair');
    }
    return response.json();
  }

  async saveCalculatorResult(calculatorType: string, inputData: any, result: any) {
    const response = await fetch(`${this.baseUrl}/calculator-results`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        calculatorType,
        inputData,
        result,
      }),
    });
    
    if (!response.ok) {
      throw new Error('Failed to save calculator result');
    }
    
    return response.json();
  }

  // Calculate exchange rate between any two currencies
  async getExchangeRate(fromCurrency: string, toCurrency: string): Promise<number> {
    try {
      const rates = await this.getForexRates(fromCurrency);
      return rates.conversion_rates[toCurrency] || 1;
    } catch (error) {
      console.error('Failed to get exchange rate:', error);
      return 1;
    }
  }
}

export const forexAPI = new ForexAPI();
