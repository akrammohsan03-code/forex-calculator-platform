# WordPress Page Setup Instructions

## Step-by-Step Guide to Add ForexCalculatorPro to WordPress

### Step 1: Create New Page in WordPress

1. **Login to WordPress Admin**
   - Go to: yourwordpresssite.com/wp-admin
   - Enter your username and password

2. **Create New Page**
   - Click "Pages" → "Add New" in left sidebar
   - Page Title: "Forex Calculators" or "Trading Tools"

### Step 2: Add the Code

1. **Switch to HTML View**
   - In page editor, click "Text" tab (Classic Editor)
   - OR click ⋯ menu → "Code Editor" (Gutenberg/Block Editor)

2. **Copy and Paste Code**
   - Copy ALL content from `wordpress-page-code.html`
   - Paste into the HTML editor
   - **IMPORTANT**: Replace "YOUR-DOMAIN-HERE.com" with your actual website URL

### Step 3: Configure Your Domain

**If using HosterPK hosting:**
Replace this line:
```html
src="https://YOUR-DOMAIN-HERE.com"
```

With your actual domain:
```html
src="https://yourdomain.com"
```

**If using Replit deployment:**
Replace with your Replit app URL:
```html
src="https://your-repl-name.yourusername.replit.app"
```

### Step 4: Publish the Page

1. **Preview First**
   - Click "Preview" to test the page
   - Check that iframe loads correctly
   - Test on mobile device

2. **Publish**
   - Click "Publish" button
   - Your page is now live!

### Step 5: Add to Navigation (Optional)

1. **Add to Menu**
   - Go to Appearance → Menus
   - Add your new page to main navigation
   - Save menu

2. **Set as Homepage (Optional)**
   - Go to Settings → Reading
   - Select "A static page"
   - Choose your forex calculators page

### What You'll Get:

✅ **Professional Header**: Navy blue with gold ForexCalculatorPro branding
✅ **Full Website**: All 11 calculators, charts, news, legal pages
✅ **Mobile Responsive**: Automatic sizing for all devices
✅ **Loading Animation**: Professional loading message
✅ **Contact Info**: Your email and Lahore address displayed
✅ **SEO Content**: Text content for search engine optimization
✅ **Feature Highlights**: Professional sections describing your tools

### Troubleshooting:

**If iframe doesn't load:**
- Check your website URL is correct
- Ensure your website is live and accessible
- Wait 24-48 hours for DNS propagation

**If styling looks wrong:**
- Make sure you copied ALL the CSS code
- Check WordPress theme doesn't override styles
- Try adding `!important` to CSS rules if needed

**Mobile display issues:**
- Test the responsive breakpoints
- Adjust iframe height in CSS if needed

### Advanced Customization:

**Change colors to match your theme:**
```css
.forex-header {
    background: linear-gradient(135deg, #YOUR-COLOR, #YOUR-COLOR2);
}
```

**Adjust iframe height:**
```css
.iframe-wrapper {
    height: 1000px; /* Change this value */
}
```

Your professional ForexCalculatorPro website will be seamlessly integrated into WordPress with full functionality!