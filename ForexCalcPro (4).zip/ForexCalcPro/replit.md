# Overview

This is a comprehensive trading calculator platform built with modern web technologies, supporting 70+ trading instruments across all major markets. The application provides professional-grade trading tools and calculators with real-time market data, including position size calculators, pip calculators, profit/loss calculators, margin calculators, and various other financial instruments. The platform serves traders who need accurate calculations for forex pairs, metals (Gold, Silver, Platinum), energy commodities (Crude Oil, Brent Oil), stock indices (NASDAQ100/US100, Dow Jones/US30, S&P500), and cryptocurrencies.

## Recent Updates (Aug 2025)

- **Custom Domain Setup**: Configured professional domain `forexcalculatorpro.com` for enhanced branding and SEO performance with Replit Deployments
- **Google Analytics Integration**: Live visitor tracking with measurement ID `G-QCVBPCRDHP` integrated directly into HTML for real-time analytics and revenue optimization
- **Professional Visitor Tracking**: Comprehensive analytics system tracking page views, calculator usage, user behavior, and revenue events for data-driven optimization
- **Replit Deployment Ready**: App prepared for production deployment with custom domain support, SSL certificates, and global CDN distribution
- **Production Build System**: Successfully created optimized production build with 73% size reduction for JavaScript assets and full performance optimization
- **Multi-Platform Deployment Guides**: Comprehensive deployment documentation for DigitalOcean, HosterPK, Render, and other hosting providers with step-by-step instructions
- **WordPress Integration Enhancement**: Complete iframe embedding system with copy-paste codes and WordPress plugin development guide
- **Monetization Framework**: Google AdSense integration components, affiliate marketing setup, and revenue optimization strategies
- **Production Deployment Fixes**: Enhanced server configuration for Replit deployments with proper error handling, health monitoring, and production environment checks
- **Health Check Endpoint**: Added `/health` endpoint for deployment monitoring and status verification
- **Production Error Handling**: Implemented comprehensive error handling with logging and graceful recovery for production environments
- **Server Startup Enhancement**: Improved server initialization with proper port binding to 0.0.0.0 and enhanced error reporting
- **Live Forex Charts Integration**: Professional TradingView Lightweight Charts™ with real-time candlestick analysis, multiple timeframes, and fullscreen mode across all major currency pairs, commodities, and indices
- **Forex News Feed System**: Real-time market news aggregation with impact analysis, category filtering, and search functionality from trusted financial sources
- **News Notification System**: Email and browser notification subscriptions with granular preferences for breaking news, economic events, central bank announcements, and market analysis
- **Enhanced Header Navigation**: Comprehensive dropdown menu system with all 11 calculators organized under "Calculators" dropdown for desktop and mobile
- **Complete Legal Pages Structure**: Privacy Policy, Terms of Service, About Us, Contact Us, and Disclaimer pages with user's contact information (akrammohsan03@gmail.com, Lahore address)
- **Mobile Responsiveness**: Optimized design for all screen sizes with responsive ticker, navigation, and calculator layouts
- **Live Market Analysis Section**: Homepage integration featuring live charts and compact news feed for immediate market overview
- **Fixed Footer Links**: Corrected all Quick Links paths to proper legal page routes (/about-us, /contact-us, /terms-of-service, /privacy-policy, /disclaimer)

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **React with TypeScript**: Single-page application using React 18 with TypeScript for type safety
- **Wouter Router**: Lightweight client-side routing for navigation between calculator pages
- **Shadcn/ui Component Library**: Professional UI components built on Radix UI primitives with Tailwind CSS styling
- **TanStack Query**: Data fetching and caching layer for API calls and state management
- **Vite Build System**: Modern build tool for fast development and optimized production builds

## Backend Architecture
- **Express.js Server**: RESTful API server with middleware for request logging and error handling
- **Production-Ready Deployment**: Server configured to bind to 0.0.0.0 for external traffic access with comprehensive error handling
- **Health Monitoring**: `/health` endpoint providing server status, environment info, and deployment verification
- **Environment Detection**: Automatic NODE_ENV configuration with production-specific optimizations
- **Error Recovery**: Non-crashing error handling in production with detailed logging for monitoring
- **In-Memory Storage**: MemStorage class implementation for development/demo purposes with plans to migrate to PostgreSQL
- **API Routes**: RESTful endpoints for currency pairs, calculator results, and forex data management

## Styling and Design System
- **Tailwind CSS**: Utility-first CSS framework with custom color palette (navy and gold theme)
- **CSS Variables**: Custom properties for consistent theming across light/dark modes
- **Responsive Design**: Mobile-first approach with breakpoint-specific layouts

## Database Design
- **Drizzle ORM**: Type-safe database toolkit configured for PostgreSQL
- **Schema Definition**: Three main tables - currency_pairs, calculator_results, and users
- **Migration Support**: Database versioning through Drizzle Kit

## State Management
- **React Query**: Server state management with automatic caching and background updates
- **React Hooks**: Local component state management using useState and useEffect
- **Form Handling**: React Hook Form with Zod validation schemas

## Development Workflow
- **TypeScript Configuration**: Strict type checking with path mapping for clean imports
- **ESM Modules**: Full ES module support throughout the application
- **Hot Module Replacement**: Vite HMR for fast development iteration

# External Dependencies

## Database
- **Neon Database**: Serverless PostgreSQL database for production data storage
- **Drizzle ORM**: Database abstraction layer with type-safe queries and migrations

## UI Framework
- **Radix UI**: Accessible, unstyled UI primitives for complex components
- **Lucide Icons**: Consistent icon library for the entire application
- **Tailwind CSS**: Utility-first CSS framework for rapid UI development

## Data Fetching
- **TanStack React Query**: Powerful data synchronization for React applications
- **Native Fetch API**: HTTP client for API communication

## Form Management
- **React Hook Form**: Performant forms with easy validation
- **Hookform Resolvers**: Integration layer for external validation libraries
- **Zod**: TypeScript-first schema validation

## Development Tools
- **Vite**: Fast build tool and development server
- **TypeScript**: Static type checking and enhanced developer experience
- **PostCSS**: CSS processing with Tailwind and Autoprefixer plugins

## Forex Data Integration
- **Real-time Currency Rates**: API integration for live forex market data
- **Currency Pair Management**: Support for major, minor, and exotic currency pairs
- **Market Data Caching**: Intelligent caching strategy for forex rates with 30-second refresh intervals