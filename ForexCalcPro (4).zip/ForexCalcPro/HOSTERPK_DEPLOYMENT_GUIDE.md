# HosterPK Deployment Guide - Forex Calculator Platform

## 📋 Overview
This guide will help you deploy your forex calculator platform to HosterPK hosting server step-by-step.

## 🚀 Pre-Deployment Checklist

### What You'll Need:
- ✅ Your HosterPK hosting account credentials
- ✅ cPanel access or FTP details
- ✅ Domain name pointed to HosterPK servers
- ✅ Downloaded project ZIP file from Replit

### HosterPK Requirements Check:
- ✅ Node.js support (contact support if unsure)
- ✅ SSH access (for npm install)
- ✅ File upload capability (cPanel/FTP)

## 📁 Project Structure for Deployment

Your exported project contains:
```
forex-calculator-platform/
├── dist/                    # Production build files
├── client/                  # Frontend source
├── server/                  # Backend source  
├── package.json            # Dependencies
├── .env.example            # Environment variables template
└── HOSTERPK_DEPLOYMENT_GUIDE.md
```

## 🔧 Step-by-Step Deployment Process

### Step 1: Prepare Your Files
1. **Download the ZIP** from Replit (3 dots menu → Download as ZIP)
2. **Extract** the ZIP file on your computer
3. **Locate** the `dist` folder (production build)

### Step 2: Connect to HosterPK

#### Method A: Using cPanel (Recommended)
1. Go to your HosterPK cPanel: `https://your-domain.com/cpanel`
2. Login with your credentials
3. Find **File Manager** in cPanel
4. Navigate to `public_html/` folder

#### Method B: Using FTP
1. Download FileZilla or similar FTP client
2. Connect using HosterPK FTP credentials:
   - Host: `your-domain.com` or FTP server provided
   - Username: Your cPanel username
   - Password: Your cPanel password
   - Port: 21 (or as provided)

### Step 3: Upload Your Files

#### For cPanel File Manager:
1. **Select all files** from your extracted project folder
2. **Upload** to `public_html/` directory
3. **Extract** if uploaded as ZIP (right-click → Extract)

#### For FTP:
1. **Select all project files** in FileZilla
2. **Drag and drop** to `/public_html/` folder
3. **Wait** for upload completion

### Step 4: Install Dependencies

#### If HosterPK supports SSH:
```bash
# Connect via SSH
ssh your-username@your-domain.com

# Navigate to your site directory
cd public_html

# Install Node.js dependencies
npm install

# Build production version (if not already built)
npm run build
```

#### If No SSH Access:
Contact HosterPK support to:
1. Install Node.js on your account
2. Run `npm install` in your directory
3. Set up Node.js application

### Step 5: Configure Environment Variables

1. **Create `.env` file** in your root directory
2. **Copy from `.env.example`**:
```env
# Google AdSense Configuration
VITE_GOOGLE_ADSENSE_CLIENT=ca-pub-XXXXXXXXXX

# Server Configuration
NODE_ENV=production
PORT=3000
```

3. **Add your Google AdSense Publisher ID**

### Step 6: Set Up Node.js Application (HosterPK Specific)

#### Check if HosterPK supports Node.js:
1. **Login to cPanel**
2. **Look for "Node.js Selector"** or **"Node.js Apps"**
3. **Create new Node.js application**:
   - **App Root:** `public_html`
   - **App URL:** Your domain
   - **App Startup File:** `server/index.ts`
   - **Node.js Version:** 18.x or higher

#### Alternative: Static File Hosting
If Node.js not supported, deploy as static files:
1. **Upload only the `dist` folder contents**
2. **Copy to `public_html/`**
3. **Your calculators will work as static HTML/JS**

### Step 7: Configure Domain Settings

1. **Ensure domain points** to HosterPK nameservers
2. **Wait for DNS propagation** (24-48 hours max)
3. **Test site access** at your domain

### Step 8: SSL Certificate Setup

1. **Go to cPanel → SSL/TLS**
2. **Install Let's Encrypt** (usually free)
3. **Force HTTPS** redirect
4. **Update AdSense settings** to use HTTPS URLs

## 🔍 Testing Your Deployment

### Verify Each Calculator:
- ✅ Position Size Calculator: `https://yourdomain.com/position-size-calculator`
- ✅ Pip Calculator: `https://yourdomain.com/pip-calculator`
- ✅ Profit Calculator: `https://yourdomain.com/profit-calculator`
- ✅ Margin Calculator: `https://yourdomain.com/margin-calculator`
- ✅ Currency Converter: `https://yourdomain.com/currency-converter`

### Check Functionality:
- ✅ All calculators load properly
- ✅ Calculations work correctly
- ✅ Mobile responsive design
- ✅ AdSense ads display (after approval)

## 🔄 Update WordPress Integration

### Update All Iframe URLs:
**Replace in WordPress:**
```html
<!-- OLD (Replit) -->
<iframe src="https://your-project.replit.app/position-size-calculator" ...>

<!-- NEW (Your Domain) -->
<iframe src="https://yourdomain.com/position-size-calculator" ...>
```

### Bulk Update Method:
1. **WordPress Admin** → **Tools** → **Search Replace DB**
2. **Search:** `your-project.replit.app`
3. **Replace:** `yourdomain.com`
4. **Run** across all posts/pages

## 🚨 Troubleshooting Common Issues

### Issue 1: "Site Not Loading"
**Solutions:**
- Check DNS settings
- Verify file permissions (755 for folders, 644 for files)
- Check .htaccess file

### Issue 2: "npm install fails"
**Solutions:**
- Contact HosterPK to install Node.js
- Use static HTML version instead
- Upload pre-built dist folder

### Issue 3: "Calculators Not Working"
**Solutions:**
- Check JavaScript console for errors
- Verify all files uploaded correctly
- Test individual calculator pages

### Issue 4: "AdSense Not Showing"
**Solutions:**
- Add new domain to AdSense account
- Wait for approval (1-7 days)
- Check ad placement code

## 📞 HosterPK Specific Support

### Contact Information:
- **Support Portal:** HosterPK customer area
- **Live Chat:** Available on HosterPK website
- **Email:** Contact through client area
- **Phone:** Check your welcome email

### Common Requests:
1. **"Please install Node.js on my account"**
2. **"I need SSH access to run npm install"**
3. **"Help me set up a Node.js application"**
4. **"Install SSL certificate for my domain"**

## 💰 Monetization Activation

### After Successful Deployment:

1. **Update Google AdSense:**
   - Add your new domain
   - Wait for approval
   - Monitor earnings

2. **Activate Affiliate Links:**
   - Test all broker referral links
   - Ensure tracking works
   - Monitor conversions

3. **WordPress Integration:**
   - Update all iframe URLs
   - Test embedded calculators
   - Verify mobile responsiveness

## 📈 Performance Optimization

### Speed Improvements:
```apache
# Add to .htaccess file
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css text/javascript application/javascript application/json
</IfModule>

<IfModule mod_expires.c>
    ExpiresActive on
    ExpiresByType text/css "access plus 1 year"
    ExpiresByType application/javascript "access plus 1 year"
    ExpiresByType image/png "access plus 1 year"
    ExpiresByType image/jpg "access plus 1 year"
</IfModule>
```

### CDN Setup (Optional):
- Cloudflare free plan
- Improves global loading speed
- Additional security features

## ✅ Final Checklist

**Pre-Launch:**
- ✅ All files uploaded to HosterPK
- ✅ Dependencies installed
- ✅ Environment variables configured
- ✅ Domain pointing to HosterPK
- ✅ SSL certificate installed

**Post-Launch:**
- ✅ All calculators tested and working
- ✅ WordPress iframes updated
- ✅ AdSense domain added
- ✅ Mobile responsiveness verified
- ✅ Performance optimized

**Monetization:**
- ✅ AdSense ads displaying
- ✅ Affiliate links functional
- ✅ Analytics tracking setup
- ✅ Revenue streams active

## 🎯 Expected Results

After successful deployment:
- **Professional forex calculator platform** running on your domain
- **WordPress integration** working seamlessly
- **Ad revenue generation** from day one
- **Full control** over your profitable trading tools
- **Scalable platform** ready for growth

Your forex calculator platform is now ready to generate revenue independently on HosterPK hosting! 🚀

## 📞 Need Help?

If you encounter issues:
1. **Check this guide** first
2. **Contact HosterPK support** for hosting-specific questions
3. **Test in stages** - don't rush the deployment
4. **Keep backups** of working versions

Good luck with your deployment! 🎯