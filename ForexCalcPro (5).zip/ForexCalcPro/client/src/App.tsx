import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useScrollToTop } from "./hooks/useScrollToTop";
import ScrollToTopButton from "./components/scroll-to-top-button";
import { useEffect } from "react";
import { initGA } from "./lib/analytics";
import { useAnalytics } from "./hooks/use-analytics";

import Home from "@/pages/home";
import PositionSizeCalculator from "@/pages/position-size-calculator";
import PipCalculator from "@/pages/pip-calculator";
import ProfitCalculator from "@/pages/profit-calculator";
import MarginCalculator from "@/pages/margin-calculator";
import CompoundingCalculator from "@/pages/compounding-calculator";
import FibonacciCalculator from "@/pages/fibonacci-calculator";
import PivotCalculator from "@/pages/pivot-calculator";
import DrawdownCalculator from "@/pages/drawdown-calculator";
import RiskOfRuinCalculator from "@/pages/risk-of-ruin-calculator";
import CurrencyConverter from "@/pages/currency-converter";
import CryptoFeesCalculator from "@/pages/crypto-fees-calculator";
import EconomicCalendar from "@/pages/economic-calendar";
import ForexCharts from "@/pages/forex-charts";
import ForexNews from "@/pages/forex-news";
import PrivacyPolicy from "@/pages/privacy-policy";
import TermsOfService from "@/pages/terms-of-service";
import AboutUs from "@/pages/about-us";
import ContactUs from "@/pages/contact-us";
import Disclaimer from "@/pages/disclaimer";
import NotFound from "@/pages/not-found";

function Router() {
  // Enable automatic scroll to top when navigating
  useScrollToTop();
  
  // Track page views with Google Analytics
  useAnalytics();

  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/position-size-calculator" component={PositionSizeCalculator} />
      <Route path="/pip-calculator" component={PipCalculator} />
      <Route path="/profit-calculator" component={ProfitCalculator} />
      <Route path="/margin-calculator" component={MarginCalculator} />
      <Route path="/compounding-calculator" component={CompoundingCalculator} />
      <Route path="/fibonacci-calculator" component={FibonacciCalculator} />
      <Route path="/pivot-calculator" component={PivotCalculator} />
      <Route path="/drawdown-calculator" component={DrawdownCalculator} />
      <Route path="/risk-of-ruin-calculator" component={RiskOfRuinCalculator} />
      <Route path="/currency-converter" component={CurrencyConverter} />
      <Route path="/crypto-fees-calculator" component={CryptoFeesCalculator} />
      <Route path="/economic-calendar" component={EconomicCalendar} />
      <Route path="/forex-charts" component={ForexCharts} />
      <Route path="/forex-news" component={ForexNews} />
      <Route path="/privacy-policy" component={PrivacyPolicy} />
      <Route path="/terms-of-service" component={TermsOfService} />
      <Route path="/about-us" component={AboutUs} />
      <Route path="/contact-us" component={ContactUs} />
      <Route path="/disclaimer" component={Disclaimer} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  // Initialize Google Analytics when app loads
  useEffect(() => {
    // Check if Google Analytics key is provided
    if (!import.meta.env.VITE_GA_MEASUREMENT_ID) {
      console.log('To track visitors, add VITE_GA_MEASUREMENT_ID to your environment variables');
    } else {
      initGA();
    }
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
        <ScrollToTopButton />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
