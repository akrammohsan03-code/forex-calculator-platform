import { useState } from 'react';
import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import SEOHead from '@/components/seo-head';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Activity, AlertTriangle, Calculator, TrendingDown } from 'lucide-react';
import { forexAPI } from '@/lib/forex-api';
import { CalculatorUtils } from '@/lib/calculator-utils';
import { useToast } from '@/hooks/use-toast';

export default function RiskOfRuinCalculator() {
  const [winRate, setWinRate] = useState<string>('60');
  const [averageWin, setAverageWin] = useState<string>('100');
  const [averageLoss, setAverageLoss] = useState<string>('50');
  const [riskPerTrade, setRiskPerTrade] = useState<string>('2');
  const [result, setResult] = useState<number | null>(null);
  const [scenarios, setScenarios] = useState<Array<{ winRate: number; riskOfRuin: number }> | null>(null);
  
  const { toast } = useToast();

  const calculateRiskOfRuin = async () => {
    const win = parseFloat(winRate);
    const avgWin = parseFloat(averageWin);
    const avgLoss = parseFloat(averageLoss);
    const risk = parseFloat(riskPerTrade);
    
    if (!win || !avgWin || !avgLoss || !risk || win < 0 || win > 100 || avgWin <= 0 || avgLoss <= 0 || risk <= 0) {
      toast({
        title: 'Invalid Input',
        description: 'Please enter valid values. Win rate should be 0-100%, other values should be positive.',
        variant: 'destructive',
      });
      return;
    }

    try {
      const riskOfRuin = CalculatorUtils.calculateRiskOfRuin(win, avgWin, avgLoss, risk);
      setResult(riskOfRuin);

      // Calculate different win rate scenarios
      const scenarioResults = [];
      for (let testWinRate = 30; testWinRate <= 80; testWinRate += 5) {
        const scenarioRisk = CalculatorUtils.calculateRiskOfRuin(testWinRate, avgWin, avgLoss, risk);
        scenarioResults.push({
          winRate: testWinRate,
          riskOfRuin: scenarioRisk,
        });
      }
      setScenarios(scenarioResults);

      // Save calculation result
      await forexAPI.saveCalculatorResult('risk-of-ruin', {
        winRate: win,
        averageWin: avgWin,
        averageLoss: avgLoss,
        riskPerTrade: risk,
      }, {
        riskOfRuin,
        scenarios: scenarioResults,
      });

      toast({
        title: 'Calculation Complete',
        description: 'Risk of ruin calculated successfully!',
      });

    } catch (error) {
      toast({
        title: 'Calculation Error',
        description: 'Failed to calculate risk of ruin. Please try again.',
        variant: 'destructive',
      });
    }
  };

  const getRiskLevel = (risk: number) => {
    if (risk <= 1) return { level: 'Very Low', color: 'text-green-600', bg: 'bg-green-100' };
    if (risk <= 5) return { level: 'Low', color: 'text-green-500', bg: 'bg-green-50' };
    if (risk <= 15) return { level: 'Moderate', color: 'text-yellow-600', bg: 'bg-yellow-100' };
    if (risk <= 30) return { level: 'High', color: 'text-orange-600', bg: 'bg-orange-100' };
    return { level: 'Very High', color: 'text-red-600', bg: 'bg-red-100' };
  };

  const riskLevel = result !== null ? getRiskLevel(result) : null;

  return (
    <>
      <SEOHead
        title="Risk of Ruin Calculator | Calculate Probability of Maximum Drawdown - ForexCalculatorPro"
        description="Free risk of ruin calculator to determine the probability of reaching maximum drawdown. Essential tool for forex traders to assess long-term survival odds."
        keywords="risk of ruin calculator, trading risk calculator, maximum drawdown probability, forex risk management, trading survival rate"
        canonicalUrl="https://forexcalculatorpro.com/risk-of-ruin-calculator"
      />

      <div className="min-h-screen bg-navy-50">
        <Header />

        {/* Hero Section */}
        <section className="navy-gradient text-white py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                Professional <span className="text-gold-400">Risk of Ruin Calculator</span>
              </h1>
              <p className="text-xl mb-8 text-navy-100 max-w-3xl mx-auto">
                Calculate the probability of reaching maximum drawdown based on your trading statistics. 
                Assess your long-term survival odds and optimize your risk management strategy.
              </p>
            </div>
          </div>
        </section>

        {/* Main Calculator Section */}
        <section className="py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Calculator Card */}
              <div className="lg:col-span-2">
                <Card className="calculator-card">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <div className="bg-gold-500 p-2 rounded-lg mr-3">
                        <Activity className="w-6 h-6 text-white" />
                      </div>
                      Risk of Ruin Calculator
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      {/* Win Rate */}
                      <div className="space-y-2">
                        <Label htmlFor="winRate">Win Rate (%)</Label>
                        <Input
                          id="winRate"
                          type="number"
                          placeholder="60"
                          min="0"
                          max="100"
                          step="0.1"
                          value={winRate}
                          onChange={(e) => setWinRate(e.target.value)}
                          className="input-field"
                        />
                        <div className="text-xs text-navy-600">
                          Percentage of winning trades (0-100%)
                        </div>
                      </div>

                      {/* Average Win */}
                      <div className="space-y-2">
                        <Label htmlFor="averageWin">Average Win ($)</Label>
                        <Input
                          id="averageWin"
                          type="number"
                          placeholder="100"
                          step="0.01"
                          value={averageWin}
                          onChange={(e) => setAverageWin(e.target.value)}
                          className="input-field"
                        />
                        <div className="text-xs text-navy-600">
                          Average profit per winning trade
                        </div>
                      </div>

                      {/* Average Loss */}
                      <div className="space-y-2">
                        <Label htmlFor="averageLoss">Average Loss ($)</Label>
                        <Input
                          id="averageLoss"
                          type="number"
                          placeholder="50"
                          step="0.01"
                          value={averageLoss}
                          onChange={(e) => setAverageLoss(e.target.value)}
                          className="input-field"
                        />
                        <div className="text-xs text-navy-600">
                          Average loss per losing trade (positive number)
                        </div>
                      </div>

                      {/* Risk Per Trade */}
                      <div className="space-y-2">
                        <Label htmlFor="riskPerTrade">Risk Per Trade (%)</Label>
                        <Input
                          id="riskPerTrade"
                          type="number"
                          placeholder="2"
                          step="0.1"
                          value={riskPerTrade}
                          onChange={(e) => setRiskPerTrade(e.target.value)}
                          className="input-field"
                        />
                        <div className="text-xs text-navy-600">
                          Percentage of account risked per trade
                        </div>
                      </div>
                    </div>

                    <Button 
                      onClick={calculateRiskOfRuin}
                      className="btn-primary w-full"
                    >
                      <Activity className="w-5 h-5 mr-2" />
                      Calculate Risk of Ruin
                    </Button>

                    {/* Results Panel */}
                    {result !== null && riskLevel && (
                      <div className="mt-8 p-6 bg-navy-50 rounded-lg">
                        <h3 className="text-lg font-semibold text-navy-900 mb-4">Risk of Ruin Analysis</h3>
                        
                        {/* Main Result */}
                        <div className="grid md:grid-cols-2 gap-4 mb-6">
                          <Card className="border">
                            <CardContent className="p-6 text-center">
                              <div className={`text-4xl font-bold mb-2 ${riskLevel.color}`}>
                                {result.toFixed(2)}%
                              </div>
                              <div className="text-sm text-navy-600">Risk of Ruin</div>
                              <div className={`mt-2 px-3 py-1 rounded-full text-xs font-medium ${riskLevel.bg} ${riskLevel.color}`}>
                                {riskLevel.level} Risk
                              </div>
                            </CardContent>
                          </Card>
                          <Card className="border">
                            <CardContent className="p-6">
                              <h4 className="font-semibold text-navy-900 mb-3">Trading Stats</h4>
                              <div className="space-y-2 text-sm">
                                <div className="flex justify-between">
                                  <span>Win Rate:</span>
                                  <span className="font-semibold">{winRate}%</span>
                                </div>
                                <div className="flex justify-between">
                                  <span>Win/Loss Ratio:</span>
                                  <span className="font-semibold">{(parseFloat(averageWin) / parseFloat(averageLoss)).toFixed(2)}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span>Risk per Trade:</span>
                                  <span className="font-semibold">{riskPerTrade}%</span>
                                </div>
                                <div className="flex justify-between">
                                  <span>Expected Value:</span>
                                  <span className={`font-semibold ${
                                    (parseFloat(winRate) / 100 * parseFloat(averageWin) - (1 - parseFloat(winRate) / 100) * parseFloat(averageLoss)) > 0 
                                      ? 'text-green-600' : 'text-red-600'
                                  }`}>
                                    ${(parseFloat(winRate) / 100 * parseFloat(averageWin) - (1 - parseFloat(winRate) / 100) * parseFloat(averageLoss)).toFixed(2)}
                                  </span>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        </div>

                        {/* Risk Interpretation */}
                        <div className="p-4 bg-white rounded-lg border mb-6">
                          <h4 className="font-semibold text-navy-900 mb-2">What This Means</h4>
                          <p className="text-sm text-navy-600">
                            {result <= 1 && "Excellent! Your risk of ruin is very low. Your trading system has strong long-term survival prospects."}
                            {result > 1 && result <= 5 && "Good risk management. Your system has a low probability of catastrophic failure."}
                            {result > 5 && result <= 15 && "Moderate risk. Consider reducing position sizes or improving win rate/risk-reward ratio."}
                            {result > 15 && result <= 30 && "High risk of significant drawdown. Your system needs improvement before live trading."}
                            {result > 30 && "Very high risk! This system is likely to fail. Major adjustments to strategy or risk management are needed."}
                          </p>
                        </div>

                        {/* Warning for High Risk */}
                        {result > 15 && (
                          <div className="p-4 bg-red-50 border border-red-200 rounded-lg mb-6">
                            <div className="flex items-center text-red-800 mb-2">
                              <AlertTriangle className="w-5 h-5 mr-2" />
                              <strong>High Risk Warning</strong>
                            </div>
                            <p className="text-red-700 text-sm">
                              Your current parameters result in a high risk of ruin. Consider:
                            </p>
                            <ul className="text-red-700 text-sm mt-2 list-disc pl-5">
                              <li>Reducing risk per trade to 1% or less</li>
                              <li>Improving your win rate through better strategy</li>
                              <li>Increasing your average win relative to average loss</li>
                              <li>Backtesting your strategy more thoroughly</li>
                            </ul>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Win Rate Scenarios */}
                    {scenarios && (
                      <div className="mt-8 p-6 bg-white rounded-lg border">
                        <h3 className="text-lg font-semibold text-navy-900 mb-4">Win Rate Impact Analysis</h3>
                        <div className="overflow-x-auto">
                          <table className="w-full text-sm">
                            <thead>
                              <tr className="border-b">
                                <th className="text-left py-2 text-navy-700">Win Rate</th>
                                <th className="text-left py-2 text-navy-700">Risk of Ruin</th>
                                <th className="text-left py-2 text-navy-700">Risk Level</th>
                                <th className="text-left py-2 text-navy-700">Recommendation</th>
                              </tr>
                            </thead>
                            <tbody>
                              {scenarios.map((scenario) => {
                                const level = getRiskLevel(scenario.riskOfRuin);
                                return (
                                  <tr key={scenario.winRate} className="border-b">
                                    <td className="py-2 font-semibold">{scenario.winRate}%</td>
                                    <td className={`py-2 font-semibold ${level.color}`}>
                                      {scenario.riskOfRuin.toFixed(2)}%
                                    </td>
                                    <td className="py-2">
                                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${level.bg} ${level.color}`}>
                                        {level.level}
                                      </span>
                                    </td>
                                    <td className="py-2 text-xs">
                                      {scenario.riskOfRuin <= 5 ? '✅ Acceptable' : 
                                       scenario.riskOfRuin <= 15 ? '⚠️ Caution' : '❌ Too risky'}
                                    </td>
                                  </tr>
                                );
                              })}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Educational Content */}
                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle>Understanding Risk of Ruin</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4 text-sm text-navy-600">
                    <p>
                      Risk of Ruin is the probability that your trading account will lose a predetermined amount 
                      of capital before it reaches a predetermined profit target. It's based on your win rate, 
                      average win/loss, and risk per trade.
                    </p>
                    <div className="space-y-2">
                      <h4 className="font-semibold text-navy-900">Key Factors:</h4>
                      <ul className="list-disc pl-5 space-y-1">
                        <li><strong>Win Rate:</strong> Higher win rates reduce risk of ruin</li>
                        <li><strong>Risk-Reward Ratio:</strong> Larger wins vs losses improve survival</li>
                        <li><strong>Position Size:</strong> Smaller risk per trade dramatically reduces ruin probability</li>
                        <li><strong>Kelly Criterion:</strong> Optimal position sizing for long-term growth</li>
                      </ul>
                    </div>
                    <div className="bg-gold-50 p-4 rounded-lg">
                      <p className="text-gold-800">
                        <strong>Pro Tip:</strong> Most professional traders aim for a risk of ruin below 1%. 
                        Even profitable strategies can fail if position sizing is too aggressive.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Side Panel */}
              <div className="space-y-6">
                {/* Quick Scenarios */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Quick Scenarios</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button
                      variant="outline"
                      className="w-full text-left justify-start"
                      onClick={() => {
                        setWinRate('60');
                        setAverageWin('150');
                        setAverageLoss('100');
                        setRiskPerTrade('1');
                      }}
                    >
                      Conservative Trader
                      <div className="text-xs text-navy-500 ml-auto">60% WR, 1% risk</div>
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full text-left justify-start"
                      onClick={() => {
                        setWinRate('55');
                        setAverageWin('200');
                        setAverageLoss('100');
                        setRiskPerTrade('2');
                      }}
                    >
                      Balanced Trader
                      <div className="text-xs text-navy-500 ml-auto">55% WR, 2% risk</div>
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full text-left justify-start"
                      onClick={() => {
                        setWinRate('45');
                        setAverageWin('300');
                        setAverageLoss('100');
                        setRiskPerTrade('2');
                      }}
                    >
                      High R:R Trader
                      <div className="text-xs text-navy-500 ml-auto">45% WR, 3:1 R:R</div>
                    </Button>
                  </CardContent>
                </Card>

                {/* Related Tools */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Related Tools</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <a href="/position-size-calculator" className="flex items-center p-3 hover:bg-navy-50 rounded-lg transition-colors group">
                      <div className="bg-gold-100 p-2 rounded mr-3 group-hover:bg-gold-200">
                        <Calculator className="w-4 h-4 text-gold-600" />
                      </div>
                      <span className="text-navy-700 font-medium">Position Size Calculator</span>
                    </a>
                    <a href="/drawdown-calculator" className="flex items-center p-3 hover:bg-navy-50 rounded-lg transition-colors group">
                      <div className="bg-gold-100 p-2 rounded mr-3 group-hover:bg-gold-200">
                        <TrendingDown className="w-4 h-4 text-gold-600" />
                      </div>
                      <span className="text-navy-700 font-medium">Drawdown Calculator</span>
                    </a>
                    <a href="/compounding-calculator" className="flex items-center p-3 hover:bg-navy-50 rounded-lg transition-colors group">
                      <div className="bg-gold-100 p-2 rounded mr-3 group-hover:bg-gold-200">
                        <Activity className="w-4 h-4 text-gold-600" />
                      </div>
                      <span className="text-navy-700 font-medium">Compounding Calculator</span>
                    </a>
                  </CardContent>
                </Card>

                {/* Risk Guidelines */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Risk Guidelines</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 text-sm text-navy-600">
                      <div className="flex items-center">
                        <div className="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
                        <div><strong>0-1%:</strong> Excellent</div>
                      </div>
                      <div className="flex items-center">
                        <div className="w-3 h-3 bg-green-400 rounded-full mr-3"></div>
                        <div><strong>1-5%:</strong> Good</div>
                      </div>
                      <div className="flex items-center">
                        <div className="w-3 h-3 bg-yellow-500 rounded-full mr-3"></div>
                        <div><strong>5-15%:</strong> Moderate</div>
                      </div>
                      <div className="flex items-center">
                        <div className="w-3 h-3 bg-orange-500 rounded-full mr-3"></div>
                        <div><strong>15-30%:</strong> High</div>
                      </div>
                      <div className="flex items-center">
                        <div className="w-3 h-3 bg-red-500 rounded-full mr-3"></div>
                        <div><strong>30%+:</strong> Very High</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
}
