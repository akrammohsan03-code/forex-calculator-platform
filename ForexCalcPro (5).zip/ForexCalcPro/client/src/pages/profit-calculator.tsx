import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import SEOHead from '@/components/seo-head';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DollarSign, TrendingUp, TrendingDown, Radio } from 'lucide-react';
import { forexAPI } from '@/lib/forex-api';
import { CalculatorUtils } from '@/lib/calculator-utils';
import { getPairsByGroups, MAJOR_CURRENCIES } from '@/data/currency-pairs';
import { useToast } from '@/hooks/use-toast';

interface ProfitResult {
  profitLoss: number;
  profitLossPips: number;
  profitLossPercentage: number;
}

export default function ProfitCalculator() {
  const [currencyPair, setCurrencyPair] = useState('EUR/USD');
  const [accountCurrency, setAccountCurrency] = useState('USD');
  const [direction, setDirection] = useState<'buy' | 'sell'>('buy');
  const [lotSize, setLotSize] = useState<string>('1');
  const [openPrice, setOpenPrice] = useState<string>('');
  const [closePrice, setClosePrice] = useState<string>('');
  const [result, setResult] = useState<ProfitResult | null>(null);
  const [rateAnimating, setRateAnimating] = useState(false);
  const [previousRate, setPreviousRate] = useState<number | null>(null);
  
  const { toast } = useToast();

  const pairGroups = getPairsByGroups();
  
  const { data: currencyPairs, isLoading } = useQuery({
    queryKey: ['/api/currency-pairs'],
    queryFn: () => forexAPI.getCurrencyPairs(),
    refetchInterval: 3000, // Real-time updates every 3 seconds
  });

  const { data: forexRates } = useQuery({
    queryKey: ['/api/forex-rates', accountCurrency],
    queryFn: () => forexAPI.getForexRates(accountCurrency),
  });

  const calculateProfit = async () => {
    const lots = parseFloat(lotSize);
    const open = parseFloat(openPrice);
    const close = parseFloat(closePrice);
    
    if (!lots || !open || !close) {
      toast({
        title: 'Invalid Input',
        description: 'Please enter valid values for all fields.',
        variant: 'destructive',
      });
      return;
    }

    try {
      // Calculate pip value
      const pipValue = CalculatorUtils.calculatePipValue({
        currencyPair,
        lotSize: lots,
        accountCurrency,
        exchangeRate: forexRates?.conversion_rates?.[currencyPair.split('/')[1]] || 1,
      });

      // Calculate profit/loss
      const profitLoss = CalculatorUtils.calculateProfitLoss({
        lotSize: lots,
        openPrice: open,
        closePrice: close,
        pipValue,
        direction,
      });

      const priceDifference = direction === 'buy' ? close - open : open - close;
      const pipDifference = priceDifference / (currencyPair.includes('JPY') ? 0.01 : 0.0001);
      const investmentAmount = lots * 100000 * open; // Approximate investment
      const profitPercentage = (profitLoss / investmentAmount) * 100;

      const profitResult: ProfitResult = {
        profitLoss,
        profitLossPips: Math.round(pipDifference * 10) / 10,
        profitLossPercentage: Math.round(profitPercentage * 100) / 100,
      };

      setResult(profitResult);

      // Save calculation result
      await forexAPI.saveCalculatorResult('profit-loss', {
        currencyPair,
        accountCurrency,
        direction,
        lotSize: lots,
        openPrice: open,
        closePrice: close,
      }, profitResult);

      toast({
        title: 'Calculation Complete',
        description: 'Profit/Loss calculated successfully!',
      });

    } catch (error) {
      toast({
        title: 'Calculation Error',
        description: 'Failed to calculate profit/loss. Please try again.',
        variant: 'destructive',
      });
    }
  };

  const currentRate = currencyPairs?.find(pair => pair.symbol === currencyPair)?.rate || '1.0000';
  
  // Track rate changes for animations
  useEffect(() => {
    if (currentRate && previousRate !== null && parseFloat(currentRate) !== previousRate) {
      setRateAnimating(true);
      setTimeout(() => setRateAnimating(false), 1000);
    }
    setPreviousRate(parseFloat(currentRate));
  }, [currentRate, previousRate]);

  const handleLiveClick = (type: 'open' | 'close') => {
    const rate = currentRate.toString();
    if (type === 'open') {
      setOpenPrice(rate);
    } else {
      setClosePrice(rate);
    }
    setRateAnimating(true);
    setTimeout(() => setRateAnimating(false), 1000);
  };

  return (
    <>
      <SEOHead
        title="Profit Calculator | Calculate Forex Trading Profit & Loss - ForexCalculatorPro"
        description="Professional profit calculator for Forex, Gold, Oil, NASDAQ100, US30 and 70+ trading instruments. Calculate potential P&L with real-time market data and risk management tools."
        keywords="profit calculator, forex profit loss calculator, trading profit calculator, P&L calculator, forex tools"
        canonicalUrl="https://forexcalculatorpro.com/profit-calculator"
      />

      <div className="min-h-screen bg-navy-50">
        <Header />

        {/* Hero Section */}
        <section className="navy-gradient text-white py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                Professional <span className="text-gold-400">Profit Calculator</span>
              </h1>
              <p className="text-xl mb-8 text-navy-100 max-w-3xl mx-auto">
                Calculate potential profits and losses for Forex, Gold, Oil, NASDAQ100, US30 and 70+ trading instruments with real-time market data.
              </p>
            </div>
          </div>
        </section>

        {/* Main Calculator Section */}
        <section className="py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Calculator Card */}
              <div className="lg:col-span-2">
                <Card className="calculator-card">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <div className="bg-gold-500 p-2 rounded-lg mr-3">
                        <DollarSign className="w-6 h-6 text-white" />
                      </div>
                      Profit & Loss Calculator
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      {/* Currency Pair Selection */}
                      <div className="space-y-2">
                        <Label htmlFor="currencyPair">Currency Pair</Label>
                        <Select value={currencyPair} onValueChange={setCurrencyPair}>
                          <SelectTrigger className="input-field">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <div className="px-2 py-1 text-xs font-semibold text-navy-700 bg-navy-50">
                              Major Pairs
                            </div>
                            {pairGroups.major.map((pair) => (
                              <SelectItem key={pair} value={pair}>
                                {pair}
                              </SelectItem>
                            ))}
                            <div className="px-2 py-1 text-xs font-semibold text-navy-700 bg-navy-50 mt-2">
                              Minor Pairs
                            </div>
                            {pairGroups.minor.map((pair) => (
                              <SelectItem key={pair} value={pair}>
                                {pair}
                              </SelectItem>
                            ))}
                            <div className="px-2 py-1 text-xs font-semibold text-navy-700 bg-navy-50 mt-2">
                              Exotic Pairs
                            </div>
                            {pairGroups.exotic.map((pair) => (
                              <SelectItem key={pair} value={pair}>
                                {pair}
                              </SelectItem>
                            ))}
                            <div className="px-2 py-1 text-xs font-semibold text-navy-700 bg-navy-50 mt-2">
                              Metals
                            </div>
                            {pairGroups.metals.map((pair) => (
                              <SelectItem key={pair} value={pair}>
                                {pair}
                              </SelectItem>
                            ))}
                            <div className="px-2 py-1 text-xs font-semibold text-navy-700 bg-navy-50 mt-2">
                              Energy & Oil
                            </div>
                            {pairGroups.energies.map((pair) => (
                              <SelectItem key={pair} value={pair}>
                                {pair}
                              </SelectItem>
                            ))}
                            <div className="px-2 py-1 text-xs font-semibold text-navy-700 bg-navy-50 mt-2">
                              Stock Indices
                            </div>
                            {pairGroups.indices.map((pair) => (
                              <SelectItem key={pair} value={pair}>
                                {pair}
                              </SelectItem>
                            ))}
                            <div className="px-2 py-1 text-xs font-semibold text-navy-700 bg-navy-50 mt-2">
                              Cryptocurrencies
                            </div>
                            {pairGroups.crypto.map((pair) => (
                              <SelectItem key={pair} value={pair}>
                                {pair}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      {/* Account Currency */}
                      <div className="space-y-2">
                        <Label htmlFor="accountCurrency">Account Currency</Label>
                        <Select value={accountCurrency} onValueChange={setAccountCurrency}>
                          <SelectTrigger className="input-field">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {MAJOR_CURRENCIES.map((currency) => (
                              <SelectItem key={currency.code} value={currency.code}>
                                {currency.name} ({currency.code})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      {/* Trade Direction */}
                      <div className="space-y-2">
                        <Label htmlFor="direction">Trade Direction</Label>
                        <Select value={direction} onValueChange={(value: 'buy' | 'sell') => setDirection(value)}>
                          <SelectTrigger className="input-field">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="buy">
                              <div className="flex items-center">
                                <TrendingUp className="w-4 h-4 mr-2 text-green-500" />
                                Buy (Long)
                              </div>
                            </SelectItem>
                            <SelectItem value="sell">
                              <div className="flex items-center">
                                <TrendingDown className="w-4 h-4 mr-2 text-red-500" />
                                Sell (Short)
                              </div>
                            </SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      {/* Lot Size */}
                      <div className="space-y-2">
                        <Label htmlFor="lotSize">Lot Size</Label>
                        <Input
                          id="lotSize"
                          type="number"
                          placeholder="1"
                          step="0.01"
                          value={lotSize}
                          onChange={(e) => setLotSize(e.target.value)}
                          className="input-field"
                        />
                      </div>

                      {/* Open Price */}
                      <div className="space-y-2">
                        <Label htmlFor="openPrice">Open Price</Label>
                        <div className="relative">
                          <Input
                            id="openPrice"
                            type="number"
                            placeholder={`Current: ${currentRate}`}
                            step="0.00001"
                            value={openPrice}
                            onChange={(e) => setOpenPrice(e.target.value)}
                            className="input-field pr-20"
                          />
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            onClick={() => handleLiveClick('open')}
                            className={`absolute right-1 top-1 h-8 text-xs px-2 transition-all duration-300 ${
                              rateAnimating ? 'bg-green-100 border-green-400 text-green-600 scale-105' : 'hover:bg-gold-50 hover:border-gold-400'
                            }`}
                          >
                            <Radio className={`w-3 h-3 mr-1 ${rateAnimating ? 'animate-ping' : ''}`} />
                            Live
                          </Button>
                        </div>
                        <div className={`text-xs transition-colors duration-300 ${
                          rateAnimating ? 'text-green-600 font-medium' : 'text-navy-600'
                        }`}>
                          <span className={`${rateAnimating ? 'rate-pulse' : ''}`}>
                            Current rate: {currentRate}
                          </span> • Click 'Live' for real-time rate
                        </div>
                      </div>

                      {/* Close Price */}
                      <div className="space-y-2">
                        <Label htmlFor="closePrice">Close Price</Label>
                        <div className="relative">
                          <Input
                            id="closePrice"
                            type="number"
                            placeholder={`Current: ${currentRate}`}
                            step="0.00001"
                            value={closePrice}
                            onChange={(e) => setClosePrice(e.target.value)}
                            className="input-field pr-20"
                          />
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            onClick={() => handleLiveClick('close')}
                            className={`absolute right-1 top-1 h-8 text-xs px-2 transition-all duration-300 ${
                              rateAnimating ? 'bg-green-100 border-green-400 text-green-600 scale-105' : 'hover:bg-gold-50 hover:border-gold-400'
                            }`}
                          >
                            <Radio className={`w-3 h-3 mr-1 ${rateAnimating ? 'animate-ping' : ''}`} />
                            Live
                          </Button>
                        </div>
                        <div className={`text-xs transition-colors duration-300 ${
                          rateAnimating ? 'text-green-600 font-medium' : 'text-navy-600'
                        }`}>
                          <span className={`${rateAnimating ? 'rate-pulse' : ''}`}>
                            Current rate: {currentRate}
                          </span> • Click 'Live' for real-time rate
                        </div>
                      </div>
                    </div>

                    <Button 
                      onClick={calculateProfit}
                      disabled={isLoading}
                      className="btn-primary w-full"
                    >
                      <DollarSign className="w-5 h-5 mr-2" />
                      Calculate Profit/Loss
                    </Button>

                    {/* Results Panel */}
                    {result && (
                      <div className="mt-8 p-6 bg-navy-50 rounded-lg">
                        <h3 className="text-lg font-semibold text-navy-900 mb-4">Calculation Results</h3>
                        <div className="grid md:grid-cols-3 gap-4">
                          <Card className="border">
                            <CardContent className="p-6 text-center">
                              <div className={`text-3xl font-bold mb-2 ${result.profitLoss >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                                {result.profitLoss >= 0 ? '+' : ''}{accountCurrency === 'USD' ? '$' : ''}{result.profitLoss.toFixed(2)}
                              </div>
                              <div className="text-sm text-navy-600">
                                {result.profitLoss >= 0 ? 'Profit' : 'Loss'}
                              </div>
                            </CardContent>
                          </Card>
                          <Card className="border">
                            <CardContent className="p-6 text-center">
                              <div className={`text-3xl font-bold mb-2 ${result.profitLossPips >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                                {result.profitLossPips >= 0 ? '+' : ''}{result.profitLossPips}
                              </div>
                              <div className="text-sm text-navy-600">Pips</div>
                            </CardContent>
                          </Card>
                          <Card className="border">
                            <CardContent className="p-6 text-center">
                              <div className={`text-3xl font-bold mb-2 ${result.profitLossPercentage >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                                {result.profitLossPercentage >= 0 ? '+' : ''}{result.profitLossPercentage.toFixed(2)}%
                              </div>
                              <div className="text-sm text-navy-600">Return</div>
                            </CardContent>
                          </Card>
                        </div>

                        {/* Trade Summary */}
                        <div className="mt-6 p-4 bg-white rounded-lg border">
                          <h4 className="font-semibold text-navy-900 mb-3">Trade Summary</h4>
                          <div className="grid md:grid-cols-2 gap-4 text-sm">
                            <div className="space-y-2">
                              <div className="flex justify-between">
                                <span className="text-navy-600">Currency Pair:</span>
                                <span className="font-medium">{currencyPair}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-navy-600">Direction:</span>
                                <span className="font-medium capitalize flex items-center">
                                  {direction === 'buy' ? (
                                    <><TrendingUp className="w-4 h-4 mr-1 text-green-500" /> Buy</>
                                  ) : (
                                    <><TrendingDown className="w-4 h-4 mr-1 text-red-500" /> Sell</>
                                  )}
                                </span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-navy-600">Lot Size:</span>
                                <span className="font-medium">{lotSize}</span>
                              </div>
                            </div>
                            <div className="space-y-2">
                              <div className="flex justify-between">
                                <span className="text-navy-600">Open Price:</span>
                                <span className="font-medium">{openPrice}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-navy-600">Close Price:</span>
                                <span className="font-medium">{closePrice}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-navy-600">Price Change:</span>
                                <span className={`font-medium ${(parseFloat(closePrice) - parseFloat(openPrice)) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                                  {(parseFloat(closePrice) - parseFloat(openPrice)).toFixed(5)}
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              {/* Side Panel */}
              <div className="space-y-6">
                {/* Quick Price Fill */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Quick Price Fill</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Button
                      variant="outline"
                      onClick={() => setOpenPrice(currentRate.toString())}
                      className="w-full mb-2"
                    >
                      Use Current Rate as Open Price
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => setClosePrice(currentRate.toString())}
                      className="w-full"
                    >
                      Use Current Rate as Close Price
                    </Button>
                  </CardContent>
                </Card>

                {/* Market Data */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Live Rates</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 text-sm">
                      {currencyPairs?.slice(0, 6).map((pair) => (
                        <div key={pair.symbol} className="flex justify-between items-center">
                          <span className="text-navy-600">{pair.symbol}</span>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setCurrencyPair(pair.symbol)}
                            className="font-semibold text-green-600 h-auto p-1"
                          >
                            {parseFloat(pair.rate.toString()).toFixed(5)}
                          </Button>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
}
