import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import SEOHead from '@/components/seo-head';
import { Mail, MapPin, Clock, MessageCircle, Phone, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function ContactUs() {
  return (
    <>
      <SEOHead
        title="Contact Us - ForexCalculatorPro"
        description="Get in touch with ForexCalculatorPro team. We're here to help with your trading calculator needs and answer any questions."
        canonicalUrl="https://forexcalculatorpro.com/contact-us"
      />
      
      <div className="min-h-screen bg-navy-50">
        <Header />

        {/* Hero Section */}
        <section className="navy-gradient text-white py-16">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div className="flex items-center justify-center mb-6">
              <div className="bg-gold-500 p-4 rounded-lg mr-4">
                <MessageCircle className="w-12 h-12 text-white" />
              </div>
              <h1 className="text-3xl md:text-5xl font-bold">Contact Us</h1>
            </div>
            <p className="text-xl text-navy-100 max-w-3xl mx-auto leading-relaxed">
              Have questions about our trading calculators or need support? We're here to help you succeed in your trading journey.
            </p>
          </div>
        </section>

        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          
          {/* Contact Information Cards */}
          <div className="grid md:grid-cols-3 gap-8 mb-16">
            <div className="bg-white rounded-lg shadow-lg p-8 text-center">
              <div className="bg-gold-500 p-4 rounded-full inline-block mb-6">
                <Mail className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-navy-900 mb-3">Email Us</h3>
              <p className="text-navy-600 mb-4">Send us your questions or feedback</p>
              <a 
                href="mailto:akrammohsan03@gmail.com" 
                className="text-gold-600 hover:text-gold-700 font-medium transition-colors"
              >
                akrammohsan03@gmail.com
              </a>
            </div>

            <div className="bg-white rounded-lg shadow-lg p-8 text-center">
              <div className="bg-gold-500 p-4 rounded-full inline-block mb-6">
                <MapPin className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-navy-900 mb-3">Visit Us</h3>
              <p className="text-navy-600 mb-4">Our office location</p>
              <div className="text-navy-700">
                <p>House 456, Street No 11</p>
                <p>J2 Block, Johar Town</p>
                <p>Lahore, Pakistan</p>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-lg p-8 text-center">
              <div className="bg-gold-500 p-4 rounded-full inline-block mb-6">
                <Clock className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-navy-900 mb-3">Response Time</h3>
              <p className="text-navy-600 mb-4">We typically respond within</p>
              <div className="text-navy-700">
                <p className="font-semibold">24 hours</p>
                <p className="text-sm">Monday to Friday</p>
              </div>
            </div>
          </div>

          {/* Contact Form Section */}
          <div className="grid lg:grid-cols-2 gap-12 mb-16">
            <div className="bg-white rounded-lg shadow-lg p-8">
              <h2 className="text-2xl font-bold text-navy-900 mb-6">Send Us a Message</h2>
              
              <form className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="firstName" className="block text-sm font-medium text-navy-700 mb-2">
                      First Name *
                    </label>
                    <input
                      type="text"
                      id="firstName"
                      name="firstName"
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gold-500 focus:border-gold-500 transition-colors"
                      placeholder="Your first name"
                    />
                  </div>
                  <div>
                    <label htmlFor="lastName" className="block text-sm font-medium text-navy-700 mb-2">
                      Last Name *
                    </label>
                    <input
                      type="text"
                      id="lastName"
                      name="lastName"
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gold-500 focus:border-gold-500 transition-colors"
                      placeholder="Your last name"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-navy-700 mb-2">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gold-500 focus:border-gold-500 transition-colors"
                    placeholder="your.email@example.com"
                  />
                </div>

                <div>
                  <label htmlFor="subject" className="block text-sm font-medium text-navy-700 mb-2">
                    Subject *
                  </label>
                  <select
                    id="subject"
                    name="subject"
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gold-500 focus:border-gold-500 transition-colors"
                  >
                    <option value="">Select a topic</option>
                    <option value="general">General Inquiry</option>
                    <option value="support">Technical Support</option>
                    <option value="bug">Bug Report</option>
                    <option value="feature">Feature Request</option>
                    <option value="business">Business Partnership</option>
                    <option value="other">Other</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-navy-700 mb-2">
                    Message *
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    required
                    rows={6}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gold-500 focus:border-gold-500 transition-colors"
                    placeholder="Tell us how we can help you..."
                  ></textarea>
                </div>

                <Button 
                  type="submit" 
                  className="w-full bg-gold-500 hover:bg-gold-600 text-white font-semibold py-3 px-6 rounded-lg transition-colors duration-200 flex items-center justify-center"
                >
                  <Send className="w-5 h-5 mr-2" />
                  Send Message
                </Button>
              </form>
            </div>

            <div className="space-y-8">
              <div className="bg-white rounded-lg shadow-lg p-8">
                <h3 className="text-xl font-semibold text-navy-900 mb-4">Quick Questions?</h3>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium text-navy-900 mb-2">Are the calculators free to use?</h4>
                    <p className="text-navy-600 text-sm">Yes, all our trading calculators are completely free to use with no registration required.</p>
                  </div>
                  <div>
                    <h4 className="font-medium text-navy-900 mb-2">How accurate are the calculations?</h4>
                    <p className="text-navy-600 text-sm">Our calculators use real-time market data and professional-grade formulas for maximum accuracy.</p>
                  </div>
                  <div>
                    <h4 className="font-medium text-navy-900 mb-2">Can I suggest new features?</h4>
                    <p className="text-navy-600 text-sm">Absolutely! We welcome feature suggestions and user feedback to improve our tools.</p>
                  </div>
                </div>
              </div>

              <div className="bg-gold-50 border border-gold-200 rounded-lg p-8">
                <h3 className="text-xl font-semibold text-navy-900 mb-4">Looking for Support?</h3>
                <p className="text-navy-600 mb-4">
                  If you're experiencing technical issues or need help with our calculators, please include:
                </p>
                <ul className="text-sm text-navy-600 space-y-2">
                  <li>• Your browser type and version</li>
                  <li>• The specific calculator you're using</li>
                  <li>• Steps to reproduce the issue</li>
                  <li>• Any error messages you see</li>
                </ul>
              </div>

              <div className="bg-navy-900 text-white rounded-lg shadow-lg p-8">
                <h3 className="text-xl font-semibold text-gold-400 mb-4">Business Inquiries</h3>
                <p className="text-navy-100 mb-4">
                  Interested in partnerships, API access, or custom calculator development? We'd love to discuss opportunities.
                </p>
                <p className="text-navy-100">
                  Email us at: <a href="mailto:akrammohsan03@gmail.com" className="text-gold-400 hover:text-gold-300">akrammohsan03@gmail.com</a>
                </p>
              </div>
            </div>
          </div>

          {/* Additional Information */}
          <div className="bg-white rounded-lg shadow-lg p-8 text-center">
            <h2 className="text-2xl font-bold text-navy-900 mb-4">We Value Your Feedback</h2>
            <p className="text-navy-600 max-w-3xl mx-auto leading-relaxed">
              Your input helps us improve ForexCalculatorPro. Whether you have suggestions for new calculators, 
              feedback on existing tools, or ideas for better user experience, we want to hear from you. 
              Together, we can build the most comprehensive trading calculator platform.
            </p>
          </div>

        </div>

        <Footer />
      </div>
    </>
  );
}