import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import SEOHead from '@/components/seo-head';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { BarChart3, Calculator, DollarSign, Zap } from 'lucide-react';
import { forexAPI } from '@/lib/forex-api';
import { getPairsByGroups, MAJOR_CURRENCIES } from '@/data/currency-pairs';
import { useToast } from '@/hooks/use-toast';

interface MarginResult {
  requiredMargin: number;
  usedMargin: number;
  freeMargin: number;
  marginLevel: number;
  positionValue: number;
}

export default function MarginCalculator() {
  const [currencyPair, setCurrencyPair] = useState('EUR/USD');
  const [accountCurrency, setAccountCurrency] = useState('USD');
  const [accountBalance, setAccountBalance] = useState<string>('10000');
  const [lotSize, setLotSize] = useState<string>('1');
  const [leverage, setLeverage] = useState<string>('100');
  const [result, setResult] = useState<MarginResult | null>(null);
  
  const { toast } = useToast();

  const pairGroups = getPairsByGroups();

  const { data: currencyPairs, isLoading } = useQuery({
    queryKey: ['/api/currency-pairs'],
    queryFn: () => forexAPI.getCurrencyPairs(),
  });

  const { data: forexRates } = useQuery({
    queryKey: ['/api/forex-rates', accountCurrency],
    queryFn: () => forexAPI.getForexRates(accountCurrency),
  });

  const calculateMargin = async () => {
    const balance = parseFloat(accountBalance);
    const lots = parseFloat(lotSize);
    const lev = parseFloat(leverage);
    
    if (!balance || !lots || !lev) {
      toast({
        title: 'Invalid Input',
        description: 'Please enter valid values for all fields.',
        variant: 'destructive',
      });
      return;
    }

    try {
      const currentRate = parseFloat(currencyPairs?.find(pair => pair.symbol === currencyPair)?.rate?.toString() || '1');
      const exchangeRate = forexRates?.conversion_rates?.[accountCurrency] || 1;

      // Calculate position value in base currency
      const positionValue = lots * 100000 * currentRate;
      
      // Calculate required margin
      const requiredMargin = positionValue / lev / exchangeRate;
      
      // Calculate used margin (same as required for single position)
      const usedMargin = requiredMargin;
      
      // Calculate free margin
      const freeMargin = balance - usedMargin;
      
      // Calculate margin level
      const marginLevel = (balance / usedMargin) * 100;

      const marginResult: MarginResult = {
        requiredMargin: Math.round(requiredMargin * 100) / 100,
        usedMargin: Math.round(usedMargin * 100) / 100,
        freeMargin: Math.round(freeMargin * 100) / 100,
        marginLevel: Math.round(marginLevel * 100) / 100,
        positionValue: Math.round(positionValue * 100) / 100,
      };

      setResult(marginResult);

      // Save calculation result
      await forexAPI.saveCalculatorResult('margin', {
        currencyPair,
        accountCurrency,
        accountBalance: balance,
        lotSize: lots,
        leverage: lev,
      }, marginResult);

      toast({
        title: 'Calculation Complete',
        description: 'Margin requirements calculated successfully!',
      });

    } catch (error) {
      toast({
        title: 'Calculation Error',
        description: 'Failed to calculate margin. Please try again.',
        variant: 'destructive',
      });
    }
  };

  const currentRate = currencyPairs?.find(pair => pair.symbol === currencyPair)?.rate || '1.0000';

  const leverageOptions = [
    '1', '2', '5', '10', '20', '30', '50', '100', '200', '300', '400', '500', '1000'
  ];

  return (
    <>
      <SEOHead
        title="Margin Calculator | Calculate Required Margin for Forex Trading - ForexCalculatorPro"
        description="Free margin calculator to determine required margin based on position size and leverage. Calculate margin requirements, free margin, and margin level for forex trading."
        keywords="margin calculator, forex margin, trading margin calculator, leverage calculator, required margin, free margin"
        canonicalUrl="https://forexcalculatorpro.com/margin-calculator"
      />

      <div className="min-h-screen bg-navy-50">
        <Header />

        {/* Hero Section */}
        <section className="navy-gradient text-white py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                Professional <span className="text-gold-400">Margin Calculator</span>
              </h1>
              <p className="text-xl mb-8 text-navy-100 max-w-3xl mx-auto">
                Determine required margin for your positions based on leverage and position size. Essential tool for managing your trading capital effectively.
              </p>
            </div>
          </div>
        </section>

        {/* Main Calculator Section */}
        <section className="py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Calculator Card */}
              <div className="lg:col-span-2">
                <Card className="calculator-card">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <div className="bg-gold-500 p-2 rounded-lg mr-3">
                        <BarChart3 className="w-6 h-6 text-white" />
                      </div>
                      Margin & Leverage Calculator
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      {/* Currency Pair Selection */}
                      <div className="space-y-2">
                        <Label htmlFor="currencyPair">Currency Pair</Label>
                        <Select value={currencyPair} onValueChange={setCurrencyPair}>
                          <SelectTrigger className="input-field">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <div className="px-2 py-1 text-xs font-semibold text-navy-700 bg-navy-50">
                              Major Pairs
                            </div>
                            {pairGroups.major.map((pair) => (
                              <SelectItem key={pair} value={pair}>
                                {pair}
                              </SelectItem>
                            ))}
                            <div className="px-2 py-1 text-xs font-semibold text-navy-700 bg-navy-50 mt-2">
                              Minor Pairs
                            </div>
                            {pairGroups.minor.map((pair) => (
                              <SelectItem key={pair} value={pair}>
                                {pair}
                              </SelectItem>
                            ))}
                            <div className="px-2 py-1 text-xs font-semibold text-navy-700 bg-navy-50 mt-2">
                              Metals & Commodities
                            </div>
                            {pairGroups.metals.map((pair) => (
                              <SelectItem key={pair} value={pair}>
                                {pair}
                              </SelectItem>
                            ))}
                            {pairGroups.energies.map((pair) => (
                              <SelectItem key={pair} value={pair}>
                                {pair}
                              </SelectItem>
                            ))}
                            <div className="px-2 py-1 text-xs font-semibold text-navy-700 bg-navy-50 mt-2">
                              Indices & Crypto
                            </div>
                            {pairGroups.indices.map((pair) => (
                              <SelectItem key={pair} value={pair}>
                                {pair}
                              </SelectItem>
                            ))}
                            {pairGroups.crypto.map((pair) => (
                              <SelectItem key={pair} value={pair}>
                                {pair}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      {/* Account Currency */}
                      <div className="space-y-2">
                        <Label htmlFor="accountCurrency">Account Currency</Label>
                        <Select value={accountCurrency} onValueChange={setAccountCurrency}>
                          <SelectTrigger className="input-field">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {MAJOR_CURRENCIES.map((currency) => (
                              <SelectItem key={currency.code} value={currency.code}>
                                {currency.name} ({currency.code})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      {/* Account Balance */}
                      <div className="space-y-2">
                        <Label htmlFor="accountBalance">Account Balance</Label>
                        <Input
                          id="accountBalance"
                          type="number"
                          placeholder="10000"
                          value={accountBalance}
                          onChange={(e) => setAccountBalance(e.target.value)}
                          className="input-field"
                        />
                      </div>

                      {/* Lot Size */}
                      <div className="space-y-2">
                        <Label htmlFor="lotSize">Lot Size</Label>
                        <Input
                          id="lotSize"
                          type="number"
                          placeholder="1"
                          step="0.01"
                          value={lotSize}
                          onChange={(e) => setLotSize(e.target.value)}
                          className="input-field"
                        />
                      </div>

                      {/* Leverage */}
                      <div className="space-y-2">
                        <Label htmlFor="leverage">Leverage Ratio</Label>
                        <Select value={leverage} onValueChange={setLeverage}>
                          <SelectTrigger className="input-field">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {leverageOptions.map((lev) => (
                              <SelectItem key={lev} value={lev}>
                                1:{lev}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      {/* Current Rate Display */}
                      <div className="space-y-2">
                        <Label>Current Rate</Label>
                        <div className="input-field bg-navy-50 flex items-center justify-center">
                          <span className="font-semibold text-navy-800">{currentRate}</span>
                        </div>
                      </div>
                    </div>

                    <Button 
                      onClick={calculateMargin}
                      disabled={isLoading}
                      className="btn-primary w-full"
                    >
                      <BarChart3 className="w-5 h-5 mr-2" />
                      Calculate Margin Requirements
                    </Button>

                    {/* Results Panel */}
                    {result && (
                      <div className="mt-8 p-6 bg-navy-50 rounded-lg">
                        <h3 className="text-lg font-semibold text-navy-900 mb-4">Margin Calculation Results</h3>
                        <div className="grid md:grid-cols-2 gap-4">
                          <Card className="border">
                            <CardContent className="p-4 text-center">
                              <div className="text-2xl font-bold text-red-600">
                                {accountCurrency === 'USD' ? '$' : ''}{result.requiredMargin.toFixed(2)}
                              </div>
                              <div className="text-sm text-navy-600">Required Margin</div>
                            </CardContent>
                          </Card>
                          <Card className="border">
                            <CardContent className="p-4 text-center">
                              <div className="text-2xl font-bold text-green-600">
                                {accountCurrency === 'USD' ? '$' : ''}{result.freeMargin.toFixed(2)}
                              </div>
                              <div className="text-sm text-navy-600">Free Margin</div>
                            </CardContent>
                          </Card>
                          <Card className="border">
                            <CardContent className="p-4 text-center">
                              <div className="text-2xl font-bold text-blue-600">
                                {result.marginLevel.toFixed(2)}%
                              </div>
                              <div className="text-sm text-navy-600">Margin Level</div>
                            </CardContent>
                          </Card>
                          <Card className="border">
                            <CardContent className="p-4 text-center">
                              <div className="text-2xl font-bold text-gold-600">
                                {accountCurrency === 'USD' ? '$' : ''}{result.positionValue.toFixed(2)}
                              </div>
                              <div className="text-sm text-navy-600">Position Value</div>
                            </CardContent>
                          </Card>
                        </div>

                        {/* Margin Level Warning */}
                        {result.marginLevel < 100 && (
                          <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
                            <div className="text-red-800 font-semibold">⚠️ Margin Call Warning</div>
                            <div className="text-red-700 text-sm mt-1">
                              Your margin level is below 100%. This position may trigger a margin call.
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Educational Content */}
                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle>Understanding Margin & Leverage</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4 text-sm text-navy-600">
                    <p>
                      Margin is the deposit required to open a leveraged trading position. It's not a cost, 
                      but a good faith deposit that allows you to control a larger position with less capital.
                    </p>
                    <div className="space-y-2">
                      <h4 className="font-semibold text-navy-900">Key Terms:</h4>
                      <ul className="list-disc pl-5 space-y-1">
                        <li><strong>Required Margin:</strong> The amount needed to open a position</li>
                        <li><strong>Used Margin:</strong> Total margin used for all open positions</li>
                        <li><strong>Free Margin:</strong> Available funds for new positions</li>
                        <li><strong>Margin Level:</strong> (Equity / Used Margin) × 100</li>
                        <li><strong>Margin Call:</strong> Typically occurs when margin level drops below 100%</li>
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Side Panel */}
              <div className="space-y-6">
                {/* Quick Tools */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Related Tools</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <a href="/position-size-calculator" className="flex items-center p-3 hover:bg-navy-50 rounded-lg transition-colors group">
                      <div className="bg-gold-100 p-2 rounded mr-3 group-hover:bg-gold-200">
                        <Calculator className="w-4 h-4 text-gold-600" />
                      </div>
                      <span className="text-navy-700 font-medium">Position Size Calculator</span>
                    </a>
                    <a href="/pip-calculator" className="flex items-center p-3 hover:bg-navy-50 rounded-lg transition-colors group">
                      <div className="bg-gold-100 p-2 rounded mr-3 group-hover:bg-gold-200">
                        <Zap className="w-4 h-4 text-gold-600" />
                      </div>
                      <span className="text-navy-700 font-medium">Pip Calculator</span>
                    </a>
                    <a href="/profit-calculator" className="flex items-center p-3 hover:bg-navy-50 rounded-lg transition-colors group">
                      <div className="bg-gold-100 p-2 rounded mr-3 group-hover:bg-gold-200">
                        <DollarSign className="w-4 h-4 text-gold-600" />
                      </div>
                      <span className="text-navy-700 font-medium">Profit Calculator</span>
                    </a>
                  </CardContent>
                </Card>

                {/* Common Leverage Ratios */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Common Leverage Ratios</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 text-sm">
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <div className="font-semibold text-navy-700">Leverage</div>
                        <div className="font-semibold text-navy-700">Margin Required</div>
                        <div>1:50</div><div>2%</div>
                        <div>1:100</div><div>1%</div>
                        <div>1:200</div><div>0.5%</div>
                        <div>1:500</div><div>0.2%</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Market Data */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Live Rates</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 text-sm">
                      {currencyPairs?.slice(0, 6).map((pair) => (
                        <div key={pair.symbol} className="flex justify-between items-center">
                          <span className="text-navy-600">{pair.symbol}</span>
                          <span className="font-semibold text-green-600">
                            {parseFloat(pair.rate.toString()).toFixed(5)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
}
