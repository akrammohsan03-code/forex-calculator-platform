import { useState } from 'react';
import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import SEOHead from '@/components/seo-head';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { TrendingUp, Calculator, DollarSign, Calendar } from 'lucide-react';
import { forexAPI } from '@/lib/forex-api';
import { CalculatorUtils } from '@/lib/calculator-utils';
import { useToast } from '@/hooks/use-toast';

export default function CompoundingCalculator() {
  const [initialBalance, setInitialBalance] = useState<string>('10000');
  const [monthlyReturn, setMonthlyReturn] = useState<string>('5');
  const [months, setMonths] = useState<string>('12');
  const [monthlyDeposit, setMonthlyDeposit] = useState<string>('0');
  const [compoundingFrequency, setCompoundingFrequency] = useState<string>('monthly');
  const [results, setResults] = useState<Array<{ month: number; balance: number; totalDeposits: number }> | null>(null);
  
  const { toast } = useToast();

  const calculateCompounding = async () => {
    const initial = parseFloat(initialBalance);
    const returnRate = parseFloat(monthlyReturn);
    const period = parseInt(months);
    const deposit = parseFloat(monthlyDeposit) || 0;
    
    if (!initial || !returnRate || !period) {
      toast({
        title: 'Invalid Input',
        description: 'Please enter valid values for all required fields.',
        variant: 'destructive',
      });
      return;
    }

    try {
      const compoundingResults = CalculatorUtils.calculateCompounding({
        initialBalance: initial,
        monthlyReturn: returnRate,
        months: period,
        monthlyDeposit: deposit,
      });

      setResults(compoundingResults);

      // Save calculation result
      await forexAPI.saveCalculatorResult('compounding', {
        initialBalance: initial,
        monthlyReturn: returnRate,
        months: period,
        monthlyDeposit: deposit,
      }, {
        finalBalance: compoundingResults[compoundingResults.length - 1].balance,
        totalReturn: compoundingResults[compoundingResults.length - 1].balance - initial,
        totalDeposits: compoundingResults[compoundingResults.length - 1].totalDeposits,
      });

      toast({
        title: 'Calculation Complete',
        description: 'Compounding projection calculated successfully!',
      });

    } catch (error) {
      toast({
        title: 'Calculation Error',
        description: 'Failed to calculate compounding. Please try again.',
        variant: 'destructive',
      });
    }
  };

  const finalResult = results ? results[results.length - 1] : null;
  const totalProfit = finalResult ? finalResult.balance - finalResult.totalDeposits : 0;
  const totalReturn = finalResult && finalResult.totalDeposits > 0 ? ((finalResult.balance - finalResult.totalDeposits) / finalResult.totalDeposits) * 100 : 0;

  return (
    <>
      <SEOHead
        title="Compounding Calculator | Simulate Account Growth & Trading Returns - ForexCalculatorPro"
        description="Free compounding calculator to simulate account growth over time. Calculate compound interest, monthly returns, and long-term trading profits with customizable parameters."
        keywords="compounding calculator, compound interest calculator, trading returns calculator, account growth simulator, forex compounding"
        canonicalUrl="https://forexcalculatorpro.com/compounding-calculator"
      />

      <div className="min-h-screen bg-navy-50">
        <Header />

        {/* Hero Section */}
        <section className="navy-gradient text-white py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                Professional <span className="text-gold-400">Compounding Calculator</span>
              </h1>
              <p className="text-xl mb-8 text-navy-100 max-w-3xl mx-auto">
                Simulate account growth over time with customizable win rates and compounding strategies. 
                Visualize the power of compound returns in your trading journey.
              </p>
            </div>
          </div>
        </section>

        {/* Main Calculator Section */}
        <section className="py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Calculator Card */}
              <div className="lg:col-span-2">
                <Card className="calculator-card">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <div className="bg-gold-500 p-2 rounded-lg mr-3">
                        <TrendingUp className="w-6 h-6 text-white" />
                      </div>
                      Account Growth Simulator
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      {/* Initial Balance */}
                      <div className="space-y-2">
                        <Label htmlFor="initialBalance">Initial Balance ($)</Label>
                        <Input
                          id="initialBalance"
                          type="number"
                          placeholder="10000"
                          value={initialBalance}
                          onChange={(e) => setInitialBalance(e.target.value)}
                          className="input-field"
                        />
                      </div>

                      {/* Monthly Return */}
                      <div className="space-y-2">
                        <Label htmlFor="monthlyReturn">Monthly Return (%)</Label>
                        <Input
                          id="monthlyReturn"
                          type="number"
                          placeholder="5"
                          step="0.1"
                          value={monthlyReturn}
                          onChange={(e) => setMonthlyReturn(e.target.value)}
                          className="input-field"
                        />
                      </div>

                      {/* Time Period */}
                      <div className="space-y-2">
                        <Label htmlFor="months">Time Period (Months)</Label>
                        <Input
                          id="months"
                          type="number"
                          placeholder="12"
                          value={months}
                          onChange={(e) => setMonths(e.target.value)}
                          className="input-field"
                        />
                      </div>

                      {/* Monthly Deposit */}
                      <div className="space-y-2">
                        <Label htmlFor="monthlyDeposit">Monthly Deposit ($)</Label>
                        <Input
                          id="monthlyDeposit"
                          type="number"
                          placeholder="0"
                          value={monthlyDeposit}
                          onChange={(e) => setMonthlyDeposit(e.target.value)}
                          className="input-field"
                        />
                      </div>

                      {/* Compounding Frequency */}
                      <div className="space-y-2 md:col-span-2">
                        <Label htmlFor="compoundingFrequency">Compounding Frequency</Label>
                        <Select value={compoundingFrequency} onValueChange={setCompoundingFrequency}>
                          <SelectTrigger className="input-field">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="monthly">Monthly</SelectItem>
                            <SelectItem value="quarterly">Quarterly</SelectItem>
                            <SelectItem value="yearly">Yearly</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <Button 
                      onClick={calculateCompounding}
                      className="btn-primary w-full"
                    >
                      <TrendingUp className="w-5 h-5 mr-2" />
                      Calculate Compounding Growth
                    </Button>

                    {/* Results Panel */}
                    {results && finalResult && (
                      <div className="mt-8 p-6 bg-navy-50 rounded-lg">
                        <h3 className="text-lg font-semibold text-navy-900 mb-4">Growth Projection Results</h3>
                        
                        {/* Summary Cards */}
                        <div className="grid md:grid-cols-4 gap-4 mb-6">
                          <Card className="border">
                            <CardContent className="p-4 text-center">
                              <div className="text-2xl font-bold text-green-600">
                                ${finalResult.balance.toFixed(2)}
                              </div>
                              <div className="text-sm text-navy-600">Final Balance</div>
                            </CardContent>
                          </Card>
                          <Card className="border">
                            <CardContent className="p-4 text-center">
                              <div className="text-2xl font-bold text-gold-600">
                                ${totalProfit.toFixed(2)}
                              </div>
                              <div className="text-sm text-navy-600">Total Profit</div>
                            </CardContent>
                          </Card>
                          <Card className="border">
                            <CardContent className="p-4 text-center">
                              <div className="text-2xl font-bold text-blue-600">
                                {totalReturn.toFixed(1)}%
                              </div>
                              <div className="text-sm text-navy-600">Total Return</div>
                            </CardContent>
                          </Card>
                          <Card className="border">
                            <CardContent className="p-4 text-center">
                              <div className="text-2xl font-bold text-navy-600">
                                ${finalResult.totalDeposits.toFixed(2)}
                              </div>
                              <div className="text-sm text-navy-600">Total Invested</div>
                            </CardContent>
                          </Card>
                        </div>

                        {/* Growth Table */}
                        <div className="overflow-x-auto">
                          <table className="w-full text-sm">
                            <thead>
                              <tr className="border-b">
                                <th className="text-left py-2 text-navy-700">Month</th>
                                <th className="text-left py-2 text-navy-700">Balance</th>
                                <th className="text-left py-2 text-navy-700">Total Deposits</th>
                                <th className="text-left py-2 text-navy-700">Profit</th>
                                <th className="text-left py-2 text-navy-700">Growth</th>
                              </tr>
                            </thead>
                            <tbody>
                              {results.slice(0, 13).map((result, index) => {
                                const profit = result.balance - result.totalDeposits;
                                const growth = index > 0 ? ((result.balance - results[index - 1].balance) / results[index - 1].balance) * 100 : 0;
                                return (
                                  <tr key={result.month} className="border-b">
                                    <td className="py-2">{result.month}</td>
                                    <td className="py-2 font-semibold">${result.balance.toFixed(2)}</td>
                                    <td className="py-2">${result.totalDeposits.toFixed(2)}</td>
                                    <td className="py-2 text-green-600">+${profit.toFixed(2)}</td>
                                    <td className="py-2 text-blue-600">{growth > 0 ? `+${growth.toFixed(1)}%` : '0%'}</td>
                                  </tr>
                                );
                              })}
                            </tbody>
                          </table>
                        </div>

                        {/* Visualization Note */}
                        {results.length > 12 && (
                          <div className="mt-4 text-xs text-navy-500">
                            * Showing first 12 months. Full projection calculated for {results.length - 1} months.
                          </div>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Educational Content */}
                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle>The Power of Compounding</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4 text-sm text-navy-600">
                    <p>
                      Compounding is the process where your investment gains generate their own gains over time. 
                      In trading, this means reinvesting your profits to grow your account exponentially.
                    </p>
                    <div className="space-y-2">
                      <h4 className="font-semibold text-navy-900">Key Benefits:</h4>
                      <ul className="list-disc pl-5 space-y-1">
                        <li>Time amplifies the effect - start early for maximum benefit</li>
                        <li>Consistent returns are more powerful than occasional large gains</li>
                        <li>Small improvements in monthly returns create dramatic long-term differences</li>
                        <li>Regular deposits accelerate the compounding effect</li>
                      </ul>
                    </div>
                    <div className="bg-gold-50 p-4 rounded-lg">
                      <p className="text-gold-800">
                        <strong>Einstein allegedly said:</strong> "Compound interest is the eighth wonder of the world. 
                        He who understands it, earns it; he who doesn't, pays it."
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Side Panel */}
              <div className="space-y-6">
                {/* Quick Presets */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Quick Presets</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button
                      variant="outline"
                      className="w-full text-left justify-start"
                      onClick={() => {
                        setInitialBalance('10000');
                        setMonthlyReturn('5');
                        setMonths('12');
                        setMonthlyDeposit('500');
                      }}
                    >
                      Conservative Growth
                      <div className="text-xs text-navy-500 ml-auto">5% monthly</div>
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full text-left justify-start"
                      onClick={() => {
                        setInitialBalance('10000');
                        setMonthlyReturn('10');
                        setMonths('12');
                        setMonthlyDeposit('1000');
                      }}
                    >
                      Aggressive Growth
                      <div className="text-xs text-navy-500 ml-auto">10% monthly</div>
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full text-left justify-start"
                      onClick={() => {
                        setInitialBalance('5000');
                        setMonthlyReturn('3');
                        setMonths('24');
                        setMonthlyDeposit('200');
                      }}
                    >
                      Long-term Steady
                      <div className="text-xs text-navy-500 ml-auto">3% monthly</div>
                    </Button>
                  </CardContent>
                </Card>

                {/* Related Tools */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Related Tools</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <a href="/position-size-calculator" className="flex items-center p-3 hover:bg-navy-50 rounded-lg transition-colors group">
                      <div className="bg-gold-100 p-2 rounded mr-3 group-hover:bg-gold-200">
                        <Calculator className="w-4 h-4 text-gold-600" />
                      </div>
                      <span className="text-navy-700 font-medium">Position Size Calculator</span>
                    </a>
                    <a href="/profit-calculator" className="flex items-center p-3 hover:bg-navy-50 rounded-lg transition-colors group">
                      <div className="bg-gold-100 p-2 rounded mr-3 group-hover:bg-gold-200">
                        <DollarSign className="w-4 h-4 text-gold-600" />
                      </div>
                      <span className="text-navy-700 font-medium">Profit Calculator</span>
                    </a>
                    <a href="/risk-of-ruin-calculator" className="flex items-center p-3 hover:bg-navy-50 rounded-lg transition-colors group">
                      <div className="bg-gold-100 p-2 rounded mr-3 group-hover:bg-gold-200">
                        <Calendar className="w-4 h-4 text-gold-600" />
                      </div>
                      <span className="text-navy-700 font-medium">Risk of Ruin Calculator</span>
                    </a>
                  </CardContent>
                </Card>

                {/* Compounding Tips */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Compounding Tips</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 text-sm text-navy-600">
                      <div className="flex items-start">
                        <div className="w-2 h-2 bg-gold-500 rounded-full mr-3 mt-2"></div>
                        <div>
                          <strong>Be Consistent:</strong> Regular returns beat sporadic large gains
                        </div>
                      </div>
                      <div className="flex items-start">
                        <div className="w-2 h-2 bg-gold-500 rounded-full mr-3 mt-2"></div>
                        <div>
                          <strong>Reinvest Profits:</strong> Don't withdraw gains; let them compound
                        </div>
                      </div>
                      <div className="flex items-start">
                        <div className="w-2 h-2 bg-gold-500 rounded-full mr-3 mt-2"></div>
                        <div>
                          <strong>Start Early:</strong> Time is your greatest ally in compounding
                        </div>
                      </div>
                      <div className="flex items-start">
                        <div className="w-2 h-2 bg-gold-500 rounded-full mr-3 mt-2"></div>
                        <div>
                          <strong>Add Regularly:</strong> Monthly deposits accelerate growth
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
}
