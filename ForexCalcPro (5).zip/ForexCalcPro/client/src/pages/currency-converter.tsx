import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import SEOHead from '@/components/seo-head';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Shuffle, ArrowRightLeft, TrendingUp, Clock } from 'lucide-react';
import { forexAPI } from '@/lib/forex-api';
import { 
  getAllCurrencies, 
  getAllInstruments,
  MAJOR_CURRENCIES, 
  EXOTIC_CURRENCIES,
  METALS, 
  ENERGIES, 
  INDICES, 
  CRYPTOCURRENCIES 
} from '@/data/currency-pairs';
import { useToast } from '@/hooks/use-toast';

interface ConversionResult {
  fromAmount: number;
  toAmount: number;
  rate: number;
  fromCurrency: string;
  toCurrency: string;
  timestamp: string;
}

export default function CurrencyConverter() {
  const [fromCurrency, setFromCurrency] = useState('USD');
  const [toCurrency, setToCurrency] = useState('EUR');
  const [amount, setAmount] = useState<string>('1000');
  const [result, setResult] = useState<ConversionResult | null>(null);
  const [conversionHistory, setConversionHistory] = useState<ConversionResult[]>([]);
  
  const { toast } = useToast();

  const { data: forexRates, isLoading, refetch } = useQuery({
    queryKey: ['/api/forex-rates', fromCurrency],
    queryFn: () => forexAPI.getForexRates(fromCurrency),
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const convertCurrency = async () => {
    const inputAmount = parseFloat(amount);
    
    if (!inputAmount || inputAmount <= 0) {
      toast({
        title: 'Invalid Amount',
        description: 'Please enter a valid amount to convert.',
        variant: 'destructive',
      });
      return;
    }

    if (fromCurrency === toCurrency) {
      toast({
        title: 'Same Currency',
        description: 'Please select different currencies to convert.',
        variant: 'destructive',
      });
      return;
    }

    try {
      const rates = forexRates?.conversion_rates || {};
      const rate = rates[toCurrency] || 1;
      
      // Handle case where we need to convert via USD if direct rate not available
      let finalRate = rate;
      let convertedAmount = inputAmount * finalRate;
      
      // If we have different conversion rates available, use them
      if (rate === 1 && toCurrency !== fromCurrency && toCurrency !== 'USD') {
        // Try cross-currency conversion via USD
        const usdToTarget = rates[toCurrency] || 1;
        convertedAmount = inputAmount * usdToTarget;
        finalRate = usdToTarget;
      }
      
      const conversionResult: ConversionResult = {
        fromAmount: inputAmount,
        toAmount: convertedAmount,
        rate: finalRate,
        fromCurrency,
        toCurrency,
        timestamp: new Date().toISOString(),
      };

      setResult(conversionResult);
      
      // Add to history (keep last 5 conversions)
      setConversionHistory(prev => [conversionResult, ...prev.slice(0, 4)]);

      // Save calculation result
      await forexAPI.saveCalculatorResult('currency-conversion', {
        fromCurrency,
        toCurrency,
        amount: inputAmount,
        rate,
      }, conversionResult);

      toast({
        title: 'Conversion Complete',
        description: 'Currency converted successfully!',
      });

    } catch (error) {
      toast({
        title: 'Conversion Error',
        description: 'Failed to convert currency. Please try again.',
        variant: 'destructive',
      });
    }
  };

  const swapCurrencies = () => {
    const temp = fromCurrency;
    setFromCurrency(toCurrency);
    setToCurrency(temp);
  };

  // Auto-convert when currencies change (if amount is valid)
  useEffect(() => {
    if (amount && parseFloat(amount) > 0 && fromCurrency !== toCurrency) {
      const timer = setTimeout(() => {
        convertCurrency();
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [fromCurrency, toCurrency, forexRates]);

  const allInstruments = getAllInstruments();
  const allCurrencies = getAllCurrencies();
  const lastUpdated = forexRates?.time_last_update_utc ? 
    new Date(forexRates.time_last_update_utc).toLocaleString() : 'Unknown';

  return (
    <>
      <SEOHead
        title="Currency Converter | Real-time Exchange Rates - ForexCalculatorPro"
        description="Free currency converter with live exchange rates. Convert between 150+ currencies including major currencies, exotic pairs, and cryptocurrencies with real-time data."
        keywords="currency converter, exchange rates, forex converter, real-time rates, currency exchange calculator"
        canonicalUrl="https://forexcalculatorpro.com/currency-converter"
      />

      <div className="min-h-screen bg-navy-50">
        <Header />

        {/* Hero Section */}
        <section className="navy-gradient text-white py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                Professional <span className="text-gold-400">Currency Converter</span>
              </h1>
              <p className="text-xl mb-8 text-navy-100 max-w-3xl mx-auto">
                Real-time currency conversion with live interbank rates for 150+ currencies. 
                Convert major currencies, exotic pairs, and cryptocurrencies instantly.
              </p>
            </div>
          </div>
        </section>

        {/* Main Calculator Section */}
        <section className="py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Calculator Card */}
              <div className="lg:col-span-2">
                <Card className="calculator-card">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <div className="bg-gold-500 p-2 rounded-lg mr-3">
                        <Shuffle className="w-6 h-6 text-white" />
                      </div>
                      Live Currency Converter
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Amount Input */}
                    <div className="space-y-2">
                      <Label htmlFor="amount">Amount</Label>
                      <Input
                        id="amount"
                        type="number"
                        placeholder="1000"
                        step="0.01"
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                        className="input-field text-lg"
                      />
                    </div>

                    {/* Currency Selection */}
                    <div className="grid md:grid-cols-3 gap-4 items-end">
                      {/* From Currency */}
                      <div className="space-y-2">
                        <Label htmlFor="fromCurrency">From</Label>
                        <Select value={fromCurrency} onValueChange={setFromCurrency}>
                          <SelectTrigger className="input-field">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <div className="px-2 py-1 text-xs font-semibold text-navy-700 bg-navy-50">
                              Major Currencies
                            </div>
                            {MAJOR_CURRENCIES.map((currency) => (
                              <SelectItem key={`from-${currency.code}`} value={currency.code}>
                                <div className="flex items-center">
                                  <span className="font-mono mr-2">{currency.code}</span>
                                  <span className="text-sm text-navy-600">{currency.name}</span>
                                </div>
                              </SelectItem>
                            ))}
                            <div className="px-2 py-1 text-xs font-semibold text-navy-700 bg-navy-50 mt-2">
                              Exotic & Other Currencies
                            </div>
                            {EXOTIC_CURRENCIES.map((currency) => (
                              <SelectItem key={`from-${currency.code}`} value={currency.code}>
                                <div className="flex items-center">
                                  <span className="font-mono mr-2">{currency.code}</span>
                                  <span className="text-sm text-navy-600">{currency.name}</span>
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      {/* Swap Button */}
                      <div className="flex justify-center">
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={swapCurrencies}
                          className="rounded-full"
                        >
                          <ArrowRightLeft className="w-4 h-4" />
                        </Button>
                      </div>

                      {/* To Currency */}
                      <div className="space-y-2">
                        <Label htmlFor="toCurrency">To</Label>
                        <Select value={toCurrency} onValueChange={setToCurrency}>
                          <SelectTrigger className="input-field">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <div className="px-2 py-1 text-xs font-semibold text-navy-700 bg-navy-50">
                              Major Currencies
                            </div>
                            {MAJOR_CURRENCIES.map((currency) => (
                              <SelectItem key={`to-${currency.code}`} value={currency.code}>
                                <div className="flex items-center">
                                  <span className="font-mono mr-2">{currency.code}</span>
                                  <span className="text-sm text-navy-600">{currency.name}</span>
                                </div>
                              </SelectItem>
                            ))}
                            <div className="px-2 py-1 text-xs font-semibold text-navy-700 bg-navy-50 mt-2">
                              Exotic & Other Currencies
                            </div>
                            {EXOTIC_CURRENCIES.map((currency) => (
                              <SelectItem key={`to-${currency.code}`} value={currency.code}>
                                <div className="flex items-center">
                                  <span className="font-mono mr-2">{currency.code}</span>
                                  <span className="text-sm text-navy-600">{currency.name}</span>
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <Button 
                      onClick={convertCurrency}
                      disabled={isLoading}
                      className="btn-primary w-full"
                    >
                      <Shuffle className="w-5 h-5 mr-2" />
                      Convert Currency
                    </Button>

                    {/* Results Panel */}
                    {result && (
                      <div className="mt-8 p-6 bg-navy-50 rounded-lg">
                        <h3 className="text-lg font-semibold text-navy-900 mb-4">Conversion Result</h3>
                        
                        {/* Main Conversion Display */}
                        <div className="text-center py-6 bg-white rounded-lg border mb-6">
                          <div className="text-2xl text-navy-600 mb-2">
                            {result.fromAmount.toLocaleString()} {result.fromCurrency}
                          </div>
                          <div className="text-gold-500 mb-2">
                            <ArrowRightLeft className="w-6 h-6 mx-auto" />
                          </div>
                          <div className="text-3xl font-bold text-green-600">
                            {result.toAmount.toLocaleString(undefined, { 
                              minimumFractionDigits: 2, 
                              maximumFractionDigits: 2 
                            })} {result.toCurrency}
                          </div>
                        </div>

                        {/* Rate Information */}
                        <div className="grid md:grid-cols-2 gap-4">
                          <Card className="border">
                            <CardContent className="p-4">
                              <div className="text-sm text-navy-600">Exchange Rate</div>
                              <div className="text-xl font-bold text-navy-900">
                                1 {result.fromCurrency} = {result.rate.toFixed(6)} {result.toCurrency}
                              </div>
                            </CardContent>
                          </Card>
                          <Card className="border">
                            <CardContent className="p-4">
                              <div className="text-sm text-navy-600">Inverse Rate</div>
                              <div className="text-xl font-bold text-navy-900">
                                1 {result.toCurrency} = {(1 / result.rate).toFixed(6)} {result.fromCurrency}
                              </div>
                            </CardContent>
                          </Card>
                        </div>

                        {/* Last Updated */}
                        <div className="mt-4 text-xs text-navy-500 flex items-center justify-center">
                          <Clock className="w-4 h-4 mr-1" />
                          Last updated: {lastUpdated}
                        </div>
                      </div>
                    )}

                    {/* Conversion History */}
                    {conversionHistory.length > 0 && (
                      <div className="mt-8 p-6 bg-white rounded-lg border">
                        <h3 className="text-lg font-semibold text-navy-900 mb-4">Recent Conversions</h3>
                        <div className="space-y-3">
                          {conversionHistory.map((conversion, index) => (
                            <div key={index} className="flex justify-between items-center py-2 border-b last:border-b-0">
                              <div className="text-sm">
                                {conversion.fromAmount.toLocaleString()} {conversion.fromCurrency} → {conversion.toAmount.toLocaleString(undefined, { 
                                  minimumFractionDigits: 2, 
                                  maximumFractionDigits: 2 
                                })} {conversion.toCurrency}
                              </div>
                              <div className="text-xs text-navy-500">
                                {new Date(conversion.timestamp).toLocaleTimeString()}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Educational Content */}
                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle>Understanding Exchange Rates</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4 text-sm text-navy-600">
                    <p>
                      Exchange rates fluctuate constantly due to supply and demand in the global forex market. 
                      Our converter uses real-time interbank rates for the most accurate conversions.
                    </p>
                    <div className="space-y-2">
                      <h4 className="font-semibold text-navy-900">Key Points:</h4>
                      <ul className="list-disc pl-5 space-y-1">
                        <li>Rates update every 30 seconds during market hours</li>
                        <li>Interbank rates differ from retail exchange rates</li>
                        <li>Major currencies typically have tighter spreads</li>
                        <li>Exotic currencies may have wider bid-ask spreads</li>
                      </ul>
                    </div>
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <p className="text-blue-800">
                        <strong>Note:</strong> Rates shown are indicative interbank rates. 
                        Actual exchange rates may vary depending on your bank or exchange service.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Side Panel */}
              <div className="space-y-6">
                {/* Quick Conversions */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Popular Conversions</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button
                      variant="outline"
                      className="w-full text-left justify-start"
                      onClick={() => {
                        setFromCurrency('USD');
                        setToCurrency('EUR');
                        setAmount('1000');
                      }}
                    >
                      USD to EUR
                      <div className="text-xs text-navy-500 ml-auto">
                        1 USD = {forexRates?.conversion_rates?.['EUR']?.toFixed(4) || '0.0000'}
                      </div>
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full text-left justify-start"
                      onClick={() => {
                        setFromCurrency('GBP');
                        setToCurrency('USD');
                        setAmount('1000');
                      }}
                    >
                      GBP to USD
                      <div className="text-xs text-navy-500 ml-auto">Live rate</div>
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full text-left justify-start"
                      onClick={() => {
                        setFromCurrency('USD');
                        setToCurrency('JPY');
                        setAmount('1000');
                      }}
                    >
                      USD to JPY
                      <div className="text-xs text-navy-500 ml-auto">Live rate</div>
                    </Button>
                  </CardContent>
                </Card>

                {/* Live Rates */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center">
                      <TrendingUp className="w-4 h-4 mr-2" />
                      Live Rates
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 text-sm">
                      {forexRates?.conversion_rates && Object.entries(forexRates.conversion_rates)
                        .filter(([currency]) => ['EUR', 'GBP', 'JPY', 'CHF', 'AUD', 'CAD'].includes(currency))
                        .slice(0, 6)
                        .map(([currency, rate]) => (
                        <div key={currency} className="flex justify-between items-center">
                          <span className="text-navy-600">{fromCurrency}/{currency}</span>
                          <span className="font-semibold text-green-600">
                            {typeof rate === 'number' ? rate.toFixed(5) : rate}
                          </span>
                        </div>
                      ))}
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => refetch()}
                      className="w-full mt-3"
                      disabled={isLoading}
                    >
                      <Clock className="w-4 h-4 mr-2" />
                      {isLoading ? 'Updating...' : 'Refresh Rates'}
                    </Button>
                  </CardContent>
                </Card>

                {/* Market Status */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Market Information</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 text-sm text-navy-600">
                      <div className="flex justify-between">
                        <span>Base Currency:</span>
                        <span className="font-semibold">{fromCurrency}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Data Source:</span>
                        <span className="font-semibold">Interbank</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Update Frequency:</span>
                        <span className="font-semibold">30 seconds</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Last Update:</span>
                        <span className="font-semibold text-xs">
                          {new Date(forexRates?.time_last_update_utc || Date.now()).toLocaleTimeString()}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
}
