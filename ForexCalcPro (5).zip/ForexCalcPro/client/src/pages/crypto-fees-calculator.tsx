import { useState } from 'react';
import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import SEOHead from '@/components/seo-head';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Bitcoin, Calculator, ArrowUpDown, TrendingUp } from 'lucide-react';
import { forexAPI } from '@/lib/forex-api';
import { useToast } from '@/hooks/use-toast';

interface ExchangeFees {
  exchange: string;
  makerFee: number;
  takerFee: number;
  withdrawalFee: number;
  minimumTrade: number;
}

interface FeeCalculationResult {
  exchange: string;
  tradeAmount: number;
  makerFeeAmount: number;
  takerFeeAmount: number;
  withdrawalFeeAmount: number;
  totalFees: number;
  netAmount: number;
}

const exchangeFees: ExchangeFees[] = [
  {
    exchange: 'Binance',
    makerFee: 0.1,
    takerFee: 0.1,
    withdrawalFee: 0.0005,
    minimumTrade: 10,
  },
  {
    exchange: 'Coinbase Pro',
    makerFee: 0.5,
    takerFee: 0.5,
    withdrawalFee: 0.001,
    minimumTrade: 1,
  },
  {
    exchange: 'Kraken',
    makerFee: 0.16,
    takerFee: 0.26,
    withdrawalFee: 0.00025,
    minimumTrade: 1,
  },
  {
    exchange: 'Bitfinex',
    makerFee: 0.1,
    takerFee: 0.2,
    withdrawalFee: 0.0004,
    minimumTrade: 15,
  },
  {
    exchange: 'KuCoin',
    makerFee: 0.1,
    takerFee: 0.1,
    withdrawalFee: 0.001,
    minimumTrade: 1,
  },
  {
    exchange: 'Bybit',
    makerFee: 0.1,
    takerFee: 0.1,
    withdrawalFee: 0.0005,
    minimumTrade: 1,
  },
  {
    exchange: 'OKX',
    makerFee: 0.08,
    takerFee: 0.1,
    withdrawalFee: 0.0004,
    minimumTrade: 1,
  },
  {
    exchange: 'Huobi',
    makerFee: 0.2,
    takerFee: 0.2,
    withdrawalFee: 0.0005,
    minimumTrade: 1,
  },
];

export default function CryptoFeesCalculator() {
  const [selectedExchange, setSelectedExchange] = useState('Binance');
  const [tradeAmount, setTradeAmount] = useState<string>('1000');
  const [orderType, setOrderType] = useState<'maker' | 'taker'>('taker');
  const [includeWithdrawal, setIncludeWithdrawal] = useState(false);
  const [result, setResult] = useState<FeeCalculationResult | null>(null);
  const [comparison, setComparison] = useState<FeeCalculationResult[] | null>(null);
  
  const { toast } = useToast();

  const calculateFees = async () => {
    const amount = parseFloat(tradeAmount);
    
    if (!amount || amount <= 0) {
      toast({
        title: 'Invalid Amount',
        description: 'Please enter a valid trade amount.',
        variant: 'destructive',
      });
      return;
    }

    try {
      const exchange = exchangeFees.find(ex => ex.exchange === selectedExchange);
      if (!exchange) {
        throw new Error('Exchange not found');
      }

      if (amount < exchange.minimumTrade) {
        toast({
          title: 'Below Minimum Trade',
          description: `Minimum trade amount for ${exchange.exchange} is $${exchange.minimumTrade}.`,
          variant: 'destructive',
        });
        return;
      }

      const feeRate = orderType === 'maker' ? exchange.makerFee : exchange.takerFee;
      const tradeFeeAmount = (amount * feeRate) / 100;
      const withdrawalFeeAmount = includeWithdrawal ? exchange.withdrawalFee * 50000 : 0; // Assuming BTC at $50k
      const totalFees = tradeFeeAmount + withdrawalFeeAmount;
      const netAmount = amount - totalFees;

      const calculationResult: FeeCalculationResult = {
        exchange: exchange.exchange,
        tradeAmount: amount,
        makerFeeAmount: (amount * exchange.makerFee) / 100,
        takerFeeAmount: (amount * exchange.takerFee) / 100,
        withdrawalFeeAmount,
        totalFees,
        netAmount,
      };

      setResult(calculationResult);

      // Calculate comparison across all exchanges
      const comparisonResults = exchangeFees.map(ex => {
        const exFeeRate = orderType === 'maker' ? ex.makerFee : ex.takerFee;
        const exTradeFee = (amount * exFeeRate) / 100;
        const exWithdrawalFee = includeWithdrawal ? ex.withdrawalFee * 50000 : 0;
        const exTotalFees = exTradeFee + exWithdrawalFee;
        
        return {
          exchange: ex.exchange,
          tradeAmount: amount,
          makerFeeAmount: (amount * ex.makerFee) / 100,
          takerFeeAmount: (amount * ex.takerFee) / 100,
          withdrawalFeeAmount: exWithdrawalFee,
          totalFees: exTotalFees,
          netAmount: amount - exTotalFees,
        };
      }).sort((a, b) => a.totalFees - b.totalFees);

      setComparison(comparisonResults);

      // Save calculation result
      await forexAPI.saveCalculatorResult('crypto-fees', {
        exchange: selectedExchange,
        tradeAmount: amount,
        orderType,
        includeWithdrawal,
      }, calculationResult);

      toast({
        title: 'Calculation Complete',
        description: 'Crypto exchange fees calculated successfully!',
      });

    } catch (error) {
      toast({
        title: 'Calculation Error',
        description: 'Failed to calculate fees. Please try again.',
        variant: 'destructive',
      });
    }
  };

  const selectedExchangeData = exchangeFees.find(ex => ex.exchange === selectedExchange);

  return (
    <>
      <SEOHead
        title="Crypto Exchange Fees Calculator | Compare Trading Fees - ForexCalculatorPro"
        description="Free crypto exchange fees calculator. Compare trading fees across major cryptocurrency exchanges including Binance, Coinbase, Kraken with maker/taker fee structures."
        keywords="crypto fees calculator, cryptocurrency trading fees, exchange fees comparison, binance fees, coinbase fees, trading cost calculator"
        canonicalUrl="https://forexcalculatorpro.com/crypto-fees-calculator"
      />

      <div className="min-h-screen bg-navy-50">
        <Header />

        {/* Hero Section */}
        <section className="navy-gradient text-white py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                Professional <span className="text-gold-400">Crypto Fees Calculator</span>
              </h1>
              <p className="text-xl mb-8 text-navy-100 max-w-3xl mx-auto">
                Calculate trading fees for multiple crypto exchanges with maker and taker fee structures. 
                Compare costs across major platforms to optimize your trading strategy.
              </p>
            </div>
          </div>
        </section>

        {/* Main Calculator Section */}
        <section className="py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Calculator Card */}
              <div className="lg:col-span-2">
                <Card className="calculator-card">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <div className="bg-gold-500 p-2 rounded-lg mr-3">
                        <Bitcoin className="w-6 h-6 text-white" />
                      </div>
                      Crypto Exchange Fees Calculator
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      {/* Exchange Selection */}
                      <div className="space-y-2">
                        <Label htmlFor="selectedExchange">Exchange</Label>
                        <Select value={selectedExchange} onValueChange={setSelectedExchange}>
                          <SelectTrigger className="input-field">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {exchangeFees.map((exchange) => (
                              <SelectItem key={exchange.exchange} value={exchange.exchange}>
                                {exchange.exchange}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      {/* Order Type */}
                      <div className="space-y-2">
                        <Label htmlFor="orderType">Order Type</Label>
                        <Select value={orderType} onValueChange={(value: 'maker' | 'taker') => setOrderType(value)}>
                          <SelectTrigger className="input-field">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="maker">
                              <div className="flex items-center">
                                <TrendingUp className="w-4 h-4 mr-2 text-green-500" />
                                Maker Order (Limit)
                              </div>
                            </SelectItem>
                            <SelectItem value="taker">
                              <div className="flex items-center">
                                <ArrowUpDown className="w-4 h-4 mr-2 text-blue-500" />
                                Taker Order (Market)
                              </div>
                            </SelectItem>
                          </SelectContent>
                        </Select>
                        <div className="text-xs text-navy-600">
                          Maker orders add liquidity, taker orders remove liquidity
                        </div>
                      </div>

                      {/* Trade Amount */}
                      <div className="space-y-2">
                        <Label htmlFor="tradeAmount">Trade Amount ($)</Label>
                        <Input
                          id="tradeAmount"
                          type="number"
                          placeholder="1000"
                          step="0.01"
                          value={tradeAmount}
                          onChange={(e) => setTradeAmount(e.target.value)}
                          className="input-field"
                        />
                        {selectedExchangeData && (
                          <div className="text-xs text-navy-600">
                            Minimum: ${selectedExchangeData.minimumTrade}
                          </div>
                        )}
                      </div>

                      {/* Include Withdrawal */}
                      <div className="space-y-2">
                        <Label>Include Withdrawal Fee</Label>
                        <div className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            id="includeWithdrawal"
                            checked={includeWithdrawal}
                            onChange={(e) => setIncludeWithdrawal(e.target.checked)}
                            className="rounded border-gray-300"
                          />
                          <Label htmlFor="includeWithdrawal" className="text-sm">
                            Include withdrawal fees in calculation
                          </Label>
                        </div>
                        <div className="text-xs text-navy-600">
                          Withdrawal fees vary by cryptocurrency
                        </div>
                      </div>
                    </div>

                    {/* Current Exchange Info */}
                    {selectedExchangeData && (
                      <div className="p-4 bg-navy-50 rounded-lg">
                        <h4 className="font-semibold text-navy-900 mb-2">{selectedExchangeData.exchange} Fee Structure</h4>
                        <div className="grid md:grid-cols-3 gap-4 text-sm">
                          <div>
                            <span className="text-navy-600">Maker Fee:</span>
                            <span className="font-semibold ml-2">{selectedExchangeData.makerFee}%</span>
                          </div>
                          <div>
                            <span className="text-navy-600">Taker Fee:</span>
                            <span className="font-semibold ml-2">{selectedExchangeData.takerFee}%</span>
                          </div>
                          <div>
                            <span className="text-navy-600">Withdrawal Fee:</span>
                            <span className="font-semibold ml-2">{selectedExchangeData.withdrawalFee} BTC</span>
                          </div>
                        </div>
                      </div>
                    )}

                    <Button 
                      onClick={calculateFees}
                      className="btn-primary w-full"
                    >
                      <Bitcoin className="w-5 h-5 mr-2" />
                      Calculate Trading Fees
                    </Button>

                    {/* Results Panel */}
                    {result && (
                      <div className="mt-8 p-6 bg-navy-50 rounded-lg">
                        <h3 className="text-lg font-semibold text-navy-900 mb-4">Fee Calculation Results</h3>
                        
                        {/* Main Results */}
                        <div className="grid md:grid-cols-2 gap-4 mb-6">
                          <Card className="border">
                            <CardContent className="p-4 text-center">
                              <div className="text-2xl font-bold text-red-600">
                                ${result.totalFees.toFixed(2)}
                              </div>
                              <div className="text-sm text-navy-600">Total Fees</div>
                            </CardContent>
                          </Card>
                          <Card className="border">
                            <CardContent className="p-4 text-center">
                              <div className="text-2xl font-bold text-green-600">
                                ${result.netAmount.toFixed(2)}
                              </div>
                              <div className="text-sm text-navy-600">Net Amount</div>
                            </CardContent>
                          </Card>
                        </div>

                        {/* Fee Breakdown */}
                        <div className="p-4 bg-white rounded-lg border">
                          <h4 className="font-semibold text-navy-900 mb-3">Fee Breakdown</h4>
                          <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                              <span>Trade Amount:</span>
                              <span className="font-semibold">${result.tradeAmount.toFixed(2)}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>{orderType === 'maker' ? 'Maker' : 'Taker'} Fee ({orderType === 'maker' ? selectedExchangeData?.makerFee : selectedExchangeData?.takerFee}%):</span>
                              <span className="text-red-600">-${(orderType === 'maker' ? result.makerFeeAmount : result.takerFeeAmount).toFixed(2)}</span>
                            </div>
                            {includeWithdrawal && (
                              <div className="flex justify-between">
                                <span>Withdrawal Fee:</span>
                                <span className="text-red-600">-${result.withdrawalFeeAmount.toFixed(2)}</span>
                              </div>
                            )}
                            <div className="flex justify-between border-t pt-2">
                              <span className="font-semibold">Net Amount:</span>
                              <span className="font-semibold text-green-600">${result.netAmount.toFixed(2)}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Exchange Comparison */}
                    {comparison && (
                      <div className="mt-8 p-6 bg-white rounded-lg border">
                        <h3 className="text-lg font-semibold text-navy-900 mb-4">Exchange Comparison</h3>
                        <div className="overflow-x-auto">
                          <table className="w-full text-sm">
                            <thead>
                              <tr className="border-b">
                                <th className="text-left py-2 text-navy-700">Exchange</th>
                                <th className="text-left py-2 text-navy-700">Trading Fee</th>
                                {includeWithdrawal && <th className="text-left py-2 text-navy-700">Withdrawal Fee</th>}
                                <th className="text-left py-2 text-navy-700">Total Fees</th>
                                <th className="text-left py-2 text-navy-700">Net Amount</th>
                                <th className="text-left py-2 text-navy-700">Rank</th>
                              </tr>
                            </thead>
                            <tbody>
                              {comparison.map((comp, index) => (
                                <tr key={comp.exchange} className={`border-b ${comp.exchange === selectedExchange ? 'bg-gold-50' : ''}`}>
                                  <td className="py-2 font-semibold">{comp.exchange}</td>
                                  <td className="py-2">${(orderType === 'maker' ? comp.makerFeeAmount : comp.takerFeeAmount).toFixed(2)}</td>
                                  {includeWithdrawal && <td className="py-2">${comp.withdrawalFeeAmount.toFixed(2)}</td>}
                                  <td className="py-2 text-red-600 font-semibold">${comp.totalFees.toFixed(2)}</td>
                                  <td className="py-2 text-green-600 font-semibold">${comp.netAmount.toFixed(2)}</td>
                                  <td className="py-2">
                                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                      index === 0 ? 'bg-green-100 text-green-800' :
                                      index === 1 ? 'bg-blue-100 text-blue-800' :
                                      index === 2 ? 'bg-yellow-100 text-yellow-800' :
                                      'bg-gray-100 text-gray-800'
                                    }`}>
                                      #{index + 1}
                                    </span>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Educational Content */}
                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle>Understanding Crypto Exchange Fees</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4 text-sm text-navy-600">
                    <p>
                      Cryptocurrency exchanges charge various fees for trading and withdrawals. 
                      Understanding these fees is crucial for optimizing your trading profitability.
                    </p>
                    <div className="space-y-2">
                      <h4 className="font-semibold text-navy-900">Fee Types:</h4>
                      <ul className="list-disc pl-5 space-y-1">
                        <li><strong>Maker Fees:</strong> Charged when you add liquidity to the order book</li>
                        <li><strong>Taker Fees:</strong> Charged when you remove liquidity from the order book</li>
                        <li><strong>Withdrawal Fees:</strong> Fixed fees for moving crypto off the exchange</li>
                        <li><strong>Deposit Fees:</strong> Usually free for crypto deposits</li>
                      </ul>
                    </div>
                    <div className="bg-orange-50 p-4 rounded-lg">
                      <p className="text-orange-800">
                        <strong>Pro Tip:</strong> Maker orders typically have lower fees than taker orders. 
                        Use limit orders to become a maker and reduce your trading costs.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Side Panel */}
              <div className="space-y-6">
                {/* Quick Presets */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Quick Trade Amounts</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button
                      variant="outline"
                      className="w-full text-left justify-start"
                      onClick={() => setTradeAmount('100')}
                    >
                      Small Trade
                      <div className="text-xs text-navy-500 ml-auto">$100</div>
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full text-left justify-start"
                      onClick={() => setTradeAmount('1000')}
                    >
                      Medium Trade
                      <div className="text-xs text-navy-500 ml-auto">$1,000</div>
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full text-left justify-start"
                      onClick={() => setTradeAmount('10000')}
                    >
                      Large Trade
                      <div className="text-xs text-navy-500 ml-auto">$10,000</div>
                    </Button>
                  </CardContent>
                </Card>

                {/* Related Tools */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Related Tools</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <a href="/currency-converter" className="flex items-center p-3 hover:bg-navy-50 rounded-lg transition-colors group">
                      <div className="bg-gold-100 p-2 rounded mr-3 group-hover:bg-gold-200">
                        <ArrowUpDown className="w-4 h-4 text-gold-600" />
                      </div>
                      <span className="text-navy-700 font-medium">Currency Converter</span>
                    </a>
                    <a href="/profit-calculator" className="flex items-center p-3 hover:bg-navy-50 rounded-lg transition-colors group">
                      <div className="bg-gold-100 p-2 rounded mr-3 group-hover:bg-gold-200">
                        <Calculator className="w-4 h-4 text-gold-600" />
                      </div>
                      <span className="text-navy-700 font-medium">Profit Calculator</span>
                    </a>
                    <a href="/position-size-calculator" className="flex items-center p-3 hover:bg-navy-50 rounded-lg transition-colors group">
                      <div className="bg-gold-100 p-2 rounded mr-3 group-hover:bg-gold-200">
                        <TrendingUp className="w-4 h-4 text-gold-600" />
                      </div>
                      <span className="text-navy-700 font-medium">Position Size Calculator</span>
                    </a>
                  </CardContent>
                </Card>

                {/* Fee Tips */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Fee Reduction Tips</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 text-sm text-navy-600">
                      <div className="flex items-start">
                        <div className="w-2 h-2 bg-green-500 rounded-full mr-3 mt-2"></div>
                        <div>
                          <strong>Use Limit Orders:</strong> Become a maker to get lower fees
                        </div>
                      </div>
                      <div className="flex items-start">
                        <div className="w-2 h-2 bg-blue-500 rounded-full mr-3 mt-2"></div>
                        <div>
                          <strong>Hold Exchange Tokens:</strong> Many exchanges offer fee discounts
                        </div>
                      </div>
                      <div className="flex items-start">
                        <div className="w-2 h-2 bg-yellow-500 rounded-full mr-3 mt-2"></div>
                        <div>
                          <strong>Increase Volume:</strong> Higher trading volume often means lower fees
                        </div>
                      </div>
                      <div className="flex items-start">
                        <div className="w-2 h-2 bg-purple-500 rounded-full mr-3 mt-2"></div>
                        <div>
                          <strong>Compare Exchanges:</strong> Fees vary significantly between platforms
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
}
