import GoogleAdsense from './google-adsense';

interface BannerAdProps {
  position: 'header' | 'sidebar' | 'footer' | 'content';
  className?: string;
}

export default function BannerAd({ position, className = '' }: BannerAdProps) {
  // Different ad slots for different positions
  const adSlots = {
    header: '1234567890',
    sidebar: '2345678901', 
    footer: '3456789012',
    content: '4567890123'
  };

  const adFormats = {
    header: 'horizontal',
    sidebar: 'vertical',
    footer: 'horizontal', 
    content: 'rectangle'
  };

  return (
    <div className={`banner-ad banner-ad-${position} ${className}`}>
      <div className="text-xs text-gray-500 mb-1 text-center">Advertisement</div>
      <GoogleAdsense
        adSlot={adSlots[position]}
        adFormat={adFormats[position]}
        className="w-full"
      />
    </div>
  );
}