import { useState } from 'react';
import { ExternalLink, Copy, Check } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';

interface WordPressIframeProps {
  calculatorName: string;
  calculatorPath: string;
}

export default function WordPressIframe({ calculatorName, calculatorPath }: WordPressIframeProps) {
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();
  
  // Get current domain for iframe URL
  const currentDomain = window.location.origin;
  const iframeUrl = `${currentDomain}${calculatorPath}`;
  
  // WordPress iframe code
  const iframeCode = `<iframe 
  src="${iframeUrl}" 
  width="100%" 
  height="600" 
  frameborder="0" 
  scrolling="auto"
  title="${calculatorName} - ForexCalculatorPro">
</iframe>

<!-- Optional: Add this CSS to make it responsive -->
<style>
  iframe {
    max-width: 100%;
    border: 1px solid #ddd;
    border-radius: 8px;
  }
  
  @media (max-width: 768px) {
    iframe {
      height: 500px;
    }
  }
</style>`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(iframeCode).then(() => {
      setCopied(true);
      toast({
        title: "Copied to clipboard",
        description: "WordPress iframe code copied successfully",
      });
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <Card className="mt-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ExternalLink className="w-5 h-5" />
          WordPress Integration
        </CardTitle>
        <p className="text-sm text-navy-600">
          Embed this calculator on your WordPress site using the iframe code below
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="iframe-url">Calculator URL:</Label>
          <Input
            id="iframe-url"
            value={iframeUrl}
            readOnly
            className="font-mono text-sm"
          />
        </div>
        
        <div>
          <Label htmlFor="iframe-code">WordPress Iframe Code:</Label>
          <div className="relative">
            <Textarea
              id="iframe-code"
              value={iframeCode}
              readOnly
              rows={15}
              className="font-mono text-xs resize-none"
            />
            <Button
              onClick={copyToClipboard}
              size="sm"
              className="absolute top-2 right-2"
              variant="outline"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 mr-1" />
                  Copied
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 mr-1" />
                  Copy
                </>
              )}
            </Button>
          </div>
        </div>

        <div className="bg-blue-50 border-l-4 border-blue-400 p-4">
          <h4 className="font-semibold text-blue-800 mb-2">WordPress Integration Steps:</h4>
          <ol className="list-decimal list-inside text-sm text-blue-700 space-y-1">
            <li>Copy the iframe code above</li>
            <li>Go to your WordPress admin dashboard</li>
            <li>Edit the page/post where you want to add the calculator</li>
            <li>Switch to HTML/Code editor (not Visual editor)</li>
            <li>Paste the iframe code where you want the calculator to appear</li>
            <li>Save and publish your page</li>
          </ol>
        </div>

        <div className="bg-green-50 border-l-4 border-green-400 p-4">
          <h4 className="font-semibold text-green-800 mb-2">Monetization Tips:</h4>
          <ul className="list-disc list-inside text-sm text-green-700 space-y-1">
            <li>Add Google AdSense ads above and below the calculator</li>
            <li>Include affiliate links to forex brokers</li>
            <li>Offer premium trading tools or courses</li>
            <li>Create email opt-in forms for trading newsletters</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}