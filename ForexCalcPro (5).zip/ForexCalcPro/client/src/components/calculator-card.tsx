import { Link } from 'wouter';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowRight } from 'lucide-react';

interface CalculatorCardProps {
  title: string;
  description: string;
  href: string;
  icon: React.ReactNode;
}

export default function CalculatorCard({ title, description, href, icon }: CalculatorCardProps) {
  return (
    <Card className="calculator-card group">
      <CardContent className="p-4 sm:p-6">
        <div className="flex items-center mb-3 sm:mb-4">
          <div className="bg-gold-500 p-2 sm:p-3 rounded-lg mr-3 sm:mr-4 group-hover:bg-gold-600 transition-colors shrink-0">
            {icon}
          </div>
          <h3 className="text-base sm:text-lg font-semibold text-navy-900 leading-tight">{title}</h3>
        </div>
        <p className="text-navy-600 mb-3 sm:mb-4 text-xs sm:text-sm leading-relaxed">{description}</p>
        <Link
          href={href}
          className="text-gold-600 font-medium hover:text-gold-700 flex items-center group-hover:translate-x-1 transition-transform"
        >
          Access Tool
          <ArrowRight className="w-4 h-4 ml-1" />
        </Link>
      </CardContent>
    </Card>
  );
}
