import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

import { Newspaper, Clock, ExternalLink, Search, Filter, TrendingUp, AlertCircle, Globe } from 'lucide-react';

interface NewsArticle {
  id: string;
  title: string;
  description: string;
  url: string;
  urlToImage?: string;
  publishedAt: string;
  source: string;
  category: 'forex' | 'economic' | 'central-bank' | 'market' | 'analysis';
  impact: 'low' | 'medium' | 'high';
  currencies?: string[];
}

interface ForexNewsFeedProps {
  compact?: boolean;
  showSearch?: boolean;
  maxArticles?: number;
}

export default function ForexNewsFeed({ compact = false, showSearch = true, maxArticles = 20 }: ForexNewsFeedProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedImpact, setSelectedImpact] = useState('all');
  const [filteredArticles, setFilteredArticles] = useState<NewsArticle[]>([]);

  // Simulated news data - replace with real API integration
  const mockNews: NewsArticle[] = [
    {
      id: '1',
      title: 'Federal Reserve Signals Potential Rate Hike in Q2 2025',
      description: 'Fed officials indicate a more hawkish stance amid persistent inflation concerns, impacting USD strength across major pairs.',
      url: '#',
      urlToImage: undefined,
      publishedAt: new Date(Date.now() - 1800000).toISOString(), // 30 minutes ago
      source: 'Reuters',
      category: 'central-bank',
      impact: 'high',
      currencies: ['USD']
    },
    {
      id: '2',
      title: 'EUR/USD Breaks Key Resistance at 1.1200 Level',
      description: 'Euro gains momentum against the dollar following stronger than expected German manufacturing data.',
      url: '#',
      publishedAt: new Date(Date.now() - 3600000).toISOString(), // 1 hour ago
      source: 'FXStreet',
      category: 'forex',
      impact: 'medium',
      currencies: ['EUR', 'USD']
    },
    {
      id: '3',
      title: 'Gold Prices Surge to $2,150 on Safe Haven Demand',
      description: 'Precious metals rally as geopolitical tensions escalate, providing support for XAU/USD bulls.',
      url: '#',
      publishedAt: new Date(Date.now() - 5400000).toISOString(), // 1.5 hours ago
      source: 'MarketWatch',
      category: 'market',
      impact: 'high',
      currencies: ['XAU']
    },
    {
      id: '4',
      title: 'Bank of England Maintains Dovish Outlook',
      description: 'BoE Governor emphasizes cautious approach to monetary policy amid UK economic uncertainties.',
      url: '#',
      publishedAt: new Date(Date.now() - 7200000).toISOString(), // 2 hours ago
      source: 'Financial Times',
      category: 'central-bank',
      impact: 'medium',
      currencies: ['GBP']
    },
    {
      id: '5',
      title: 'Japanese Yen Weakens on BoJ Intervention Speculation',
      description: 'USD/JPY climbs higher as market participants debate potential Bank of Japan currency intervention.',
      url: '#',
      publishedAt: new Date(Date.now() - 9000000).toISOString(), // 2.5 hours ago
      source: 'Bloomberg',
      category: 'forex',
      impact: 'medium',
      currencies: ['JPY', 'USD']
    },
    {
      id: '6',
      title: 'ECB Economic Bulletin Shows Growth Concerns',
      description: 'European Central Bank releases quarterly bulletin highlighting downside risks to eurozone economic growth.',
      url: '#',
      publishedAt: new Date(Date.now() - 10800000).toISOString(), // 3 hours ago
      source: 'ECB Press Release',
      category: 'economic',
      impact: 'medium',
      currencies: ['EUR']
    },
    {
      id: '7',
      title: 'Oil Prices Impact CAD as Inventory Data Released',
      description: 'Canadian Dollar reacts to weekly petroleum inventory figures showing unexpected build.',
      url: '#',
      publishedAt: new Date(Date.now() - 14400000).toISOString(), // 4 hours ago
      source: 'CNBC',
      category: 'market',
      impact: 'low',
      currencies: ['CAD']
    },
    {
      id: '8',
      title: 'Technical Analysis: GBP/USD Eyes 1.2800 Resistance',
      description: 'Sterling approaches critical technical level with momentum indicators showing bullish divergence.',
      url: '#',
      publishedAt: new Date(Date.now() - 16200000).toISOString(), // 4.5 hours ago
      source: 'DailyFX',
      category: 'analysis',
      impact: 'low',
      currencies: ['GBP', 'USD']
    }
  ];

  // Filter articles based on search and filters
  useEffect(() => {
    let filtered = mockNews;

    if (searchQuery) {
      filtered = filtered.filter(article =>
        article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        article.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        article.currencies?.some(curr => curr.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }

    if (selectedCategory !== 'all') {
      filtered = filtered.filter(article => article.category === selectedCategory);
    }

    if (selectedImpact !== 'all') {
      filtered = filtered.filter(article => article.impact === selectedImpact);
    }

    setFilteredArticles(filtered.slice(0, maxArticles));
  }, [searchQuery, selectedCategory, selectedImpact, maxArticles]);

  const formatTimeAgo = (dateString: string): string => {
    const now = new Date();
    const publishTime = new Date(dateString);
    const diffMs = now.getTime() - publishTime.getTime();
    
    const minutes = Math.floor(diffMs / (1000 * 60));
    const hours = Math.floor(diffMs / (1000 * 60 * 60));

    if (minutes < 60) {
      return `${minutes}m ago`;
    } else if (hours < 24) {
      return `${hours}h ago`;
    } else {
      const days = Math.floor(hours / 24);
      return `${days}d ago`;
    }
  };

  const getImpactColor = (impact: string): 'destructive' | 'secondary' | 'outline' | 'default' => {
    switch (impact) {
      case 'high': return 'destructive';
      case 'medium': return 'secondary';
      case 'low': return 'outline';
      default: return 'outline';
    }
  };

  const getImpactIcon = (impact: string) => {
    switch (impact) {
      case 'high': return <AlertCircle className="w-3 h-3" />;
      case 'medium': return <TrendingUp className="w-3 h-3" />;
      case 'low': return <Globe className="w-3 h-3" />;
      default: return null;
    }
  };

  const getCategoryColor = (category: string): string => {
    switch (category) {
      case 'forex': return 'bg-blue-100 text-blue-800';
      case 'economic': return 'bg-green-100 text-green-800';
      case 'central-bank': return 'bg-purple-100 text-purple-800';
      case 'market': return 'bg-orange-100 text-orange-800';
      case 'analysis': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (compact) {
    return (
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center text-lg">
            <Newspaper className="w-5 h-5 mr-2 text-gold-500" />
            Market News
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {filteredArticles.slice(0, 5).map((article) => (
            <div key={article.id} className="border-b border-gray-100 last:border-0 pb-3 last:pb-0">
              <div className="flex justify-between items-start mb-1">
                <h4 className="text-sm font-medium line-clamp-2">{article.title}</h4>
                <span className="text-xs text-gray-500 ml-2 flex-shrink-0">{formatTimeAgo(article.publishedAt)}</span>
              </div>
              <div className="flex items-center space-x-2 text-xs">
                <Badge variant={getImpactColor(article.impact)} className="px-1 py-0 h-5">
                  {getImpactIcon(article.impact)}
                  <span className="ml-1">{article.impact.toUpperCase()}</span>
                </Badge>
                <span className="text-gray-500">{article.source}</span>
                {article.currencies && (
                  <div className="flex space-x-1">
                    {article.currencies.slice(0, 2).map(curr => (
                      <span key={curr} className="bg-gray-200 px-1 rounded text-xs">{curr}</span>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Newspaper className="w-6 h-6 mr-2 text-gold-500" />
          Forex Market News
        </CardTitle>

        {showSearch && (
          <div className="flex flex-wrap gap-4 mt-4">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="w-4 h-4 absolute left-3 top-3 text-gray-400" />
              <Input
                placeholder="Search news, currencies..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>

            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-[140px]">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="forex">Forex</SelectItem>
                <SelectItem value="economic">Economic</SelectItem>
                <SelectItem value="central-bank">Central Bank</SelectItem>
                <SelectItem value="market">Market</SelectItem>
                <SelectItem value="analysis">Analysis</SelectItem>
              </SelectContent>
            </Select>

            <Select value={selectedImpact} onValueChange={setSelectedImpact}>
              <SelectTrigger className="w-[120px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Impact</SelectItem>
                <SelectItem value="high">High Impact</SelectItem>
                <SelectItem value="medium">Medium Impact</SelectItem>
                <SelectItem value="low">Low Impact</SelectItem>
              </SelectContent>
            </Select>
          </div>
        )}
      </CardHeader>

      <CardContent>
        <div className="space-y-4">
          {filteredArticles.map((article) => (
            <div key={article.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-semibold text-gray-900 line-clamp-2">{article.title}</h3>
                <div className="flex items-center text-sm text-gray-500 ml-4 flex-shrink-0">
                  <Clock className="w-4 h-4 mr-1" />
                  {formatTimeAgo(article.publishedAt)}
                </div>
              </div>
              
              <p className="text-gray-600 text-sm mb-3 line-clamp-2">{article.description}</p>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Badge variant={getImpactColor(article.impact)}>
                    {getImpactIcon(article.impact)}
                    <span className="ml-1">{article.impact.toUpperCase()}</span>
                  </Badge>
                  
                  <span className={`text-xs px-2 py-1 rounded-full ${getCategoryColor(article.category)}`}>
                    {article.category.replace('-', ' ').toUpperCase()}
                  </span>
                  
                  <span className="text-sm text-gray-500">{article.source}</span>
                </div>
                
                <div className="flex items-center space-x-2">
                  {article.currencies && (
                    <div className="flex space-x-1">
                      {article.currencies.map(curr => (
                        <span key={curr} className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs font-medium">
                          {curr}
                        </span>
                      ))}
                    </div>
                  )}
                  
                  <Button variant="ghost" size="sm" className="p-2">
                    <ExternalLink className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
          
          {filteredArticles.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              <Newspaper className="w-12 h-12 mx-auto mb-4 text-gray-300" />
              <p>No news articles found matching your criteria.</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}