#!/bin/bash

echo "🚀 Starting Render build process for Forex Calculator Platform..."

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Create dist directory
echo "📁 Creating build directory..."
mkdir -p dist
mkdir -p dist/public

# Build client (frontend)
echo "🎨 Building frontend with Vite..."
npx vite build --outDir=dist/public

# Build server (backend)
echo "⚙️ Building backend with esbuild..."
npx esbuild server/index.ts --bundle --platform=node --outfile=dist/index.js --external:tsx --format=cjs

# Copy any additional assets
echo "📋 Copying additional assets..."
cp -r shared dist/ 2>/dev/null || echo "No shared folder to copy"

# Verify build output
echo "✅ Verifying build output..."
ls -la dist/
ls -la dist/public/

echo "🎉 Build completed successfully!"
echo "📊 Build statistics:"
echo "- Frontend: $(du -sh dist/public | cut -f1)"
echo "- Backend: $(du -sh dist/index.js | cut -f1)"
echo "- Total: $(du -sh dist | cut -f1)"