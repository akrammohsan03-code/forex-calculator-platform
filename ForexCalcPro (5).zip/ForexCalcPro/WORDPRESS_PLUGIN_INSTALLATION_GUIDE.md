# WordPress Plugin Installation Guide - Forex Calculator Pro

## 🔧 **Plugin Not Showing? Follow These Steps**

### **Step 1: Create Plugin Folder Structure**

1. **Access your WordPress via FTP/cPanel File Manager**
2. **Navigate to**: `/wp-content/plugins/`
3. **Create new folder**: `forex-calculator-pro`
4. **Upload these files in the folder**:
   ```
   forex-calculator-pro/
   ├── forex-calculators-plugin.php
   └── assets/
       ├── style.css
       └── script.js
   ```

### **Step 2: Upload Plugin Files**

**Copy these files from your project:**
- `wordpress-integration/forex-calculators-plugin.php` → Upload to plugin folder
- `wordpress-integration/assets/style.css` → Upload to `assets/` folder  
- `wordpress-integration/assets/script.js` → Upload to `assets/` folder

### **Step 3: Activate Plugin**

1. **Go to WordPress Admin** → **Plugins** → **Installed Plugins**
2. **Find "Forex Calculator Pro"**
3. **Click "Activate"**

### **Step 4: Add Calculators to Pages**

**Create a new page and add these shortcodes:**

```
[forex_position_size]
[forex_pip_calculator]
[forex_profit_calculator]
[forex_margin_calculator]
[forex_currency_converter]
```

### **Step 5: Test Calculators**

1. **View the page** with shortcodes
2. **Check if calculators display**
3. **Test calculations** by entering values
4. **Verify results appear**

## 🚨 **Troubleshooting**

### **Plugin Not Appearing in Admin?**

**Check file structure:**
```
/wp-content/plugins/forex-calculator-pro/
├── forex-calculators-plugin.php  (Must be here!)
└── assets/
    ├── style.css
    └── script.js
```

### **Shortcodes Not Working?**

1. **Check plugin is activated**
2. **Verify shortcode spelling**: `[forex_position_size]`
3. **Try on different page/post**

### **Calculators Show But Don't Work?**

1. **Check browser console** for JavaScript errors
2. **Ensure jQuery is loaded** (most WordPress themes include it)
3. **Test with default WordPress theme**

### **Styling Issues?**

1. **Check if CSS file loads** in browser developer tools
2. **Add `!important` to CSS** if theme conflicts
3. **Use theme's color scheme** by editing CSS

## 📋 **Quick Test Shortcodes**

**Add this to any page/post to test:**

```html
<h3>Position Size Calculator</h3>
[forex_position_size]

<h3>Pip Calculator</h3>
[forex_pip_calculator]

<h3>Profit Calculator</h3>
[forex_profit_calculator]
```

## 🎯 **Expected Results**

After successful installation, you should see:
- ✅ Professional calculator forms
- ✅ Working input fields and dropdowns
- ✅ Calculate buttons that respond
- ✅ Results display after calculation
- ✅ Mobile-responsive design

## 💰 **Add Your AdSense Code**

**Edit the plugin file and replace:**
```php
data-ad-client="ca-pub-XXXXXXXXXX"
```
**With your actual AdSense publisher ID**

## 📞 **Still Having Issues?**

**Check WordPress Requirements:**
- WordPress 5.0 or higher
- PHP 7.4 or higher
- Active theme with jQuery support
- No plugin conflicts

**Common Solutions:**
1. **Deactivate other plugins** temporarily
2. **Switch to default theme** for testing
3. **Check file permissions** (644 for files, 755 for folders)
4. **Clear caching** if using cache plugins

Your forex calculators should now work perfectly in WordPress! 🚀