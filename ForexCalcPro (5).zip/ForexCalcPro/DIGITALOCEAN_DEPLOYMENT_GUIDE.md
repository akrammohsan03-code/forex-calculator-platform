# DigitalOcean Deployment Guide - Forex Calculator Platform

## 🌊 Why DigitalOcean for Your Forex Calculators?

- **Cost-effective**: $6/month droplet handles thousands of visitors
- **Full control**: Complete server access and customization
- **Scalable**: Easy to upgrade when your ad revenue grows
- **Professional**: Perfect for serious monetization
- **Node.js ready**: Pre-configured for your application

## 🚀 Step-by-Step Deployment Process

### Phase 1: Create DigitalOcean Account & Droplet

#### 1.1 Sign Up for DigitalOcean
1. Go to `https://www.digitalocean.com`
2. Click **"Sign Up"** 
3. Use this link for **$200 free credit**: `https://m.do.co/c/your-referral-code`
4. Verify your email and add payment method

#### 1.2 Create Your Droplet
1. **Click "Create"** → **"Droplets"**
2. **Choose Image**: Ubuntu 22.04 LTS
3. **Choose Plan**: 
   - **Basic**: $6/month (1GB RAM, 1 CPU, 25GB SSD)
   - **Recommended for start**: Perfect for forex calculators
4. **Add Authentication**: 
   - **SSH Key** (recommended) or **Password**
5. **Choose Hostname**: `forex-calculator-server`
6. **Click "Create Droplet"**

#### 1.3 Note Your Server Details
```
IP Address: 123.456.789.101
Username: root
SSH Key: Your uploaded key
```

### Phase 2: Server Setup & Configuration

#### 2.1 Connect to Your Server
```bash
# SSH into your droplet
ssh root@123.456.789.101

# Update system packages
apt update && apt upgrade -y
```

#### 2.2 Install Node.js & Dependencies
```bash
# Install Node.js 18.x
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
apt-get install -y nodejs

# Install additional tools
apt-get install -y nginx git ufw certbot python3-certbot-nginx

# Verify installation
node --version
npm --version
```

#### 2.3 Configure Firewall
```bash
# Set up UFW firewall
ufw allow ssh
ufw allow 'Nginx Full'
ufw allow 80
ufw allow 443
ufw enable
```

### Phase 3: Deploy Your Forex Calculator App

#### 3.1 Upload Your Project Files
**Method A: Direct Upload**
```bash
# Create app directory
mkdir /var/www/forex-calculator
cd /var/www/forex-calculator

# Upload your files here (use SCP, SFTP, or Git)
```

**Method B: Using Git (if you have repository)**
```bash
# Clone your repository
cd /var/www
git clone https://github.com/yourusername/forex-calculator.git
cd forex-calculator
```

**Method C: Manual File Transfer**
Use FileZilla or WinSCP to upload your project files to `/var/www/forex-calculator`

#### 3.2 Install Dependencies & Build
```bash
# Navigate to your app directory
cd /var/www/forex-calculator

# Install dependencies
npm install

# Build production version
npm run build

# Install PM2 for process management
npm install -g pm2
```

#### 3.3 Configure Environment Variables
```bash
# Create environment file
nano .env

# Add your configuration:
VITE_GOOGLE_ADSENSE_CLIENT=ca-pub-XXXXXXXXXX
NODE_ENV=production
PORT=5000
```

#### 3.4 Start Your Application
```bash
# Start with PM2
pm2 start server/index.ts --name "forex-calculator" --interpreter="node --loader tsx"

# Save PM2 configuration
pm2 save
pm2 startup

# Check status
pm2 status
```

### Phase 4: Configure Nginx Reverse Proxy

#### 4.1 Create Nginx Configuration
```bash
# Create site configuration
nano /etc/nginx/sites-available/forex-calculator

# Add this configuration:
server {
    listen 80;
    server_name your-domain.com www.your-domain.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    # Optimize static assets
    location /assets/ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

#### 4.2 Enable Site & Restart Nginx
```bash
# Enable the site
ln -s /etc/nginx/sites-available/forex-calculator /etc/nginx/sites-enabled/

# Test configuration
nginx -t

# Restart Nginx
systemctl restart nginx
systemctl enable nginx
```

### Phase 5: Domain & SSL Configuration

#### 5.1 Point Domain to DigitalOcean
1. **Log into your domain registrar**
2. **Change nameservers** to DigitalOcean:
   - `ns1.digitalocean.com`
   - `ns2.digitalocean.com`
   - `ns3.digitalocean.com`

#### 5.2 Configure DNS in DigitalOcean
1. **Go to DigitalOcean Dashboard** → **Networking** → **Domains**
2. **Add Domain**: `your-domain.com`
3. **Create A Records**:
   - `@` → Your droplet IP
   - `www` → Your droplet IP

#### 5.3 Install SSL Certificate
```bash
# Install Let's Encrypt SSL
certbot --nginx -d your-domain.com -d www.your-domain.com

# Test auto-renewal
certbot renew --dry-run
```

### Phase 6: Optimize Performance

#### 6.1 Enable Gzip Compression
```bash
# Edit Nginx configuration
nano /etc/nginx/nginx.conf

# Add in http block:
gzip on;
gzip_vary on;
gzip_min_length 1024;
gzip_types
    text/plain
    text/css
    text/xml
    text/javascript
    application/javascript
    application/xml+rss
    application/json;
```

#### 6.2 Configure Node.js App for Production
```bash
# Update your server configuration
nano /var/www/forex-calculator/server/index.ts

# Ensure production optimizations:
# - Compression middleware
# - Security headers
# - Error handling
```

#### 6.3 Set Up Monitoring
```bash
# Install monitoring tools
pm2 install pm2-logrotate

# Configure log rotation
pm2 set pm2-logrotate:max_size 10M
pm2 set pm2-logrotate:retain 30

# Check logs
pm2 logs
```

### Phase 7: Update WordPress Integration

#### 7.1 Update All Iframe URLs
**In WordPress Admin:**
1. **Search and Replace** all iframe URLs
2. **From**: `https://your-project.replit.app/position-size-calculator`
3. **To**: `https://your-domain.com/position-size-calculator`

#### 7.2 Test All Calculators
Verify these URLs work:
- `https://your-domain.com/position-size-calculator`
- `https://your-domain.com/pip-calculator`
- `https://your-domain.com/profit-calculator`
- `https://your-domain.com/margin-calculator`
- `https://your-domain.com/currency-converter`

### Phase 8: Activate Monetization

#### 8.1 Update Google AdSense
1. **Add new domain** to AdSense account
2. **Update ads.txt** file if required
3. **Wait for approval** (usually 24-48 hours)

#### 8.2 Set Up Analytics
```bash
# Add Google Analytics tracking
# Update your React components with GA4 code
```

## 🔧 Maintenance & Management

### Regular Tasks
```bash
# Update system packages
apt update && apt upgrade -y

# Restart application if needed
pm2 restart forex-calculator

# Check application status
pm2 status

# View logs
pm2 logs forex-calculator

# Monitor resources
htop
df -h
```

### Backup Strategy
```bash
# Create backup script
nano /root/backup.sh

#!/bin/bash
# Backup application
tar -czf /root/forex-calculator-backup-$(date +%Y%m%d).tar.gz /var/www/forex-calculator

# Backup to DigitalOcean Spaces (optional)
# Configure s3cmd and upload
```

### Scaling When Revenue Grows
```bash
# Upgrade droplet in DigitalOcean dashboard
# No downtime with proper planning

# Or add load balancer for high traffic
# DigitalOcean Load Balancer: $12/month
```

## 💰 Cost Breakdown

### Monthly Costs:
- **Droplet**: $6/month (1GB RAM, 1 CPU)
- **Domain**: ~$12/year ($1/month)
- **SSL**: Free (Let's Encrypt)
- **Total**: ~$7/month

### Expected Revenue:
- **Conservative**: $200-500/month
- **Optimistic**: $1000-3000/month
- **ROI**: 2800%+ return on hosting investment

## 🚨 Troubleshooting

### App Not Loading
```bash
# Check PM2 status
pm2 status

# Check logs
pm2 logs forex-calculator

# Restart app
pm2 restart forex-calculator
```

### SSL Issues
```bash
# Renew SSL certificate
certbot renew

# Check certificate status
certbot certificates
```

### Performance Issues
```bash
# Check server resources
htop
free -m
df -h

# Upgrade droplet if needed
```

## 📋 Deployment Checklist

**Pre-Deployment:**
- ✅ DigitalOcean account created
- ✅ Droplet configured with Ubuntu 22.04
- ✅ Node.js and dependencies installed
- ✅ Domain pointed to DigitalOcean

**Deployment:**
- ✅ Application files uploaded
- ✅ Dependencies installed with npm
- ✅ Environment variables configured
- ✅ PM2 process manager set up
- ✅ Nginx reverse proxy configured

**Post-Deployment:**
- ✅ SSL certificate installed
- ✅ Domain resolving correctly
- ✅ All calculators tested and working
- ✅ WordPress iframes updated
- ✅ AdSense integration verified

**Monetization:**
- ✅ Google AdSense domain added
- ✅ Analytics tracking configured
- ✅ Performance monitoring active
- ✅ Backup strategy implemented

## 🎯 Success Metrics

After deployment, you should see:
- **Fast loading times** (< 2 seconds)
- **High uptime** (99.9%+)
- **Mobile responsiveness** across all devices
- **SEO optimization** for search rankings
- **Ad revenue generation** from day one

## 📞 Support Resources

### DigitalOcean Resources:
- **Documentation**: `https://docs.digitalocean.com`
- **Community**: `https://www.digitalocean.com/community`
- **Support**: Available 24/7 via tickets

### Additional Help:
- **Server Management**: Consider managed hosting if you prefer hands-off approach
- **Performance Optimization**: CloudFlare CDN integration
- **Scaling**: Load balancers and multiple droplets when traffic grows

Your forex calculator platform is now ready for professional deployment on DigitalOcean! This setup provides the foundation for serious monetization and scaling as your ad revenue grows.

## 🔄 Migration from Other Platforms

If moving from Replit or other platforms:
1. **Download your project** as ZIP
2. **Extract and upload** to `/var/www/forex-calculator`
3. **Follow deployment steps** above
4. **Update all external references** to new domain
5. **Test thoroughly** before switching traffic

Your professional forex trading platform is ready to generate serious revenue on DigitalOcean! 🚀