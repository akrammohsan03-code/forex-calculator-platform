# Complete WordPress Iframe Integration Guide

## 📋 Overview
This guide will show you exactly how to embed your forex calculators into any WordPress website using iframes. This is perfect for monetizing your content and providing valuable tools to your visitors.

## 🚀 Method 1: Simple HTML Iframe (Easiest)

### Step 1: Get Your Calculator URL
Your forex calculators are available at these URLs:
```
https://your-domain.com/position-size-calculator
https://your-domain.com/pip-calculator
https://your-domain.com/profit-calculator
https://your-domain.com/margin-calculator
https://your-domain.com/currency-converter
```

### Step 2: Create the Iframe Code
```html
<iframe 
  src="https://your-domain.com/position-size-calculator" 
  width="100%" 
  height="600" 
  frameborder="0" 
  scrolling="auto"
  style="border: 1px solid #ddd; border-radius: 8px; max-width: 100%;"
  title="Position Size Calculator">
</iframe>
```

### Step 3: Add to WordPress
1. **Login to WordPress Admin**
   - Go to `https://yoursite.com/wp-admin`
   - Enter your admin credentials

2. **Edit or Create a Page/Post**
   - Go to `Pages` → `Add New` or edit existing page
   - Or go to `Posts` → `Add New` for blog posts

3. **Switch to HTML Editor**
   - Click the `Text` tab (not `Visual`)
   - Or in Gutenberg: Add a `Custom HTML` block

4. **Paste the Iframe Code**
   - Paste your iframe code where you want the calculator
   - Replace `https://your-domain.com` with your actual domain

5. **Publish or Update**
   - Click `Publish` or `Update`
   - View your page to see the calculator

## 🎨 Method 2: Responsive Iframe with Custom CSS

### Enhanced Iframe Code with Responsive Design
```html
<div class="forex-calculator-container">
  <iframe 
    src="https://your-domain.com/position-size-calculator" 
    width="100%" 
    height="600" 
    frameborder="0" 
    scrolling="auto"
    class="forex-calculator-iframe"
    title="Position Size Calculator">
  </iframe>
</div>

<style>
.forex-calculator-container {
  max-width: 900px;
  margin: 20px auto;
  padding: 0 15px;
}

.forex-calculator-iframe {
  width: 100%;
  border: 1px solid #e0e0e0;
  border-radius: 12px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
  background: #fff;
}

/* Mobile responsiveness */
@media (max-width: 768px) {
  .forex-calculator-iframe {
    height: 500px;
  }
  
  .forex-calculator-container {
    padding: 0 10px;
  }
}

@media (max-width: 480px) {
  .forex-calculator-iframe {
    height: 450px;
    border-radius: 8px;
  }
}
</style>
```

### Where to Add This CSS
**Option 1: In WordPress Customizer**
1. Go to `Appearance` → `Customize`
2. Click `Additional CSS`
3. Paste the CSS code (just the part between `<style>` tags)
4. Click `Publish`

**Option 2: In Theme Files**
1. Go to `Appearance` → `Theme Editor`
2. Select `style.css`
3. Add the CSS at the bottom
4. Click `Update File`

## 🔧 Method 3: WordPress Shortcode (Advanced)

### Create a Custom Plugin
1. **Create Plugin File**
   - Create folder: `/wp-content/plugins/forex-calculator/`
   - Create file: `forex-calculator.php`

```php
<?php
/*
Plugin Name: Forex Calculator Embed
Description: Embed forex calculators using shortcodes
Version: 1.0
*/

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Main shortcode function
function forex_calculator_shortcode($atts) {
    // Set default attributes
    $atts = shortcode_atts([
        'type' => 'position-size',
        'height' => '600',
        'width' => '100%',
        'domain' => 'https://your-domain.com'
    ], $atts);

    // Calculator URLs mapping
    $calculators = [
        'position-size' => '/position-size-calculator',
        'pip' => '/pip-calculator',
        'profit' => '/profit-calculator',
        'margin' => '/margin-calculator',
        'currency-converter' => '/currency-converter',
        'compounding' => '/compounding-calculator',
        'fibonacci' => '/fibonacci-calculator',
        'pivot' => '/pivot-calculator',
        'drawdown' => '/drawdown-calculator',
        'risk-of-ruin' => '/risk-of-ruin-calculator',
        'crypto-fees' => '/crypto-fees-calculator'
    ];

    // Validate calculator type
    if (!isset($calculators[$atts['type']])) {
        return '<p style="color: red;">Invalid calculator type. Available types: ' . implode(', ', array_keys($calculators)) . '</p>';
    }

    // Build iframe URL
    $iframe_url = $atts['domain'] . $calculators[$atts['type']];
    
    // Calculator names for title
    $calculator_names = [
        'position-size' => 'Position Size Calculator',
        'pip' => 'Pip Calculator',
        'profit' => 'Profit Calculator',
        'margin' => 'Margin Calculator',
        'currency-converter' => 'Currency Converter',
        'compounding' => 'Compounding Calculator',
        'fibonacci' => 'Fibonacci Calculator',
        'pivot' => 'Pivot Calculator',
        'drawdown' => 'Drawdown Calculator',
        'risk-of-ruin' => 'Risk of Ruin Calculator',
        'crypto-fees' => 'Crypto Fees Calculator'
    ];

    // Generate iframe HTML
    $iframe_html = sprintf(
        '<div class="forex-calculator-wrapper" style="max-width: 900px; margin: 20px auto;">
            <iframe 
                src="%s" 
                width="%s" 
                height="%s" 
                frameborder="0" 
                scrolling="auto"
                style="border: 1px solid #e0e0e0; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); width: 100%%; max-width: 100%%;"
                title="%s">
            </iframe>
        </div>',
        esc_url($iframe_url),
        esc_attr($atts['width']),
        esc_attr($atts['height']),
        esc_attr($calculator_names[$atts['type']])
    );

    return $iframe_html;
}

// Register shortcode
add_shortcode('forex_calculator', 'forex_calculator_shortcode');

// Add CSS for responsiveness
function forex_calculator_styles() {
    echo '<style>
        @media (max-width: 768px) {
            .forex-calculator-wrapper iframe {
                height: 500px !important;
            }
        }
        @media (max-width: 480px) {
            .forex-calculator-wrapper iframe {
                height: 450px !important;
            }
        }
    </style>';
}
add_action('wp_head', 'forex_calculator_styles');
?>
```

2. **Activate Plugin**
   - Go to `Plugins` → `Installed Plugins`
   - Find "Forex Calculator Embed"
   - Click `Activate`

### Using Shortcodes
After activating the plugin, you can use these shortcodes:

```
[forex_calculator type="position-size"]
[forex_calculator type="pip" height="500"]
[forex_calculator type="profit" height="650"]
[forex_calculator type="margin"]
[forex_calculator type="currency-converter"]
```

**Available Types:**
- `position-size`
- `pip`
- `profit`
- `margin`
- `currency-converter`
- `compounding`
- `fibonacci`
- `pivot`
- `drawdown`
- `risk-of-ruin`
- `crypto-fees`

## 📱 Mobile Optimization Tips

### Responsive Height Adjustments
```css
/* Desktop */
.forex-calculator-iframe {
    height: 600px;
}

/* Tablet */
@media (max-width: 1024px) {
    .forex-calculator-iframe {
        height: 550px;
    }
}

/* Mobile */
@media (max-width: 768px) {
    .forex-calculator-iframe {
        height: 500px;
    }
}

/* Small Mobile */
@media (max-width: 480px) {
    .forex-calculator-iframe {
        height: 450px;
    }
}
```

### Touch-Friendly Design
```css
.forex-calculator-iframe {
    -webkit-overflow-scrolling: touch; /* Smooth scrolling on iOS */
    overflow: auto;
}
```

## 💰 Monetization Integration

### Adding Ads Around Calculators
```html
<!-- Advertisement Above Calculator -->
<div style="text-align: center; margin: 20px 0;">
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <ins class="adsbygoogle"
         style="display:block"
         data-ad-client="ca-pub-XXXXXXXXXX"
         data-ad-slot="1234567890"
         data-ad-format="horizontal"></ins>
    <script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
</div>

<!-- Your Calculator Iframe -->
<iframe src="https://your-domain.com/position-size-calculator" ...></iframe>

<!-- Advertisement Below Calculator -->
<div style="text-align: center; margin: 20px 0;">
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <ins class="adsbygoogle"
         style="display:block"
         data-ad-client="ca-pub-XXXXXXXXXX"
         data-ad-slot="0987654321"
         data-ad-format="rectangle"></ins>
    <script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
</div>
```

### Affiliate Links Integration
```html
<div style="background: #f8f9fa; padding: 20px; margin: 20px 0; border-radius: 8px; text-align: center;">
    <h3>Start Trading with Recommended Brokers</h3>
    <p>Use these calculators with top-rated forex brokers:</p>
    <a href="https://your-affiliate-link-etoro" style="background: #17a2b8; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;">eToro</a>
    <a href="https://your-affiliate-link-xm" style="background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;">XM</a>
    <a href="https://your-affiliate-link-fxtm" style="background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;">FXTM</a>
</div>
```

## 🔒 Security Best Practices

### CSP Headers (Content Security Policy)
If you face loading issues, add this to your site's `.htaccess`:
```
Header always set Content-Security-Policy "frame-ancestors 'self' https://your-wordpress-domain.com;"
```

### HTTPS Requirements
- Ensure your calculator domain uses HTTPS
- WordPress site should also use HTTPS
- Mixed content (HTTP iframe on HTTPS site) will be blocked

## ⚡ Performance Optimization

### Lazy Loading
```html
<iframe 
  src="https://your-domain.com/position-size-calculator" 
  loading="lazy"
  width="100%" 
  height="600">
</iframe>
```

### Preload Important Calculators
Add to your theme's `functions.php`:
```php
function preload_calculator_resources() {
    echo '<link rel="preload" href="https://your-domain.com/position-size-calculator" as="document">';
}
add_action('wp_head', 'preload_calculator_resources');
```

## 🎯 SEO Optimization

### Adding Context Around Calculators
```html
<div class="calculator-introduction">
    <h2>Position Size Calculator - Free Forex Tool</h2>
    <p>Calculate the optimal position size for your forex trades based on your account balance, risk tolerance, and stop loss. This professional-grade calculator helps traders manage risk effectively.</p>
</div>

<!-- Your Calculator Iframe Here -->

<div class="calculator-explanation">
    <h3>How to Use the Position Size Calculator</h3>
    <ol>
        <li>Enter your account balance</li>
        <li>Set your risk percentage (typically 1-3%)</li>
        <li>Input your stop loss in pips</li>
        <li>Select your currency pair</li>
        <li>Click calculate to get your optimal position size</li>
    </ol>
</div>
```

## 🐛 Troubleshooting Common Issues

### Calculator Not Loading
1. **Check HTTPS:** Both sites must use HTTPS
2. **Domain Issues:** Verify your calculator domain is accessible
3. **X-Frame-Options:** Your server might block embedding

### Mobile Display Issues
1. **Add viewport meta tag:**
   ```html
   <meta name="viewport" content="width=device-width, initial-scale=1">
   ```

2. **Use responsive CSS:**
   ```css
   iframe {
       max-width: 100%;
       height: auto;
   }
   ```

### AdBlock Issues
Some users might have adblockers that block iframes. Add this notice:
```html
<noscript>
    <div style="background: #fff3cd; padding: 15px; margin: 15px 0; border-radius: 5px;">
        <strong>Note:</strong> If you don't see the calculator above, please disable your ad blocker for this page.
    </div>
</noscript>
```

## 📊 Analytics Tracking

### Track Iframe Interactions
Add this to your WordPress site:
```html
<script>
window.addEventListener('message', function(e) {
    if (e.origin === 'https://your-domain.com') {
        // Track calculator usage with Google Analytics
        gtag('event', 'calculator_interaction', {
            'event_category': 'forex_tools',
            'event_label': 'position_size_calculator'
        });
    }
});
</script>
```

This comprehensive guide covers everything you need to successfully embed your forex calculators into WordPress and start monetizing your content!