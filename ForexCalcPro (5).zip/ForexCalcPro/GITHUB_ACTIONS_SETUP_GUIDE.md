# GitHub Actions Setup Guide - Detailed Build Configuration

## 🔧 **Step 3.2: Set Up Build Action (Detailed Instructions)**

### **What is GitHub Actions?**
GitHub Actions automatically builds and deploys your forex calculator platform whenever you make changes. It's like having a personal assistant that updates your website automatically.

### **Step-by-Step Build Action Setup**

#### **Option A: Using GitHub Web Interface (Easiest)**

**Step 1: Create the Workflow Folder Structure**
1. **In your repository**, click **"Add file"** → **"Create new file"**
2. **Type this path**: `.github/workflows/deploy.yml`
   - GitHub will automatically create the folders
   - The dot (.) at the beginning is important - don't skip it

**Step 2: Copy the Workflow Configuration**
3. **Paste this exact code** into the `deploy.yml` file:

```yaml
name: Build and Deploy Forex Calculator to GitHub Pages

on:
  push:
    branches: [ main, master ]
  pull_request:
    branches: [ main, master ]
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write

concurrency:
  group: "pages"
  cancel-in-progress: false

jobs:
  build:
    runs-on: ubuntu-latest
    
    steps:
    - name: Checkout repository
      uses: actions/checkout@v4
      
    - name: Setup Node.js
      uses: actions/setup-node@v4
      with:
        node-version: '18'
        cache: 'npm'
        
    - name: Install dependencies
      run: npm ci
      
    - name: Build project for GitHub Pages
      run: |
        npm run build
        mkdir -p docs
        cp -r dist/public/* docs/
        touch docs/.nojekyll
        
    - name: Setup Pages
      uses: actions/configure-pages@v4
      
    - name: Upload artifact
      uses: actions/upload-pages-artifact@v3
      with:
        path: docs

  deploy:
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    runs-on: ubuntu-latest
    needs: build
    
    steps:
    - name: Deploy to GitHub Pages
      id: deployment
      uses: actions/deploy-pages@v4
```

**Step 3: Commit the Workflow**
4. **Scroll down** to "Commit changes" section
5. **Commit message**: `Add GitHub Actions workflow for automated deployment`
6. **Description**: `Automatically builds and deploys forex calculators to GitHub Pages`
7. **Click "Commit changes"**

#### **Option B: Upload as File (Alternative Method)**

**If you prefer to upload the file:**
1. **Create the file** on your computer: `deploy.yml`
2. **Copy the code** from above into the file
3. **In GitHub repository**, navigate to create folder: `.github/workflows/`
4. **Upload the file** `deploy.yml` into this folder

### **Step 3.3: Configure Repository Settings**

**Enable GitHub Pages with Actions:**
1. **Go to repository Settings** (not your account settings)
2. **Scroll down to "Pages"** in the left sidebar
3. **Source**: Select **"GitHub Actions"** (not "Deploy from branch")
4. **Save the settings**

### **Step 3.4: Trigger the First Build**

**Manual Trigger:**
1. **Go to "Actions" tab** in your repository
2. **Click "Build and Deploy Forex Calculator to GitHub Pages"**
3. **Click "Run workflow"** dropdown
4. **Click "Run workflow"** button
5. **Wait 3-5 minutes** for the build to complete

**Or Push a Change:**
1. **Edit any file** in your repository (like README.md)
2. **Add a small change** like "Updated for GitHub Pages"
3. **Commit the change**
4. **The workflow runs automatically**

### **Step 3.5: Monitor the Build Process**

**Watch Your Build:**
1. **Click "Actions" tab** to see all workflows
2. **Click the running workflow** to see detailed progress
3. **Each step shows**:
   - ✅ Green checkmark = Success
   - ❌ Red X = Error (check logs)
   - 🟡 Yellow circle = Running

**Build Steps Explained:**
- **Checkout**: Downloads your code
- **Setup Node.js**: Installs Node.js version 18
- **Install dependencies**: Runs `npm ci` to install packages
- **Build project**: Creates the production build
- **Upload artifact**: Prepares files for deployment
- **Deploy**: Publishes to GitHub Pages

### **Step 3.6: Verify Deployment**

**After Successful Build:**
1. **Go back to Settings** → **Pages**
2. **You'll see**: "Your site is published at https://username.github.io/forex-calculator-platform"
3. **Click the URL** to visit your live site
4. **Test all calculators** to ensure they work

## 🚨 **Troubleshooting Build Issues**

### **Common Build Failures and Fixes:**

#### **Error: "npm ci can't find package.json"**
**Fix:**
1. **Ensure `package.json`** exists in repository root
2. **Replace with `github-package.json`** I provided
3. **Commit the changes**

#### **Error: "Build command failed"**
**Fix:**
1. **Check your `package.json`** has correct build script:
   ```json
   "scripts": {
     "build": "vite build --outDir=dist/public"
   }
   ```
2. **Ensure all dependencies** are listed in `package.json`

#### **Error: "Permission denied"**
**Fix:**
1. **Go to Settings** → **Actions** → **General**
2. **Workflow permissions**: Select **"Read and write permissions"**
3. **Save changes** and re-run workflow

#### **Error: "Pages deployment failed"**
**Fix:**
1. **Check Settings** → **Pages** source is set to **"GitHub Actions"**
2. **Ensure repository is public** (required for free GitHub Pages)
3. **Re-run the workflow**

### **Advanced Configuration Options**

#### **Custom Domain Setup**
If you have your own domain, add this to the workflow:

```yaml
- name: Create CNAME file
  run: echo "yourdomain.com" > docs/CNAME
```

#### **Environment Variables**
Add secrets for Google AdSense:

1. **Go to Settings** → **Secrets and variables** → **Actions**
2. **Click "New repository secret"**
3. **Name**: `VITE_GOOGLE_ADSENSE_CLIENT`
4. **Value**: `ca-pub-XXXXXXXXXX`

Then update the workflow:
```yaml
- name: Build project with environment variables
  env:
    VITE_GOOGLE_ADSENSE_CLIENT: ${{ secrets.VITE_GOOGLE_ADSENSE_CLIENT }}
  run: |
    npm run build
    mkdir -p docs
    cp -r dist/public/* docs/
    touch docs/.nojekyll
```

#### **Build Caching for Faster Deployments**
The workflow already includes `cache: 'npm'` which speeds up builds by caching dependencies.

## 📊 **Expected Build Timeline**

**Typical Build Process:**
- **Checkout**: 10-15 seconds
- **Setup Node.js**: 15-20 seconds  
- **Install dependencies**: 30-60 seconds (first time), 10-15 seconds (cached)
- **Build project**: 60-120 seconds
- **Deploy**: 30-45 seconds
- **Total**: 3-5 minutes

## ✅ **Success Indicators**

**Your build is successful when:**
1. **All workflow steps** show green checkmarks
2. **Settings → Pages** shows: "Your site is published at..."
3. **Your URL loads** the forex calculator homepage
4. **All calculators work** when tested
5. **HTTPS certificate** is automatically active

## 🔄 **Automatic Updates**

**After initial setup:**
- **Every code change** you push triggers a new build
- **Builds take 3-5 minutes** to complete
- **Your site updates automatically** with zero downtime
- **No manual intervention** required

## 💡 **Pro Tips**

1. **Check Actions tab regularly** to monitor builds
2. **Fix failed builds immediately** to prevent deployment issues
3. **Use "workflow_dispatch"** to manually trigger builds
4. **Monitor build times** - consistently slow builds indicate optimization needs
5. **Keep dependencies updated** for security and performance

Your GitHub Actions workflow is now configured for professional automated deployment of your forex calculator platform!

## 🎯 **Next Steps After Setup**

1. **Test your live site** at the GitHub Pages URL
2. **Update WordPress iframe URLs** to point to GitHub Pages
3. **Configure Google AdSense** with your new domain
4. **Set up Google Analytics** for traffic monitoring
5. **Consider custom domain** for professional branding

Your forex calculators are now automatically deployed with professional CI/CD pipeline!