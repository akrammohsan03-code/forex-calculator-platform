# GitHub Pages Troubleshooting Guide

## 🚨 **URL Not Working? Common Fixes**

### **Issue: `akrammohsan03-code.github.io` not loading**

**Possible Causes & Solutions:**

### **1. Repository Name Mismatch**
**Problem**: GitHub Pages URL doesn't match repository name
**Check**: Your repository name should match the URL path

**If your URL is**: `akrammohsan03-code.github.io/REPO-NAME`
**Then repository should be named**: `REPO-NAME`

**Quick Fix**:
1. Go to repository **Settings**
2. Scroll down to **"Repository name"** 
3. Rename to match what comes after `.github.io/`
4. Or use the format: `username.github.io` for main site

### **2. GitHub Pages Not Enabled**
**Check Settings**:
1. Go to repository **Settings** → **Pages**
2. **Source** should be **"GitHub Actions"** or **"Deploy from branch"**
3. If using branch: **Branch** should be **"main"** and **folder** should be **"/ (root)"**

### **3. Build Failed**
**Check Build Status**:
1. Go to **Actions** tab in repository
2. Look for ❌ (failed) or ✅ (success) status
3. Click failed build to see error logs

**Common Build Fixes**:
- Ensure `package.json` exists with correct `build` script
- Check all dependencies are listed
- Verify Node.js version compatibility

### **4. Wrong File Structure**
**For GitHub Actions deployment**, ensure:
```
repository/
├── .github/
│   └── workflows/
│       └── deploy.yml
├── package.json
├── src/ (or client/src/)
└── other project files
```

**For Branch deployment**, ensure built files are in:
- Root folder (/)
- OR docs/ folder
- OR gh-pages branch

### **5. DNS Propagation (Custom Domain)**
**If using custom domain**:
- DNS changes take 24-48 hours
- Check if CNAME file exists in repository
- Verify DNS records at domain registrar

## 🔧 **Quick Diagnostic Steps**

### **Step 1: Verify Repository Setup**
1. **Repository name**: Should match desired URL
2. **Visibility**: Must be **Public** for free GitHub Pages
3. **Files**: All project files uploaded correctly

### **Step 2: Check Pages Configuration**
1. **Settings** → **Pages**
2. **Source**: Verify correct deployment method
3. **Custom domain**: Remove if causing issues

### **Step 3: Monitor Build Process**
1. **Actions** tab → Latest workflow run
2. **All steps green**: Build successful
3. **Any red X**: Click to see error details

### **Step 4: Test Alternative URLs**
Try these URL formats:
- `https://akrammohsan03-code.github.io/`
- `https://akrammohsan03-code.github.io/repository-name/`
- `https://akrammohsan03-code.github.io/index.html`

## 🚀 **Quick Fix Solutions**

### **Solution A: Rename Repository**
1. **Settings** → **Repository name**
2. **Rename to**: `forex-calculators` or `akrammohsan03-code.github.io`
3. **Wait 5-10 minutes** for GitHub to update

### **Solution B: Re-enable Pages**
1. **Settings** → **Pages**
2. **Source**: **None** (save)
3. **Source**: **GitHub Actions** (save again)
4. **Wait for rebuild**

### **Solution C: Manual Branch Deployment**
If GitHub Actions fails:
1. **Build locally** or download built files
2. **Create `gh-pages` branch**
3. **Upload built files** to gh-pages branch
4. **Settings** → **Pages** → **Source**: **Deploy from branch** → **gh-pages**

### **Solution D: Use Repository as Subdirectory**
1. **Repository name**: `forex-calculators`
2. **URL becomes**: `akrammohsan03-code.github.io/forex-calculators/`
3. **Update base URL** in Vite config:
   ```typescript
   export default defineConfig({
     base: '/forex-calculators/',
     // ... other config
   })
   ```

## 📝 **Immediate Action Plan**

**For `akrammohsan03-code.github.io` specifically:**

### **Option 1: Main User Site**
1. **Rename repository** to: `akrammohsan03-code.github.io`
2. **URL becomes**: `https://akrammohsan03-code.github.io/`
3. **No subdirectory needed**

### **Option 2: Project Site**
1. **Keep current repository name**
2. **URL**: `https://akrammohsan03-code.github.io/REPOSITORY-NAME/`
3. **Update config** for subdirectory base

### **Option 3: Simple Static Deployment**
1. **Run build command**: `npm run build`
2. **Upload built files** to `docs/` folder
3. **Pages source**: Deploy from branch → main → /docs

## 🔍 **Debug Checklist**

**Check these items:**
- ✅ Repository is public
- ✅ GitHub Pages enabled in settings
- ✅ Build process completed successfully
- ✅ Correct file structure
- ✅ Package.json has build script
- ✅ No CNAME conflicts
- ✅ Waiting adequate time for propagation (10-15 minutes)

## 💡 **Most Common Fix**

**Repository Name Issue**:
- If you want `akrammohsan03-code.github.io` to work
- Repository MUST be named exactly: `akrammohsan03-code.github.io`
- Otherwise, use format: `username.github.io/repository-name/`

## 🆘 **Emergency Backup Plan**

**If GitHub Pages still fails:**
1. **Use Netlify**: Drag and drop built files
2. **Use Vercel**: Connect GitHub repository
3. **Use Surge.sh**: Simple command-line deployment
4. **All provide free hosting** similar to GitHub Pages

Your forex calculator site should be working within 15 minutes of applying the correct fix!