<?php
/*
Plugin Name: Forex Calculator Pro
Description: Professional forex trading calculators with position size, pip value, profit/loss, and margin calculations
Version: 1.0.0
Author: ForexCalculatorPro
*/

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class ForexCalculatorPro {
    
    public function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_shortcode('forex_calculator', array($this, 'calculator_shortcode'));
        add_shortcode('forex_position_size', array($this, 'position_size_calculator'));
        add_shortcode('forex_pip_calculator', array($this, 'pip_calculator'));
        add_shortcode('forex_profit_calculator', array($this, 'profit_calculator'));
        add_shortcode('forex_margin_calculator', array($this, 'margin_calculator'));
        add_shortcode('forex_currency_converter', array($this, 'currency_converter'));
        
        // Add admin menu
        add_action('admin_menu', array($this, 'admin_menu'));
    }
    
    public function enqueue_scripts() {
        wp_enqueue_script('forex-calculator-js', plugin_dir_url(__FILE__) . 'assets/script.js', array('jquery'), '1.0.0', true);
        wp_enqueue_style('forex-calculator-css', plugin_dir_url(__FILE__) . 'assets/style.css', array(), '1.0.0');
        
        // Localize script for AJAX
        wp_localize_script('forex-calculator-js', 'forex_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('forex_calculator_nonce')
        ));
    }
    
    public function calculator_shortcode($atts) {
        $atts = shortcode_atts(array(
            'type' => 'position-size',
            'currency' => 'USD',
            'style' => 'default'
        ), $atts);
        
        switch($atts['type']) {
            case 'position-size':
                return $this->render_position_size_calculator($atts);
            case 'pip':
                return $this->render_pip_calculator($atts);
            case 'profit':
                return $this->render_profit_calculator($atts);
            case 'margin':
                return $this->render_margin_calculator($atts);
            case 'currency-converter':
                return $this->render_currency_converter($atts);
            default:
                return $this->render_position_size_calculator($atts);
        }
    }
    
    private function render_position_size_calculator($atts) {
        ob_start();
        ?>
        <div class="forex-calculator-container position-size-calculator">
            <div class="calculator-header">
                <h3>Position Size Calculator</h3>
                <p>Calculate the optimal position size based on your risk management strategy</p>
            </div>
            
            <div class="calculator-form">
                <div class="form-row">
                    <div class="form-group">
                        <label for="account-balance">Account Balance</label>
                        <input type="number" id="account-balance" placeholder="10000" step="0.01">
                        <select id="account-currency">
                            <option value="USD">USD</option>
                            <option value="EUR">EUR</option>
                            <option value="GBP">GBP</option>
                            <option value="JPY">JPY</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="risk-percentage">Risk Percentage (%)</label>
                        <input type="number" id="risk-percentage" placeholder="2" step="0.1" max="10">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="currency-pair">Currency Pair</label>
                        <select id="currency-pair">
                            <option value="EURUSD">EUR/USD</option>
                            <option value="GBPUSD">GBP/USD</option>
                            <option value="USDJPY">USD/JPY</option>
                            <option value="USDCHF">USD/CHF</option>
                            <option value="AUDUSD">AUD/USD</option>
                            <option value="USDCAD">USD/CAD</option>
                            <option value="NZDUSD">NZD/USD</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="stop-loss-pips">Stop Loss (Pips)</label>
                        <input type="number" id="stop-loss-pips" placeholder="50" step="1">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="entry-price">Entry Price</label>
                        <input type="number" id="entry-price" placeholder="1.1000" step="0.0001">
                    </div>
                </div>
                
                <button class="calculate-btn" onclick="calculatePositionSize()">Calculate Position Size</button>
            </div>
            
            <div class="results-container" id="position-size-results" style="display: none;">
                <h4>Calculation Results</h4>
                <div class="results-grid">
                    <div class="result-item">
                        <span class="result-label">Lot Size:</span>
                        <span class="result-value" id="lot-size">0.00</span>
                    </div>
                    <div class="result-item">
                        <span class="result-label">Units:</span>
                        <span class="result-value" id="units">0</span>
                    </div>
                    <div class="result-item">
                        <span class="result-label">Money at Risk:</span>
                        <span class="result-value" id="money-at-risk">$0.00</span>
                    </div>
                    <div class="result-item">
                        <span class="result-label">Pip Value:</span>
                        <span class="result-value" id="pip-value">$0.00</span>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- AdSense Ad Space -->
        <div class="adsense-container">
            <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
            <ins class="adsbygoogle"
                 style="display:block"
                 data-ad-client="ca-pub-XXXXXXXXXX"
                 data-ad-slot="1234567890"
                 data-ad-format="auto"></ins>
            <script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
        </div>
        <?php
        return ob_get_clean();
    }
    
    private function render_pip_calculator($atts) {
        ob_start();
        ?>
        <div class="forex-calculator-container pip-calculator">
            <div class="calculator-header">
                <h3>Pip Calculator</h3>
                <p>Calculate pip values for different currency pairs and position sizes</p>
            </div>
            
            <div class="calculator-form">
                <div class="form-row">
                    <div class="form-group">
                        <label for="pip-currency-pair">Currency Pair</label>
                        <select id="pip-currency-pair">
                            <option value="EURUSD">EUR/USD</option>
                            <option value="GBPUSD">GBP/USD</option>
                            <option value="USDJPY">USD/JPY</option>
                            <option value="USDCHF">USD/CHF</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="pip-lot-size">Lot Size</label>
                        <input type="number" id="pip-lot-size" placeholder="1.0" step="0.01">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="pip-account-currency">Account Currency</label>
                        <select id="pip-account-currency">
                            <option value="USD">USD</option>
                            <option value="EUR">EUR</option>
                            <option value="GBP">GBP</option>
                        </select>
                    </div>
                </div>
                
                <button class="calculate-btn" onclick="calculatePipValue()">Calculate Pip Value</button>
            </div>
            
            <div class="results-container" id="pip-results" style="display: none;">
                <h4>Pip Value Results</h4>
                <div class="result-item large">
                    <span class="result-label">Pip Value:</span>
                    <span class="result-value" id="pip-result-value">$0.00</span>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    private function render_profit_calculator($atts) {
        ob_start();
        ?>
        <div class="forex-calculator-container profit-calculator">
            <div class="calculator-header">
                <h3>Profit/Loss Calculator</h3>
                <p>Calculate potential profit or loss for your forex trades</p>
            </div>
            
            <div class="calculator-form">
                <div class="form-row">
                    <div class="form-group">
                        <label for="profit-currency-pair">Currency Pair</label>
                        <select id="profit-currency-pair">
                            <option value="EURUSD">EUR/USD</option>
                            <option value="GBPUSD">GBP/USD</option>
                            <option value="USDJPY">USD/JPY</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="trade-type">Trade Type</label>
                        <select id="trade-type">
                            <option value="buy">Buy</option>
                            <option value="sell">Sell</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="lot-size-profit">Lot Size</label>
                        <input type="number" id="lot-size-profit" placeholder="1.0" step="0.01">
                    </div>
                    
                    <div class="form-group">
                        <label for="open-price">Open Price</label>
                        <input type="number" id="open-price" placeholder="1.1000" step="0.0001">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="close-price">Close Price</label>
                        <input type="number" id="close-price" placeholder="1.1050" step="0.0001">
                    </div>
                </div>
                
                <button class="calculate-btn" onclick="calculateProfit()">Calculate Profit/Loss</button>
            </div>
            
            <div class="results-container" id="profit-results" style="display: none;">
                <h4>Profit/Loss Results</h4>
                <div class="results-grid">
                    <div class="result-item">
                        <span class="result-label">Pips:</span>
                        <span class="result-value" id="profit-pips">0</span>
                    </div>
                    <div class="result-item">
                        <span class="result-label">Profit/Loss:</span>
                        <span class="result-value" id="profit-amount">$0.00</span>
                    </div>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    private function render_margin_calculator($atts) {
        ob_start();
        ?>
        <div class="forex-calculator-container margin-calculator">
            <div class="calculator-header">
                <h3>Margin Calculator</h3>
                <p>Calculate required margin for your forex positions</p>
            </div>
            
            <div class="calculator-form">
                <div class="form-row">
                    <div class="form-group">
                        <label for="margin-currency-pair">Currency Pair</label>
                        <select id="margin-currency-pair">
                            <option value="EURUSD">EUR/USD</option>
                            <option value="GBPUSD">GBP/USD</option>
                            <option value="USDJPY">USD/JPY</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="margin-lot-size">Lot Size</label>
                        <input type="number" id="margin-lot-size" placeholder="1.0" step="0.01">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="leverage">Leverage</label>
                        <select id="leverage">
                            <option value="50">1:50</option>
                            <option value="100">1:100</option>
                            <option value="200">1:200</option>
                            <option value="500">1:500</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="margin-account-currency">Account Currency</label>
                        <select id="margin-account-currency">
                            <option value="USD">USD</option>
                            <option value="EUR">EUR</option>
                            <option value="GBP">GBP</option>
                        </select>
                    </div>
                </div>
                
                <button class="calculate-btn" onclick="calculateMargin()">Calculate Margin</button>
            </div>
            
            <div class="results-container" id="margin-results" style="display: none;">
                <h4>Margin Requirements</h4>
                <div class="result-item large">
                    <span class="result-label">Required Margin:</span>
                    <span class="result-value" id="required-margin">$0.00</span>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    private function render_currency_converter($atts) {
        ob_start();
        ?>
        <div class="forex-calculator-container currency-converter">
            <div class="calculator-header">
                <h3>Currency Converter</h3>
                <p>Convert between different currencies with real-time rates</p>
            </div>
            
            <div class="calculator-form">
                <div class="form-row">
                    <div class="form-group">
                        <label for="from-currency">From</label>
                        <select id="from-currency">
                            <option value="USD">USD - US Dollar</option>
                            <option value="EUR">EUR - Euro</option>
                            <option value="GBP">GBP - British Pound</option>
                            <option value="JPY">JPY - Japanese Yen</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="to-currency">To</label>
                        <select id="to-currency">
                            <option value="EUR">EUR - Euro</option>
                            <option value="USD">USD - US Dollar</option>
                            <option value="GBP">GBP - British Pound</option>
                            <option value="JPY">JPY - Japanese Yen</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="amount">Amount</label>
                        <input type="number" id="amount" placeholder="1000" step="0.01">
                    </div>
                </div>
                
                <button class="calculate-btn" onclick="convertCurrency()">Convert Currency</button>
            </div>
            
            <div class="results-container" id="converter-results" style="display: none;">
                <h4>Conversion Result</h4>
                <div class="result-item large">
                    <span class="result-label">Converted Amount:</span>
                    <span class="result-value" id="converted-amount">0.00</span>
                </div>
                <div class="result-item">
                    <span class="result-label">Exchange Rate:</span>
                    <span class="result-value" id="exchange-rate">1.0000</span>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    // Shortcode methods for individual calculators
    public function position_size_calculator($atts) {
        return $this->render_position_size_calculator($atts);
    }
    
    public function pip_calculator($atts) {
        return $this->render_pip_calculator($atts);
    }
    
    public function profit_calculator($atts) {
        return $this->render_profit_calculator($atts);
    }
    
    public function margin_calculator($atts) {
        return $this->render_margin_calculator($atts);
    }
    
    public function currency_converter($atts) {
        return $this->render_currency_converter($atts);
    }
    
    // Admin menu
    public function admin_menu() {
        add_options_page(
            'Forex Calculator Settings',
            'Forex Calculator',
            'manage_options',
            'forex-calculator-settings',
            array($this, 'admin_page')
        );
    }
    
    public function admin_page() {
        ?>
        <div class="wrap">
            <h1>Forex Calculator Pro Settings</h1>
            
            <h2>Available Shortcodes</h2>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Calculator</th>
                        <th>Shortcode</th>
                        <th>Description</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Position Size Calculator</td>
                        <td><code>[forex_position_size]</code></td>
                        <td>Calculate optimal position size based on risk</td>
                    </tr>
                    <tr>
                        <td>Pip Calculator</td>
                        <td><code>[forex_pip_calculator]</code></td>
                        <td>Calculate pip values for different pairs</td>
                    </tr>
                    <tr>
                        <td>Profit/Loss Calculator</td>
                        <td><code>[forex_profit_calculator]</code></td>
                        <td>Calculate potential profit or loss</td>
                    </tr>
                    <tr>
                        <td>Margin Calculator</td>
                        <td><code>[forex_margin_calculator]</code></td>
                        <td>Calculate required margin</td>
                    </tr>
                    <tr>
                        <td>Currency Converter</td>
                        <td><code>[forex_currency_converter]</code></td>
                        <td>Convert between currencies</td>
                    </tr>
                </tbody>
            </table>
            
            <h2>Usage Examples</h2>
            <p><strong>Basic usage:</strong> <code>[forex_position_size]</code></p>
            <p><strong>With parameters:</strong> <code>[forex_calculator type="pip" currency="EUR"]</code></p>
            
            <h2>Monetization</h2>
            <p>Add your Google AdSense publisher ID in the plugin file to display ads with calculators.</p>
        </div>
        <?php
    }
}

// Initialize the plugin
new ForexCalculatorPro();

// AJAX handlers for calculations
add_action('wp_ajax_calculate_position_size', 'handle_position_size_calculation');
add_action('wp_ajax_nopriv_calculate_position_size', 'handle_position_size_calculation');

function handle_position_size_calculation() {
    check_ajax_referer('forex_calculator_nonce', 'nonce');
    
    $account_balance = floatval($_POST['account_balance']);
    $risk_percentage = floatval($_POST['risk_percentage']);
    $stop_loss_pips = floatval($_POST['stop_loss_pips']);
    $currency_pair = sanitize_text_field($_POST['currency_pair']);
    
    // Get current exchange rate (simplified)
    $exchange_rate = get_exchange_rate($currency_pair);
    
    // Calculate position size
    $risk_amount = ($account_balance * $risk_percentage) / 100;
    $pip_value = calculate_pip_value($currency_pair, 1.0); // 1 lot
    $lot_size = $risk_amount / ($stop_loss_pips * $pip_value);
    $units = $lot_size * 100000; // Standard lot = 100,000 units
    
    wp_send_json_success(array(
        'lot_size' => round($lot_size, 2),
        'units' => round($units),
        'money_at_risk' => round($risk_amount, 2),
        'pip_value' => round($pip_value, 2)
    ));
}

function get_exchange_rate($pair) {
    // In production, integrate with real forex API
    $rates = array(
        'EURUSD' => 1.0850,
        'GBPUSD' => 1.2650,
        'USDJPY' => 149.50,
        'USDCHF' => 0.9050
    );
    
    return isset($rates[$pair]) ? $rates[$pair] : 1.0;
}

function calculate_pip_value($pair, $lot_size) {
    // Simplified pip value calculation
    $pip_values = array(
        'EURUSD' => 10,
        'GBPUSD' => 10,
        'USDJPY' => 6.69,
        'USDCHF' => 11.05
    );
    
    return isset($pip_values[$pair]) ? $pip_values[$pair] * $lot_size : 10 * $lot_size;
}
?>