# ForexCalculatorPro WordPress Integration

## How to Add Your Forex Calculators to WordPress

### Method 1: WordPress Plugin (Recommended)

#### Step 1: Install the Plugin
1. Download the `forex-calculators-plugin.php` file
2. Create a folder called `forex-calculators` in your WordPress `/wp-content/plugins/` directory
3. Upload these files to the folder:
   - `forex-calculators-plugin.php`
   - `assets/style.css`
   - `assets/script.js`

#### Step 2: Activate the Plugin
1. Go to WordPress Admin → Plugins
2. Find "ForexCalculatorPro" 
3. Click "Activate"

#### Step 3: Use Shortcodes in Your Posts/Pages

Add these shortcodes anywhere in your WordPress content:

```
[forex_position_calculator title="Position Size Calculator"]

[forex_pip_calculator title="Pip Value Calculator"]

[forex_profit_calculator title="Profit/Loss Calculator"]

[forex_margin_calculator title="Margin Calculator"]

[forex_currency_converter title="Currency Converter"]
```

### Method 2: Embed as iFrame

If you have your website hosted elsewhere, embed it in WordPress:

```html
<iframe 
    src="https://your-domain.com" 
    width="100%" 
    height="800px" 
    frameborder="0">
</iframe>
```

### Method 3: WordPress Gutenberg Blocks

Create custom Gutenberg blocks for each calculator:

1. **Add Custom HTML Block**
2. **Paste Calculator HTML** from your React components
3. **Add CSS via Customizer** → Additional CSS

### Method 4: Theme Integration

Add calculators directly to your theme:

1. **Edit theme files** (functions.php, single.php, page.php)
2. **Include calculator PHP code**
3. **Enqueue styles and scripts**

### Available Calculator Features:

✅ **Position Size Calculator**
- Account balance input
- Risk percentage setting
- Stop loss in pips
- Automatic lot size calculation

✅ **Pip Calculator**
- All major currency pairs
- Multiple lot sizes (micro, mini, standard)
- Account currency selection
- Live exchange rates

✅ **Profit Calculator** 
- Entry and exit price inputs
- Long/short position options
- Pip difference calculation
- Profit/loss in USD

✅ **Margin Calculator**
- Required margin calculation
- Leverage settings
- Position size inputs

✅ **Currency Converter**
- Real-time exchange rates
- Multiple currency pairs
- Amount conversion

### Styling Options:

**Professional Theme**: Navy blue (#1e3a8a) and gold (#d97706) color scheme
**Responsive Design**: Works on all devices
**Clean UI**: Modern card-based layout
**Animations**: Smooth transitions and loading states

### Contact Information:

Your WordPress calculators will display:
- **Email**: akrammohsan03@gmail.com  
- **Address**: Lahore Johar Town J2 Street No 11 House 456

### Installation Support:

1. **Plugin Method**: Upload plugin files and activate
2. **Shortcode Usage**: Copy shortcodes into posts/pages  
3. **Customization**: Modify CSS for your theme colors
4. **Mobile Optimization**: Automatic responsive design

Your professional forex calculators are now ready for WordPress integration with full functionality!