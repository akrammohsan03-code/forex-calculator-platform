# Complete Project Transfer Guide

## 📁 How to Download Your Forex Calculator Project

### Method 1: Download from Replit (Easiest)
1. **In your Replit project**, click the **3 dots menu** (⋮) next to your project name
2. Select **"Download as ZIP"**
3. Your entire project downloads as a ZIP file
4. Extract the ZIP file on your computer

### Method 2: Manual File Copy
If download doesn't work, copy these key files:

**Essential Files to Copy:**
```
📁 Your Project Files
├── client/
│   ├── src/
│   │   ├── components/ (all calculator components)
│   │   ├── pages/ (all calculator pages)
│   │   ├── lib/ (utility functions)
│   │   └── data/ (currency data)
│   └── index.html
├── server/
│   ├── index.ts (main server file)
│   ├── routes.ts
│   └── storage.ts
├── shared/
│   └── schema.ts
├── package.json (dependencies)
├── tsconfig.json
├── vite.config.ts
├── tailwind.config.ts
├── postcss.config.js
├── .env.example
├── MONETIZATION_GUIDE.md
└── WORDPRESS_IFRAME_GUIDE.md
```

## 🚀 Setting Up on Your Own Hosting

### Requirements for Your Hosting:
- **Node.js** support (version 18+)
- **npm** package manager
- **Terminal/SSH access**
- **24/7 uptime**

### Popular Hosting Options:
1. **DigitalOcean** - $5/month droplet with Node.js
2. **Linode** - $5/month VPS
3. **Vercel** - Free tier, perfect for this project
4. **Netlify** - Free tier available
5. **Railway** - Simple deployment
6. **Render** - Free tier with automatic deployments

## 📋 Installation Steps on New Hosting

### Step 1: Upload Files
```bash
# Upload your project files to your server
# Use FTP, cPanel, or git clone
```

### Step 2: Install Dependencies
```bash
# Navigate to your project folder
cd your-forex-calculator-project

# Install all required packages
npm install
```

### Step 3: Set Up Environment Variables
```bash
# Copy the example environment file
cp .env.example .env

# Edit .env with your settings
# Add your Google AdSense Publisher ID:
VITE_GOOGLE_ADSENSE_CLIENT=ca-pub-XXXXXXXXXX
```

### Step 4: Build the Project
```bash
# Build the production version
npm run build

# Start the server
npm run dev
```

### Step 5: Configure Your Domain
- Point your domain to your server IP
- Set up SSL certificate (Let's Encrypt is free)
- Configure your server to serve the app

## 🔄 Update WordPress Integration

Once your calculators are running on your domain:

### Update All Iframe URLs
**Old URL (Replit):**
```html
<iframe src="https://your-project.replit.app/position-size-calculator" ...>
```

**New URL (Your Domain):**
```html
<iframe src="https://yourdomain.com/position-size-calculator" ...>
```

### Bulk Update in WordPress:
1. Go to WordPress Admin → Tools → Search Replace
2. Search for: `your-project.replit.app`
3. Replace with: `yourdomain.com`
4. Run replacement across all posts/pages

## 💰 Monetization Setup on New Domain

### Google AdSense
1. **Update AdSense Settings:**
   - Add your new domain to AdSense account
   - Update site list in AdSense dashboard
   - May need re-approval for new domain

2. **Verify Ads Work:**
   - Test all calculator pages
   - Check ad placement and loading
   - Monitor earnings in AdSense dashboard

### Affiliate Links
- Update any hardcoded affiliate URLs
- Test all broker referral links
- Ensure tracking pixels still work

## 🛠 Server Configuration Examples

### For DigitalOcean Droplet:
```bash
# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PM2 for process management
sudo npm install -g pm2

# Start your app with PM2
pm2 start server/index.ts --name "forex-calculator"
pm2 startup
pm2 save
```

### For Nginx Configuration:
```nginx
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;
    
    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## 📊 Performance Optimization

### Enable Gzip Compression:
```javascript
// Add to your server/index.ts
import compression from 'compression';
app.use(compression());
```

### Set Up CDN:
- Cloudflare (free tier available)
- AWS CloudFront
- Improves loading speed globally

## 🔒 Security Considerations

### SSL Certificate:
```bash
# Using Let's Encrypt (free)
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com
```

### Firewall Setup:
```bash
# Basic UFW setup
sudo ufw allow ssh
sudo ufw allow 'Nginx Full'
sudo ufw enable
```

## 📈 Analytics and Monitoring

### Google Analytics:
- Add tracking code to all calculator pages
- Monitor visitor behavior and popular calculators
- Track conversion rates for affiliate links

### Server Monitoring:
- Set up uptime monitoring (UptimeRobot is free)
- Monitor server resources (CPU, memory)
- Set up alerts for downtime

## 🎯 Final Checklist

✅ **Project Downloaded/Copied**
✅ **Dependencies Installed**
✅ **Environment Variables Set**
✅ **Domain Configured**
✅ **SSL Certificate Installed**
✅ **WordPress Iframes Updated**
✅ **AdSense Domain Added**
✅ **All Calculators Tested**
✅ **Affiliate Links Working**
✅ **Analytics Configured**
✅ **Monitoring Set Up**

## 💡 Pro Tips

1. **Keep Replit Running Temporarily:**
   - Test your new hosting first
   - Gradually switch iframe URLs
   - Ensure everything works before shutting down Replit

2. **Backup Strategy:**
   - Regular database backups (if you add one later)
   - Code backups to GitHub
   - Configuration backups

3. **Scaling Preparation:**
   - Use PM2 or similar for process management
   - Set up load balancing when traffic grows
   - Consider Docker containers for easier deployment

## 📞 Support Resources

- **Hosting Support:** Contact your hosting provider
- **WordPress Help:** WordPress.org support forums
- **AdSense Issues:** Google AdSense Help Center
- **Technical Questions:** Stack Overflow

Your forex calculator platform is now ready to run independently and generate revenue on your own hosting! 🚀