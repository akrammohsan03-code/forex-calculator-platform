import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get all currency pairs
  app.get("/api/currency-pairs", async (req, res) => {
    try {
      const pairs = await storage.getAllCurrencyPairs();
      res.json(pairs);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch currency pairs" });
    }
  });

  // Get specific currency pair
  app.get("/api/currency-pairs/:symbol", async (req, res) => {
    try {
      const { symbol } = req.params;
      const pair = await storage.getCurrencyPair(symbol);
      if (!pair) {
        return res.status(404).json({ error: "Currency pair not found" });
      }
      res.json(pair);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch currency pair" });
    }
  });

  // Update currency pair rate (for real-time updates)
  app.patch("/api/currency-pairs/:symbol", async (req, res) => {
    try {
      const { symbol } = req.params;
      const { rate } = req.body;
      
      if (!rate || isNaN(parseFloat(rate))) {
        return res.status(400).json({ error: "Valid rate is required" });
      }

      const updated = await storage.updateCurrencyPair(symbol, { rate: rate.toString() });
      if (!updated) {
        return res.status(404).json({ error: "Currency pair not found" });
      }
      
      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: "Failed to update currency pair" });
    }
  });

  // Save calculator result
  app.post("/api/calculator-results", async (req, res) => {
    try {
      const { calculatorType, inputData, result } = req.body;
      
      if (!calculatorType || !inputData || !result) {
        return res.status(400).json({ error: "All fields are required" });
      }

      const saved = await storage.saveCalculatorResult({
        calculatorType,
        inputData: JSON.stringify(inputData),
        result: JSON.stringify(result),
      });
      
      res.json(saved);
    } catch (error) {
      res.status(500).json({ error: "Failed to save calculator result" });
    }
  });

  // Get calculator results by type
  app.get("/api/calculator-results/:type", async (req, res) => {
    try {
      const { type } = req.params;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      
      const results = await storage.getCalculatorResults(type, limit);
      res.json(results);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch calculator results" });
    }
  });

  // Forex rates proxy endpoint (using free API service)
  app.get("/api/forex-rates/:base?", async (req, res) => {
    try {
      const base = req.params.base || 'USD';
      
      // Use exchangerate.host - free API service without registration
      const response = await fetch(`https://api.exchangerate.host/latest?base=${base}`);
      
      if (!response.ok) {
        throw new Error(`API request failed: ${response.status}`);
      }
      
      const data = await response.json();
      
      if (data.success) {
        // Transform to our expected format
        const transformedData = {
          base_code: data.base,
          conversion_rates: data.rates,
          time_last_update_utc: data.date,
        };
        res.json(transformedData);
      } else {
        throw new Error('API request unsuccessful');
      }
    } catch (error) {
      // Enhanced fallback with more realistic rates
      const fallbackRates: Record<string, number> = {
        // Major currencies
        'EUR': 0.85, 'GBP': 0.73, 'JPY': 110.0, 'CHF': 0.92, 'AUD': 1.35, 'CAD': 1.25, 'NZD': 1.42,
        // Exotic currencies
        'ZAR': 15.2, 'MXN': 20.5, 'SGD': 1.35, 'HKD': 7.8, 'NOK': 8.5, 'SEK': 9.2, 'DKK': 6.3,
        'TRY': 8.5, 'PLN': 3.9, 'CZK': 22.1, 'HUF': 310.0, 'RUB': 75.0, 'BRL': 5.2, 'INR': 74.5,
        'CNY': 6.4, 'KRW': 1180.0, 'THB': 33.2, 'MYR': 4.1, 'PHP': 50.5, 'IDR': 14250.0,
      };

      // If base is not USD, convert rates accordingly
      const base = req.params.base || 'USD';
      let convertedRates = { ...fallbackRates };
      
      if (base !== 'USD') {
        const baseRate = fallbackRates[base] || 1;
        convertedRates = {};
        Object.entries(fallbackRates).forEach(([currency, rate]) => {
          convertedRates[currency] = rate / baseRate;
        });
        convertedRates['USD'] = 1 / baseRate;
      } else {
        convertedRates['USD'] = 1;
      }

      const fallbackData = {
        base_code: base,
        conversion_rates: convertedRates,
        time_last_update_utc: new Date().toISOString(),
      };
      
      res.json(fallbackData);
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
